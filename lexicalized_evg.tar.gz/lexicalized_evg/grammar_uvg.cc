/*
 * Copyright William Headden 2009
 *
*/

#include"grammar_uvg.h"
#include<math.h>
U Grammar_uvg::NUMSTOP=2;
U Grammar_uvg::NUMARG=1;
string Grammar_uvg::type_id="Grammar_uvg";
void Grammar_uvg::initKlein(const vector<Sentence> & sents,F randomize,int varType,const vector<set<Upair> > * train_deps){
 	cout<<"initKlein, randomize="<<randomize<<endl;
	//assert(NUMARG==1&&NUMSTOP==2);
	ExtendedHashCount<U,U,double> largs;
	ExtendedHashCount<U,U,double> rargs;
	HashCount<U,double> rootargs;
	ExtendedHashCount<U,U,double> lstops[2];
	ExtendedHashCount<U,U,double> lstops2[2];
	ExtendedHashCount<U,U,double> rstops[2];
	ExtendedHashCount<U,U,double> rstops2[2];
	set<U> tags;
	for(U s=0;s<sents.size();s++){
		HashCount<U,double> er;
		HashCount<U,double> el;
		Sentence w;
		w.resize(sents[s].size()/2);
		for(U i=0;i<sents[s].size();i+=2)
			w[i/2]=sents[s][i];
		double n=w.size();
		for(U i=0;i<w.size();i+=1){
			rootargs.inc(w[i].tag,1/n);
			tags.insert(w[i].tag);
		}
		for(int j=0;j<(int)w.size();j+=1){
			double sum=0.0;
			for(int i = 0; i < n; ++i) {
			    if(i!=j) sum += 1.0 / fabs(i - j);
			}
			for(int i = 0; i < j; ++i) {
			    double x = ((n - 1.0)/(n)) * (1.0/sum) * (1.0/(j - i));
			    er.inc(i,x);
			    rargs.inc(w[j].tag,w[i].tag,x);
			}
			for(int i = j+1; i < n; ++i) {
			    double x = ((n - 1.0)/(n)) * (1.0/sum) * (1.0/(i - j));
			    el.inc(i,x);
			    largs.inc(w[j].tag,w[i].tag,x);
			}
			
		}
		for(int i = 0; i < n; ++i){
			if(el.get(i) > 0) {

			    lstops2[0].inc(nonstop,w[i].tag,1.0);
			    lstops[1].inc(nonstop,w[i].tag,el.get(i));
			    lstops2[1].inc(nonstop,w[i].tag,-1);

			    lstops[0].inc(stop,w[i].tag,1.0);
			    lstops2[0].inc(stop,w[i].tag,-1.0);
			    lstops2[1].inc(stop,w[i].tag,1);
			}
			else {
			    lstops[0].inc(stop,w[i].tag,1.0);
			}

			if(er.get(i) > 0) {
			    rstops2[0].inc(nonstop,w[i].tag,1.0);
			    rstops[1].inc(nonstop,w[i].tag,er.get(i));
			    rstops2[1].inc(nonstop,w[i].tag,-1);

			    rstops[0].inc(stop,w[i].tag,1.0);
			    rstops2[0].inc(stop,w[i].tag,-1.0);
			    rstops2[1].inc(stop,w[i].tag,1);
			}
			else {
			    rstops[0].inc(stop,w[i].tag,1.0);
			}
			

		}

	}
	//smoothing
	foreach (set<U>,tag,tags){
	    U a=*tag;
	    rootargs.inc(a,0.1);
	    foreach (set<U>,tag2,tags){
		U b=*tag2;
		largs.inc(a,b,.1);
		rargs.inc(a,b,.1);
	    }
	    for(U v=0;v<2;v++){
		lstops[v].inc(stop,a,.1);
		lstops[v].inc(nonstop,a,.1);
		rstops[v].inc(stop,a,.1);
		rstops[v].inc(nonstop,a,.1);
	    }
	}
	//crazy stuff:
	double min_e = 0.0;
	double max_e = 1.0;
	for(U v=0;v<2;v++){
		foreach (set<U>,tag,tags){
		    U a=*tag;
		    double c=lstops[v].get(stop,a);
		    double cc=lstops2[v].get(stop,a);
		    if(c>0 && cc<0){
			if(max_e> -c/cc){
				max_e=-c/cc;
			}
		    }	
		    if(c>0 && cc>0){
			if(min_e < -c/cc) {
			    min_e = -c/cc;
			}
			
		    }
		    c=rstops[v].get(stop,a);
		    cc=rstops2[v].get(stop,a);
		    if(c>0 && cc<0){
			if(max_e> -c/cc){
				max_e=-c/cc;
			}
		    }	
		    if(c>0 && cc>0){
			if(min_e < -c/cc) {
			    min_e = -c/cc;
			}
			
		    }
		    c=lstops[v].get(nonstop,a);
		    cc=lstops2[v].get(nonstop,a);
		    if(c>0 && cc<0){
			if(max_e> -c/cc){
				max_e=-c/cc;
			}
		    }	
		    if(c>0 && cc>0){
			if(min_e < -c/cc) {
			    min_e = -c/cc;
			}
			
		    }
		    c=rstops[v].get(nonstop,a);
		    cc=rstops2[v].get(nonstop,a);
		    if(c>0 && cc<0){
			if(max_e> -c/cc){
				max_e=-c/cc;
			}
		    }	
		    if(c>0 && cc>0){
			if(min_e < -c/cc) {
			    min_e = -c/cc;
			}
			
		    }
		}
	}
	double pr_first_kid = 0.9 * max_e + 0.1 * min_e;
	for(U v=0;v<2;v++){
		foreach (set<U>,tag,tags){
		    U a=*tag;
		    if(lstops2[v].get(stop,a)>0) lstops[v].inc(stop,a,pr_first_kid*lstops2[v].get(stop,a));
		    if(lstops2[v].get(nonstop,a)>0) lstops[v].inc(nonstop,a,pr_first_kid*lstops2[v].get(nonstop,a));
		    if(rstops2[v].get(stop,a)>0) rstops[v].inc(stop,a,pr_first_kid*rstops2[v].get(stop,a));
		    if(rstops2[v].get(nonstop,a)>0) rstops[v].inc(nonstop,a,pr_first_kid*rstops2[v].get(nonstop,a));
		}
	}
	for(U v=0;v<2;v++){
		foreach (set<U>,tag,tags){
		    U a=*tag;
		    L_att.get_stop_given_head_valence(a,v)->insert(stop,lstops[v].get(stop,a));
		    R_att.get_stop_given_head_valence(a,v)->insert(stop,rstops[v].get(stop,a));
		    L_att.get_stop_given_head_valence(a,v)->insert(nonstop,lstops[v].get(nonstop,a));
		    R_att.get_stop_given_head_valence(a,v)->insert(nonstop,rstops[v].get(nonstop,a));
		    cout<<"L_stop:\t   stop/nonstop\t"<<getTagVocab().lookup(a)<<'\t'<<v<<'\t'<<lstops[v].get(stop,a)<<'\t'<<lstops[v].get(nonstop,a)<<'\t'<<lstops[v].get(stop,a)/(double)(lstops[v].get(stop,a)+lstops[v].get(nonstop,a))<<endl;
		    cout<<"R_stop:\t   stop/nonstop\t"<<getTagVocab().lookup(a)<<'\t'<<v<<'\t'<<rstops[v].get(stop,a)<<'\t'<<rstops[v].get(nonstop,a)<<'\t'<<rstops[v].get(stop,a)/(double)(rstops[v].get(stop,a)+rstops[v].get(nonstop,a))<<endl;
		}
	}
	foreach (set<U>,tag2,tags){
		U a=*tag2;
		S_root_att.get_arg_given_root()->insert(a,rootargs.get(a));
		    foreach (set<U>,tag,tags){
			U b=*tag;
			for(U v=1;v<=NUMARG;v++){
				L_att.get_arg_given_head_valence(b,2)->insert(a,largs.get(a,b),false);
				R_att.get_arg_given_head_valence(b,2)->insert(a,rargs.get(a,b),false);
			}
		    }
	}
	if(randomize>0){
		cout<<"sampling from posterior of klein initializer"<<endl;
		sample_posterior(true,true,randomize);
	}
}


Grammar_uvg::Grammar_uvg(MetaGrammar * mg):Grammar(mg),

	S_root_att(this,getArgs(),getWords(),getTagVocab(),getWordVocab()),
	L_att(this,getArgs(),getWords(),mg->stop_symbols,"L",getTagVocab(),getWordVocab()),
	R_att(this,getArgs(),getWords(),mg->stop_symbols,"R",getTagVocab(),getWordVocab())
{
	setCollapsed(false,true,true);
}
Grammar_uvg::Grammar_uvg(Grammar_uvg * model0, MetaGrammar * metagrammar):
	Grammar(metagrammar),
	S_root_att(model0->S_root_att,this),
	L_att(model0->L_att,this),
	R_att(model0->R_att,this)
{

	//reestimate(type,model0);
}
F Grammar_uvg::increment_rule(U par,U pc, U l,U lc, const word_type & head,F weight,bool delete_table){
	assert(pc==TOP);
	assert(lc<TOP);
	// If lc==0, then 1 stop, no nonstops
	// if lc==1, then 1 stop, 1 nonstop
	// if lc==2, then 1 stop, 2 nonstop...
	// if lc==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}
			
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}

	}
	else assert(false);
        return pr;	
}

F Grammar_uvg::increment_rule(U par, U pc,U lchild,U lc, U rchild, U rc, const word_type & s,const word_type & m, const word_type & e,F weight,bool delete_table){
    F pr=1;
	if(weight==1)assert(!delete_table);
	
	// L^pc -> L ML^pc
	if(par==L){
	    assert(pc==rc);
	    assert(lc==TOP);
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(lchild==L&&rchild==ML);
	    pr*=L_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=L_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(pc==lc);
	    assert(rc==TOP);
	    assert(lchild==MR&&rchild==R);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    pr*=R_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=R_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(rc==TOP-1||rc==TOP-2);
  	   
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }


	}
	// MR --> R L
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(lc==TOP-1||lc==TOP-2);
	   assert(lchild==R&&rchild==L);
	   assert(rc==TOP);
	   if(pc==TOP-1){
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }

	}
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_inc(m.tag,weight);
	  pr*=  S_root_att.aw_given_root_arg_inc(m.tag,m.word,weight);
	}
	//S -> L R

    return pr;	
}
F Grammar_uvg::prob_rule(U par,U pc,U l,U lc, const word_type & head){
	assert(pc==TOP);
	assert(lc<TOP);
	assert(par==l);
	// If pc2==0, then 1 stop, no nonstops
	// if pc2==1, then 1 stop, 1 nonstop
	// if pc2==2, then 1 stop, 2 nonstop...
	// if pc2==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);

	}
	else assert(false);
	if(pr>1&&pr<1.00001) pr=1;
	if(pr>1) cout<<"pr="<<pr<<endl;
	assert(pr<=1);
	//cout<<"prob_rule="<<translate[par]<<pc<<" --> "<<translate[l]<<lc
	//		  <<'\t'<<getTagVocab().lookup(head.tag)
	//		  <<'\t'<<pr<<endl;
        return pr;	
}

F Grammar_uvg::prob_rule(U par,U pc, U lchild, U lc, U rchild,U rc, const word_type & s,const word_type & m,const word_type & e){
	// L -> L ML
	assert(pc>0);
	assert(pc<NUMVAL);
	assert(lc<NUMVAL);
	assert(rc<NUMVAL);
	F pr=1;
	if(par==L){
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(pc==rc);
	    assert(lc==TOP);
	    assert(lchild==L&&rchild==ML);
	    pr*=L_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=L_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(lchild==MR&&rchild==R);
	    assert(pc==lc);
	    assert(rc==TOP);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    pr*=R_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=R_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(pc-1==rc||pc==rc);
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//ML^Np -->R L^Np | R L^N-1
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
	   }
	}
	// MR --> UR L
	// MR --> MR M
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(pc-1==lc||pc==lc);
	   assert(rc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//MR^Np -->R^Np L | R^N-1 L
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
	    }
	}
	// M --> R L 
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_prob(m.tag);
	  pr*=  S_root_att.aw_given_root_arg_prob(m.tag,m.word);

	}
	else assert(false);
	//S -> L R
	//cout<<"prob_rule="<<translate[par]<<pc<<" --> "
	//		  <<translate[lchild]<<lc<<'\t'
	//		  <<translate[rchild]<<rc<<'\t'
	//		  <<'\t'<<getTagVocab().lookup(s.tag)
	//		  <<'\t'<<getTagVocab().lookup(m.tag)
	//		  <<'\t'<<getTagVocab().lookup(e.tag)
	//		  <<pr<<endl;
	if(!(pr<=1)) cout<<"pr="<<pr<<endl;
	assert(pr<=1);
	return pr;

}
void Grammar_uvg::write(ostream & out){
	out<<"Grammar: "<<endl;
	out<<"left:"<<endl;
	L_att.write(out);
	out<<"right:"<<endl;
	R_att.write(out);
}
void Grammar_uvg::AttDist::write(ostream & out){}
MD * Grammar_uvg::AttDist::get_stop_given_head_valence(U  h,U v){ 
	if(v>=NUMSTOP) v=NUMSTOP-1;//cap valence
	return getMD(h,v,stop_given_head_valence);
}
F Grammar_uvg::AttDist::stop_given_head_valence_hw_prob(U h,U v, U hw,U arg){
	return get_stop_given_head_valence(h,v)->prob(arg);
}
F Grammar_uvg::AttDist::stop_given_head_valence_hw_inc(U h,U v, U hw,U arg,F weight){
	return get_stop_given_head_valence(h,v)->insert(arg,weight,false);
}

F Grammar_uvg::AttDist::arg_given_head_valence_hw_inc(U h,U v, U hw,U arg,F weight){
	U size=1;
	MD * md[size];
	md[0] = get_arg_given_head_valence(h,v);

	F mix[1]= {1};
	F total=0;
	F probTrans[size];
	for(U i=0;i<size;i++){
		probTrans[i]=md[i]->prob(arg)*mix[i];
		total+=probTrans[i];
	}
	if(total==0) total=1;//in case there is zero mass

	for(U i=0;i<size;i++){
		md[i]->insert(arg,weight*probTrans[i]/total,false);
	}
	return total;
}

F Grammar_uvg::AttDist::arg_given_head_valence_prob(U h,U v, U argt){
	MD * md1 = get_arg_given_head_valence(h,v);
	
	F pr=md1->prob(argt);
	
	assert(pr>=0&&pr<=1.0000001);
	return pr;
}
F Grammar_uvg::AttDist::arg_given_head_valence_hw_prob(U ht,U v,U hw, U argt){
	F pr=arg_given_head_valence_prob(ht,v,argt);
	return pr;
}
F Grammar_uvg::AttDist::aw_given_arg_head_valence_hw_prob(U argt,U ht,U v,U hw, U aw){
	return 1;
}
F Grammar_uvg::AttDist::aw_given_arg_head_valence_hw_inc(U arg,U head, U v,U hw, U aw, F weight){
	return 1;
}
MD * Grammar_uvg::AttDist::get_arg_given_head_valence(U  h,U v){ 
	assert(v>0);
	//if(v>NUMARG) cout<<"capped valence "<<v<<" to "<<NUMARG<<endl;
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(h,v,arg_given_head_valence);
}
Grammar_uvg::AttDist::AttDist(Grammar_uvg * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, list<pair<U,F> > & stop,const string & direction,Vocab & tv,Vocab & wv):
	tagVocab(tv),
	wordVocab(wv),
	dir(direction),
	args(arg),
	words(word),
	stops(stop),
	//stop_given_head_valence(NUMSTOP),
	//arg_given_head_valence(NUMARG+1),
	stop_given_head_valence(NUMSTOP,V_MD(tv.size(),NULL)),
	arg_given_head_valence(NUMARG+1,V_MD(tv.size(),NULL)),
	g(gram)
{
	foreach(UFList,arg,getArgs()){
		string id=dir+"_stop_given_";
		string id3=dir+"_arg_given_";
		string id2=dir+"_arg_given_";
		string argstr=tagVocab.lookup(arg->first);
		id+=argstr;
		id3+=argstr;
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
			char nc='0'+n;
			string ida=id3+nc;
			arg_given_head_valence[n][arg->first]=new MD(args.size(),args,ida,false);
			//arg_given_head_valence[n].insert(pair<U,MD>(arg->first,MD(args.size(),args,ida)));
			g->add_nonmix_dist(get_arg_given_head_valence(arg->first,n));




		}

		for(U n=0;n<NUMSTOP;n++){
			char nc='0'+n;
			string ida=id+nc;
			stop_given_head_valence[n][arg->first]=new MD(2,stops,ida,false);
			//stop_given_head_valence[n].insert(pair<U,MD>(arg->first,MD(2,stops,ida)));
			g->add_nonmix_dist(get_stop_given_head_valence(arg->first,n));
		}
	}
		
}
Grammar_uvg::AttDist::AttDist(Grammar_uvg::AttDist & ad,Grammar_uvg * gram):
	tagVocab(ad.tagVocab),
	wordVocab(ad.wordVocab),
	dir(ad.dir),
	args(ad.args),
	words(ad.words),
	stops(ad.stops),
	stop_given_head_valence(NUMSTOP,V_MD(tagVocab.size(),NULL)),
	arg_given_head_valence(NUMARG+1,V_MD(tagVocab.size(),NULL)),
	g(gram)
{
	foreach(UFList,arg,getArgs()){
		string id=dir+"_stop_given_";
		string id3=dir+"_arg_given_";
		string id2=dir+"_arg_given_";
		string argstr=tagVocab.lookup(arg->first);
		id+=argstr;
		id3+=argstr;
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
			char nc='0'+n;
			string ida=id3+nc;
			arg_given_head_valence[n][arg->first]=new MD(*(ad.get_arg_given_head_valence(arg->first,n)));
			g->add_nonmix_dist(get_arg_given_head_valence(arg->first,n));

		}

		for(U n=0;n<NUMSTOP;n++){
			char nc='0'+n;
			string ida=id+nc;
			stop_given_head_valence[n][arg->first]=new MD(*(ad.get_stop_given_head_valence(arg->first,n)));
			g->add_nonmix_dist(get_stop_given_head_valence(arg->first,n));
		}
	}
		
}

Grammar_uvg::RootAttDist::RootAttDist(Grammar_uvg * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, Vocab & tv,Vocab & wv):
	tagVocab(tv),
	wordVocab(wv),
	args(arg),
	words(word),
	arg_given_root(new MD(args.size(),args,"S_arg_given_root")),
	g(gram)
{
	g->add_nonmix_dist(get_arg_given_root());
}
Grammar_uvg::RootAttDist::RootAttDist(Grammar_uvg::RootAttDist & ad,Grammar_uvg * gram):
	tagVocab(ad.tagVocab),
	wordVocab(ad.wordVocab),
	args(ad.args),
	words(ad.words),
	arg_given_root(new MD(*(ad.get_arg_given_root()))),
	g(gram)
{
	g->add_nonmix_dist(get_arg_given_root());
}
F Grammar_uvg::RootAttDist::arg_given_root_prob(U arg){
	return arg_given_root->prob(arg);
}
F Grammar_uvg::RootAttDist::aw_given_root_arg_prob(U arg,U aw){
        return 1;
}

F Grammar_uvg::RootAttDist::arg_given_root_inc(U arg,F weight){
	return arg_given_root->insert(arg,weight,false);
}
F Grammar_uvg::RootAttDist::aw_given_root_arg_inc(U arg,U aw,F weight){
	return 1;
}

