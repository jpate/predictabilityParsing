a=2
s=2
runpath='/home/headdenw/research/markPCFGsamplers/lexicalized2_3_merge/'
hogpath=runpath+'hog_reg2/'
executable=runpath+'estimate_uvg6_luvg1linb'
hogname='VB_uvg6_luvg1linb_23_2_2'
treepath=runpath+'hog_reg2/'+hogname+'/analyses/'
options1=' -D 1  -V 1 -n 100 -u 100 -t /u/headdenw/tmp/wsj_2_21.conll -d /u/headdenw/tmp/wsj_22.conll -T /u/headdenw/tmp/wsj_23.conll -b 20 -M 1000'
seed0=17500
num_jobs=500
for job in range(0,num_jobs):
	print executable+options1+' -r '+str(seed0+job)+' -a '+str(a)+' -s '+str(s)+' -A '+treepath+str(job)
	
