/*
 * Copyright William Headden 2009
 *
*/

#include"dependency.h"
#include"utility.h"
void processWords(Sentences & trains,Sentences & trains2,Sentences & devs,Sentences & tests,Sentences & tests10,Vocab & wordVocab,list<pair<U,F> > & words,int unkCutoff,string unkstr,int unkNum,Vocab & tagVocab,U ownTagCutoff){
	
	HashCount<U> wordCount;
	HashCount<U> wordCount2;
	U unk=wordVocab.lookup(unkstr);
	for(U i=0;i<trains.size();i++)
		for(U j=0;j<trains[i].size();j++){
			wordCount.inc(trains[i][j].word,1);
			wordCount2.inc(trains[i][j].word,1);
		}
	for(U i=0;i<trains2.size();i++)
		for(U j=0;j<trains2[i].size();j++){
			wordCount.inc(trains2[i][j].word,1);
		}
        if(unkNum>0){//keep top unkNum, make rest 0
		//assert(false);
		set<int> count_word;
		foreach(HashCount<U>,c,wordCount){
			count_word.insert(c->second);
		}
		int i=0;
		rforeach(set<int>,c,count_word){
			i++;
			if(i==unkNum+1){
				unkCutoff=*c;
			}
		}	
		i=0;
		foreach(HashCount<U>,c,wordCount){
			
			if(c->second>unkCutoff)
				cout<<"keeping word "<<(i++)<<'\t'<<wordVocab.lookup(c->first)<<'\t'<<c->second<<endl;
			count_word.insert(c->second);
		}
	}
	U otc=0;
	cout<<"promote top "<<ownTagCutoff<<" words"<<endl;
        if(ownTagCutoff>0){//keep top unkNum, make rest 0
		//assert(false);
		set<int> count_word;
		foreach(HashCount<U>,c,wordCount2){
			count_word.insert(c->second);
		}
		U i=0;
		rforeach(set<int>,c,count_word){
			i++;
			if(i==ownTagCutoff-1){
				otc=*c;
				break;
			}
		}	
		ownTagCutoff=otc;
	}
	else ownTagCutoff=(U)-1;//max value

	cout<<"unkNum="<<unkNum<<"\tunkCutoff="<<unkCutoff<<"\townTagCutoff="<<ownTagCutoff<<endl;
	for(U i=0;i<trains.size();i++)
		for(U j=0;j<trains[i].size();j++){
			if(wordCount2.get(trains[i][j].word)>ownTagCutoff){//if we see a word often enough, give it its own tag right off the bat
				trains[i][j].tag=tagVocab.lookup(wordVocab.lookup(trains[i][j].word));
				cout<<"promoting "<<wordVocab.lookup(trains[i][j].word)<<endl;
				assert(false);
			}
			if(wordCount.get(trains[i][j].word)<=unkCutoff)
				trains[i][j].word=unk;
		}
	for(U i=0;i<trains2.size();i++)
		for(U j=0;j<trains2[i].size();j++){
			if(wordCount2.get(trains2[i][j].word)>ownTagCutoff){//if we see a word often enough, give it its own tag right off the bat
				trains2[i][j].tag=tagVocab.lookup(wordVocab.lookup(trains2[i][j].word));
				assert(false);
			}
			if(wordCount.get(trains2[i][j].word)<=unkCutoff)
				trains2[i][j].word=unk;
		}
	for(U i=0;i<devs.size();i++)
		for(U j=0;j<devs[i].size();j++){
			if(wordCount2.get(devs[i][j].word)>ownTagCutoff){//if we see a word often enough, give it its own tag right off the bat
				devs[i][j].tag=tagVocab.lookup(wordVocab.lookup(devs[i][j].word));
				assert(false);
			}
			if(wordCount.get(devs[i][j].word)<=unkCutoff)
				devs[i][j].word=unk;
		}
	for(U i=0;i<tests.size();i++)
		for(U j=0;j<tests[i].size();j++){
			if(wordCount2.get(tests[i][j].word)>ownTagCutoff){//if we see a word often enough, give it its own tag right off the bat
				tests[i][j].tag=tagVocab.lookup(wordVocab.lookup(tests[i][j].word));
				assert(false);
			}
			if(wordCount.get(tests[i][j].word)<=unkCutoff)
				tests[i][j].word=unk;
		}
	for(U i=0;i<tests10.size();i++)
		for(U j=0;j<tests10[i].size();j++){
			if(wordCount2.get(tests10[i][j].word)>ownTagCutoff){//if we see a word often enough, give it its own tag right off the bat
				tests10[i][j].tag=tagVocab.lookup(wordVocab.lookup(tests[i][j].word));
				assert(false);
			}
			if(wordCount.get(tests10[i][j].word)<=unkCutoff)
				tests10[i][j].word=unk;
		}
	int unkCount=0;
	for(U i=1;i<wordVocab.size();i++)
		if(wordCount.get(i)>=unkCutoff){
			//cout<<"adding word "<<wordVocab.lookup(i)<<endl;
			words.push_back(pair<U,F>(i,1));

		}
		else if(i!=unk){
			//cout<<"substituted UNK for "<<wordVocab.lookup(i)<<'\t'<<i<<endl;
			
			unkCount++;
		}
	if(unkCount>0)
		words.push_back(pair<U,F>(unk,1));
	
	cout<<"vocabulary has "<<words.size()<<" words; collapsed to UNK: "<<unkCount<<" "<<endl;
	
}
void read_deps(istream & in,Sentences & trains, vector<set<Upair> > * gold_deps,Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len,bool use_gold_tags,bool excise_on_words,U language){
	cout<<"read_deps"<<endl;
	vector<list<CoNLLDependency> > gold_conll_deps;
	CoNLLDependency::read_deps(in,gold_conll_deps);
	cout<<"removing punc and filtering for size"<< excise_punc<<endl;
	if(gold_deps) gold_deps->resize(gold_conll_deps.size());
	PuncID pid(language);
	PuncID2 pid2;
	size_t i_small=0;
	U none=-2;
	U root=-1;
	for(size_t i=0;i<gold_conll_deps.size();i++){
		size_t k=0;
		int num_punc=0;
		bool puncMismatch=false;
		vector<CoNLLDependency> depvec(gold_conll_deps[i].size());
		foreach(list<CoNLLDependency>,j,gold_conll_deps[i]){
			const CoNLLDependency & d=*j;
					assert(k<depvec.size());
					depvec[k]=d;
			if(excise_punc){
				if((!excise_on_words)&&(pid.isPunc(d.cpostag)||pid.isPunc(d.postag))){
					if(use_gold_tags&&pid.isPunc(d.cpostag)!=pid.isPunc(d.postag))
						puncMismatch=true;
					depvec[k].head=none;
					depvec[k].phead=none;
					num_punc++;
				}
				else if(excise_on_words&&(pid2.isPunc(d.form))){
					depvec[k].head=none;
					depvec[k].phead=none;
					num_punc++;

				}
			}
			k++;
		}
		if(puncMismatch) continue;
		assert(depvec.size()==k);
		//assert(num_punc==0);
		bool skip=false;
		if(excise_punc&&num_punc>0){
				//cout<<"removing puncs"<<endl;
				//for(k=0;k<depvec.size();k++){
				//	cout<<depvec[k]<<endl;
				//}
				for(k=0;k<depvec.size();k++){
					if(depvec[k].head==none){
							assert(depvec[k].phead==none);
							for(size_t k1=0;k1<depvec.size();k1++){
								if(depvec[k1].id>k) depvec[k1].id--;			
								if(depvec[k1].head>k&&depvec[k1].head!=none&&depvec[k1].head!=root) depvec[k1].head--;			
								if(depvec[k1].phead>k&&depvec[k1].phead!=none&&depvec[k1].phead!=root) depvec[k1].phead--;			
							}
							for(size_t k1=k+1;k1<depvec.size();k1++)
								depvec[k1-1]=depvec[k1];
							depvec.resize(depvec.size()-1);
							k--;
					}
				}
				U root_k=depvec.size();
				for(k=0;k<depvec.size();k++){
					if(depvec[k].head==k){
						skip=true;
					}
					if(depvec[k].head==0) root_k=k;
					
				}
				//if(root_k==depvec.size()) skip=true;
				//for(k=0;k<depvec.size();k++){
				//	cout<<depvec[k]<<endl;
				//}
		}


		if(depvec.size()>max_sent_len||skip) continue;
		Sentence terms;
		terms.resize(2*k);
		//cout<<endl;
		for(k=0;k<depvec.size();k++){
			//cout<<depvec[k]<<endl;
			if(depvec[k].head==k){
				cerr<<"depvec:"<<endl;
				for(U j=0;j<depvec.size();j++) cerr<<'\t'<<depvec[j]<<endl;
			}
			assert(depvec[k].id==k);
			assert(depvec[k].head!=k);
			assert(depvec[k].phead!=k);
			assert(2*k+1<terms.size());
			string form=depvec[k].form;
			if(lowercaseAll){
				for(U j=0;j<form.size();j++)
					form[j]=tolower(form[j]);
			}
			terms[2*k]=terms[2*k+1]=word_type(tagVocab.lookup(depvec[k].postag),wordVocab.lookup(form));
			if(depvec[k].head>200)
				assert(depvec[k].head==root);
			if(gold_deps)(*gold_deps)[i_small].insert(Upair(depvec[k].head,depvec[k].id));
		}
		if(gold_deps&&(*gold_deps)[i_small].size()>0){
			//for(k=0;k<depvec.size();k++){
			//	depvec[k].print(cout);
			//}
			//cout<<endl;
			assert(terms.size()>0);
			trains.push_back(terms);
			i_small++;	
		}
	}
	if(gold_deps) gold_deps->resize(i_small);
	cout<<"done read_deps"<<endl;
}

std::istream& readline_symbols(std::istream& is, list<string> & syms){
  syms.clear();
  std::string line;
  if (std::getline(is, line)) {
    std::istringstream iss(line);
    std::string s;
    while (iss >> s)
      syms.push_back(s);
  }
  return is;
}  // readline_symbols()
pair<string,string> split_symbol(string & s,char delim){
  bool found=false;
  for(U i=0;i<s.size();i++){
	if(s[i]=='_') s[i]=' ';found=true;
  }
  assert(found);
  stringstream ss(s);
  pair<string,string> p;
  ss>>p.first;
  ss>>p.second;
  //cout<<"read "<<s<<" parsed |"<<p<<endl;
  return p;
}  // split_symbols()
list<string> & split_symbol(string s,list<string> & l,char delim){
  U count=0;
  for(U i=0;i<s.size();i++){
	if(s[i]==delim){ 
		s[i]=' ';
		count++;
	}
  }
  assert(count>0);
  stringstream ss(s);
  string temp;
  for(U i=0;i<=count;i++){
	  ss>>temp;
	  l.push_back(temp);
  }
  //cout<<"read "<<s<<" parsed |"<<l<<endl;
  return l;
}  // readline_symbols()

//in has gold dependencies, in2 has the words, the excess words will be at the beginning
void read_flat2(istream & in2,Sentences & trains, Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len){
	cout<<"read_flat2"<<endl;
	vector<vector<vector<int> > > tags;
	vector<vector<int>  > words;
        list<string> terminals;
        vector<vector<int> > terminal_ints;
        vector<int> word_ints;
	while(readline_symbols(in2,terminals)){
		terminal_ints.clear();
		word_ints.clear();
		foreach(list<string>,s,terminals){
			list<string> stringList;
			split_symbol(*s,stringList,'_');
			string word=stringList.front();
			stringList.pop_front();
			if(lowercaseAll)
				for(U j=0;j<word.size();j++)
					word[j]=tolower(word[j]);
			word_ints.push_back(wordVocab.lookup(word));
			vector<int> vec;
			while(stringList.size()>0){
				vec.push_back(tagVocab.lookup(stringList.front()));
				stringList.pop_front();
			}
			
			terminal_ints.push_back(vec);
		}
		tags.push_back(terminal_ints);
		words.push_back(word_ints);
	}
	PuncID2 pid;


	size_t i_small=0;
	//U none=-2;
	//U root=-1;
	for(size_t i=0;i<tags.size();i++){
		size_t k=0;
		int num_punc=0;
		for(U j=0;j<tags[i].size();j++){
			assert(k<=j);
			tags[i][k]=tags[i][j];
			words[i][k]=words[i][j];
			if(excise_punc&&pid.isPunc(wordVocab.lookup(words[i][j]))){
				num_punc++;
			}
			else
				k++;
		}
		tags[i].resize(k);
		words[i].resize(k);
		//what has been written so far, saturday 12pm 

		for(U j=0;j<tags[i].size();j++)
			if(excise_punc&&pid.isPunc(wordVocab.lookup(words[i][j])))
				assert(false);


		if(tags[i].size()>max_sent_len) continue;

		Sentence terms;
		terms.resize(2*k);
		for(k=0;k<tags[i].size();k++){
			assert(2*k+1<terms.size());
			assert(tags[i][k].size()>0);
			//the tags[i][j][0] should change when we go to multiple tags
			terms[2*k]=terms[2*k+1]=word_type(tags[i][k][0],words[i][k]);
		}
		if(terms.size()>0){
			trains.push_back(terms);
			i_small++;	
		}
	}
}
void read_flat(istream & in,istream & in2,Sentences & trains, vector<set<Upair> > & gold_deps,Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len){
	cout<<"read_flat"<<endl;
	vector<vector<int> > tags;
        list<string> terminals;
        vector<int> terminal_ints;
	while(readline_symbols(in2,terminals)){
		terminal_ints.clear();
		foreach(list<string>,s,terminals){
			
			terminal_ints.push_back(tagVocab.lookup((*s)));
		}
		tags.push_back(terminal_ints);
	}
	vector<list<CoNLLDependency> > gold_conll_deps;
	CoNLLDependency::read_deps(in,gold_conll_deps);

	gold_deps.resize(gold_conll_deps.size());
	cout<<"read "<<gold_conll_deps.size()<<" dep_sentences before filtering"<<endl;
	cout<<"read "<<tags.size()<<" tag_sentences before filtering"<<endl;
	assert(gold_conll_deps.size()==tags.size());
	PuncID2 pid;
	size_t i_small=0;
	U none=-2;
	U root=-1;
	for(size_t i=0;i<gold_deps.size();i++){
		size_t k=0;
		int num_punc=0;
		vector<CoNLLDependency> depvec(gold_conll_deps[i].size());
		assert(gold_conll_deps[i].size()==tags[i].size());
		foreach(list<CoNLLDependency>,j,gold_conll_deps[i]){
			const CoNLLDependency & d=*j;
			assert(k<depvec.size());
			depvec[k]=d;
			if(excise_punc&&(pid.isPunc(d.cpostag)||pid.isPunc(d.postag))){
				depvec[k].head=none;
				depvec[k].phead=none;
				num_punc++;
			}
			depvec[k].postag=tagVocab.lookup(tags[i][k]);
			depvec[k].cpostag=tagVocab.lookup(tags[i][k]);
			//cout<<depvec[k]<<endl;
			k++;
		}
		assert(depvec.size()==k);
		if(excise_punc&&num_punc>0){
			for(k=0;k<depvec.size();k++){
				if(depvec[k].head==none){
					assert(depvec[k].phead==none);
					for(size_t k1=0;k1<depvec.size();k1++){
						if(depvec[k1].id>k) depvec[k1].id--;			
						if(depvec[k1].head>k&&depvec[k1].head!=none&&depvec[k1].head!=root) depvec[k1].head--;			
						if(depvec[k1].phead>k&&depvec[k1].phead!=none&&depvec[k1].phead!=root) depvec[k1].phead--;			
					}
					for(size_t k1=k+1;k1<depvec.size();k1++)
						depvec[k1-1]=depvec[k1];
					depvec.resize(depvec.size()-1);
					k--;
				}
			}
		}


		if(depvec.size()>max_sent_len) continue;
		Sentence terms;
		terms.resize(2*k);
		for(k=0;k<depvec.size();k++){
			assert(depvec[k].id==k);
			assert(depvec[k].head!=k);
			assert(depvec[k].phead!=k);
			assert(2*k+1<terms.size());
			string form=depvec[k].form;
			if(lowercaseAll){
				for(U j=0;j<form.size();j++)
					form[j]=tolower(form[j]);
			}
			terms[2*k]=terms[2*k+1]=word_type(tagVocab.lookup(depvec[k].postag),wordVocab.lookup(form));
			gold_deps[i_small].insert(Upair(depvec[k].head,depvec[k].id));
		}
		if(gold_deps[i_small].size()>0){
			assert(terms.size()>0);
			trains.push_back(terms);
			i_small++;	
		}
	}
	gold_deps.resize(i_small);
//	for(size_t i=0;i<trains.size();i++){
//		for(size_t j=0;j<trains[i].size();j++)
//			cout<<tagVocab.lookup(trains[i][j].tag)<<"/"<<wordVocab.lookup(trains[i][j].word)<<" ";
//		cout<<endl;
//	}
	cout<<"done read_flat"<<endl;

}
