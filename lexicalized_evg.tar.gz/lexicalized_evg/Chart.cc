/*
 * Copyright William Headden 2009
 *
*/

#include"Chart.h"
inline bool even(size_t s){
	return s%2==0;
}
#include"random.h"
const word_type & getHeadFromSent(U par,U s,U e,const Sentence & sentence){
		//word_type root(-1,-1);
		
		if(par==S) return sentence.root;
		if(par==L||par==ML)
			return sentence[e];
		else return sentence[s];

}

Chart::Chart(const Sentence & s,Grammar * g):chartPositions(s.size()),sentence(s),grammar(g){
	for(size_t i=0;i<chartPositions.size();i++){
		chartPositions[i].resize(s.size());
		for(size_t j=0;j<chartPositions[i].size();j++){
			chartPositions[i][j].s=i;
			chartPositions[i][j].e=j;
		
		}
	}

}
Chart::~Chart(){//changed


}
void Chart::incErule(U p,U pc, U l,U lc, U s,U e,Grammar * newG){
   assert(p==l);
   assert(pc==TOP);
   F p_sent=get(0,sentence.size()-1)->insideProb[S][TOP];
   F pr = get(s,e)->outsideProb[p][pc] 
	* get(s,e)->insideProb[l][lc] 
	/ p_sent;
   if(pr==0) return;
   pr*= grammar->prob_rule(p,pc,l,lc,getHead(p,s,e));
   newG->increment_rule(p,pc,l,lc,getHead(p,s,e),pr,false);	
}
F Chart::incErule2(U p,U pc, U l,U lc, U r,U rc,U s,U m,U e,Grammar * newG){
   static F pr=0;
   if((pr = get(s,e)->outsideProb[p][pc] 
	* get(s,m)->insideProb[l][lc] 
	* get(m+1,e)->insideProb[r][rc]) >0){
	   pr*= grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e])
	/ get(0,sentence.size()-1)->insideProb[S][TOP];
	   newG->increment_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e],pr,false);	
   }
   return pr;
}
void Chart::incrementExpectedCounts(Grammar * newG){
	U N = sentence.size();
	F p_sent=get(0,N-1)->insideProb[S][TOP];
	assert(p_sent>0);
	F pr=0;
	ChartPos * pos;
	U gap, s,e,m;
	for(s=0;s<N;s++){
		pos=get(s,s);
		if(even(s)){
			pr=pos->outsideProb[L][TOP]*grammar->prob_rule(L,TOP,L,0,sentence[s])*pos->insideProb[L][0]/p_sent;
			newG->increment_rule(L,TOP,L,0,sentence[s],pr,false);
		}
		else{
			pr=pos->outsideProb[R][TOP]*grammar->prob_rule(R,TOP,R,0,sentence[s])*pos->insideProb[R][0]/p_sent;
			newG->increment_rule(R,TOP,R,0,sentence[s],pr,false);
		}
			
	}
	for (gap = 1; gap < N; gap++){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
	     for (m=s;m<e;m++) {
		if(even(s)&&even(e)){// L parent
			// L -> L ML
			for (U n=1;n<TOP;n++){
				incErule2(L,n,L,TOP,ML,n,s,m,e,newG);
			}
			
		}		
		else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			for (U n=1;n<TOP;n++){
				incErule2(R,n,MR,n,R,TOP,s,m,e,newG);
			}
		}		
		else if(!even(s)&&even(e)){   //M parent
			// MLn --> R Ln | n =0,1,2,...,TOP-1
			// MRn --> Rn L
			incErule2(ML,TOP-1,R,TOP,L,TOP-1,s,m,e,newG);
			incErule2(MR,TOP-1,R,TOP-1,L,TOP,s,m,e,newG);
			for (U n=1;n<TOP;n++){
				incErule2(ML,n,R,TOP,L,n-1,s,m,e,newG);
				incErule2(MR,n,R,n-1,L,TOP,s,m,e,newG);
			}
		}
		else if(s==0&&e==N-1){  //S parent
			//S -> L R
			incErule2(S,TOP,L,TOP,R,TOP,s,m,e,newG);
		}		
		
	     }
	     }
    	     if(even(s)&&even(e)){// L parent
			// L -> L ML
			for (U n=1;n<=TOP-1;n++){
				incErule(L,TOP,L,n,s,e,newG);
				
			}
			
	     }		
    	     else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			for (U n=1;n<=TOP-1;n++){
				incErule(R,TOP,R,n,s,e,newG);
			}
	    }
         }
	}


}
F dirHeight(Tree * t){
   if(t->s==t->e) return 0;
   if(t->nt==ML)
	return dirHeight(t->right);
   if(t->nt==MR)
	return dirHeight(t->left);
   if(t->nt==L&&t->right)//L->L ML
	return dirHeight(t->right)+1;
   if(t->nt==R&&t->right)//R->MR R
	return dirHeight(t->left)+1;
   if((t->nt==L||t->nt==R)&&t->left)
	return dirHeight(t->left);
   if(t->nt==S){
	//dirHeight(
	return 0;
   }
   assert(false);
   return 0;
}
F oneDirBranchiness(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e){
   static F pr=0;
   if((pr = C->get(s,e)->outsideProb[p][pc] 
	* C->get(s,m)->insideProb[l][lc] 
	* C->get(m+1,e)->insideProb[r][rc]) >0){
	   pr*= C->grammar->prob_rule(p,pc,l,lc,r,rc,C->sentence[s],C->sentence[m],C->sentence[e])
	/ C->get(0,C->sentence.size()-1)->insideProb[S][TOP];
	   if(p==L)
		   pr*=-1;
	   if(p==R)
		   pr*=1;
   }
   return pr;
}

F invLogDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e){
   static F pr=0;
   if((pr = C->get(s,e)->outsideProb[p][pc] 
	* C->get(s,m)->insideProb[l][lc] 
	* C->get(m+1,e)->insideProb[r][rc]) >0){
	   pr*= C->grammar->prob_rule(p,pc,l,lc,r,rc,C->sentence[s],C->sentence[m],C->sentence[e])
	/ C->get(0,C->sentence.size()-1)->insideProb[S][TOP];
	   if(p==L)
		   pr*=-log(fabs(s-m)/2+1);
	   if(p==R)
		   pr*=-log(fabs(e-m)/2+1);
   }
   return pr;
}
F sqDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e){
   static F pr=0;
   static F p2=0;
   if((pr = C->get(s,e)->outsideProb[p][pc] 
	* C->get(s,m)->insideProb[l][lc] 
	* C->get(m+1,e)->insideProb[r][rc]) >0){
	   pr*= C->grammar->prob_rule(p,pc,l,lc,r,rc,C->sentence[s],C->sentence[m],C->sentence[e])
	/ C->get(0,C->sentence.size()-1)->insideProb[S][TOP];
	   if(p==L)
		   p2=fabs(s-m)/2;
	   if(p==R)
		   p2=fabs(e-m)/2;
   }
   //cout<<"absDistance( "<<(p==L?'L':'R')<<")= "<<pr<<'\t'<<p2<<endl;
   return pr*p2*p2;
}
F absDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e){
   static F pr=0;
   static F p2=0;
   if((pr = C->get(s,e)->outsideProb[p][pc] 
	* C->get(s,m)->insideProb[l][lc] 
	* C->get(m+1,e)->insideProb[r][rc]) >0){
	   pr*= C->grammar->prob_rule(p,pc,l,lc,r,rc,C->sentence[s],C->sentence[m],C->sentence[e])
	/ C->get(0,C->sentence.size()-1)->insideProb[S][TOP];
	   if(p==L)
		   p2=fabs(s-m)/2;
	   if(p==R)
		   p2=fabs(e-m)/2;
   }
   //cout<<"absDistance( "<<(p==L?'L':'R')<<")= "<<pr<<'\t'<<p2<<endl;
   return pr*p2;
}
F Chart::incrementExpectedCounts2(F (*G)(Chart *,U,U,U,U,U,U,int,int,int)){
	F score=0;
	assert(G);
	U N = sentence.size();
	F p_sent=get(0,N-1)->insideProb[S][TOP];
	assert(p_sent>0);
	ChartPos * pos;
	U gap, s,e,m;
	for(s=0;s<N;s++){
		pos=get(s,s);
		if(even(s)){
			//pr=pos->outsideProb[L][TOP]*grammar->prob_rule(L,TOP,L,0,sentence[s])*pos->insideProb[L][0]/p_sent;
			//grammar->increment_rule(L,TOP,L,0,sentence[s],pr,false);
		}
		else{
			//pr=pos->outsideProb[R][TOP]*grammar->prob_rule(R,TOP,R,0,sentence[s])*pos->insideProb[R][0]/p_sent;
			//grammar->increment_rule(R,TOP,R,0,sentence[s],pr,false);
		}
			
	}
	for (gap = 1; gap < N; gap++){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
		     for (m=s;m<e;m++) {
			if(even(s)&&even(e)){// L parent
				// L -> L ML
				for (U n=1;n<TOP;n++){
					score+=G(this,L,n,L,TOP,ML,n,s,m,e);
				}
				
			}		
			else if(!even(s)&&!even(e)){ //R parent
				// R -> MR R
				for (U n=1;n<TOP;n++){
					score+=G(this,R,n,MR,n,R,TOP,s,m,e);
				}
			}		
//			else if(!even(s)&&even(e)){   //M parent
//				// MLn --> R Ln | n =0,1,2,...,TOP-1
//				// MRn --> Rn L
//				incErule2(ML,TOP-1,R,TOP,L,TOP-1,s,m,e);
//				incErule2(MR,TOP-1,R,TOP-1,L,TOP,s,m,e);
//				for (U n=1;n<TOP;n++){
//					incErule2(ML,n,R,TOP,L,n-1,s,m,e);
//					incErule2(MR,n,R,n-1,L,TOP,s,m,e);
//				}
//			}
//			else if(s==0&&e==N-1){  //S parent
//				//S -> L R
//				incErule2(S,TOP,L,TOP,R,TOP,s,m,e);
//			}		
			
		     }
	     }
//    	     if(even(s)&&even(e)){// L parent
//			// L -> L ML
//			for (U n=1;n<=TOP-1;n++){
//				incErule(L,TOP,L,n,s,e);
//				
//			}
//			
//	     }		
//    	     else if(!even(s)&&!even(e)){ //R parent
//			// R -> MR R
//			for (U n=1;n<=TOP-1;n++){
//				incErule(R,TOP,R,n,s,e);
//			}
//	    }
         }
	}

	return score;
}
F Chart::outside(){
	int N=sentence.size();
	int s,e,gap,m;
	ChartPos * pos=NULL;
	pos=get(0,N-1);
	pos->outsideProb[S][TOP]=1;
	
	if(!(get(0,N-1)->insideProb[S][TOP]>0)){
		for (int i=0;i<N;i++)
			cerr<<grammar->getTagVocab().lookup(sentence[i].tag)<<'_'<<grammar->getWordVocab().lookup(sentence[i].word)<<' ';
		cerr<<endl;

	}
	assert(get(0,N-1)->insideProb[S][TOP]>0);



	for (gap = N-1; gap >=1; gap--){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     //unary:
    	     if(even(s)&&even(e)){// L parent
			//add to outside prob of L^n
			for (U n=1;n<=TOP-1;n++){
				incOutside(L,TOP,L,n,s,e);
			}
	      }		
    	      else if(!even(s)&&!even(e)){ //R parent
			// R -> R
			for (U n=1;n<=TOP-1;n++)
				incOutside(R,TOP,R,n,s,e);
	     }		
	     //binary
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
		     for (m=s;m<e;m++) {
			if(even(s)&&even(e)){// L parent
				// L -> L ML
				//add to outside prob of L^n
				incOutside(L,TOP-1,L,TOP,ML,TOP-1,s,m,e);
				for (U n=1;n<TOP-1;n++){
					incOutside(L,n,L,TOP,ML,n,s,m,e);
				}
				
			}		
			else if(!even(s)&&!even(e)){ //R parent
				// R -> MR R
				incOutside(R,TOP-1,MR,TOP-1,R,TOP,s,m,e);//continue generating
				for (U n=1;n<TOP-1;n++){
					incOutside(R,n,MR,n,R,TOP,s,m,e);
				}
			}		
			else if(!even(s)&&even(e)){   //M parent
				// MLn --> R Ln | n =0,1,2,...,TOP-1
				// MRn --> Rn L
				incOutside(ML,TOP-1,R,TOP,L,TOP-1,s,m,e);
				incOutside(MR,TOP-1,R,TOP-1,L,TOP,s,m,e);
				for (U n=1;n<TOP;n++){
					incOutside(ML,n,R,TOP,L,n-1,s,m,e);
					incOutside(MR,n,R,n-1,L,TOP,s,m,e);
				}
			}
			else if(s==0&&e==N-1){  //S parent
				//S -> L R
				incOutside(S,TOP,L,TOP,R,TOP,s,m,e);
			}
		     }
		}		
			
         }
	}
	for(s=0;s<N;s++){
		pos=get(s,s);
		if(even(s)){
			incOutside(L,TOP,L,0,s,s);
			pos->outsideProb[UL][TOP]+=grammar->prob_rule(L,0,sentence[s])*pos->outsideProb[L][0];
		}
		else{
			incOutside(R,TOP,R,0,s,s);
			pos->outsideProb[UR][TOP]+=grammar->prob_rule(R,0,sentence[s])*pos->outsideProb[R][0];
		}

	}
	/*
	*/
	for(s=0;s<N-2;s+=1){
		if(get(s,s)->outsideProb[UL][TOP]!=get(s+1,s+1)->outsideProb[UR][TOP])
			assert(fabs(log(get(s,s)->outsideProb[UL][TOP])-log(get(s+1,s+1)->outsideProb[UR][TOP]))<.0001);
	}
	assert(fabs(log(get(0,0)->outsideProb[UL][TOP])-log(get(1,1)->outsideProb[UR][TOP]))<.0001);
	assert(fabs(log(get(0,0)->outsideProb[UL][TOP])-log(get(0,N-1)->insideProb[S][TOP]))<.0001);
	return get(0,0)->outsideProb[UL][TOP];
}

Chart::TFPair Chart::viterbiTree(){
	size_t N=sentence.size();
	size_t s,e,gap,m;
	ChartPos * pos=NULL;
	for(s=0;s<N;s++){
		pos=get(s,s);
		if(even(s)){
			pos->viterbiProb[UL][TOP]=1;
			incViterbi(L,0,UL,TOP,s);
			incViterbi(L,TOP,L,0,s,s);
			//pos->viterbiProb[L][0]=grammar->prob_rule(L,0,sentence[s]);
			//pos->viterbiProb[L][TOP]=grammar->prob_rule(L,TOP,0,sentence[s])*pos->viterbiProb[L][0];
		}
		else{
			pos->viterbiProb[UR][TOP]=1;
			incViterbi(R,0,UR,TOP,s);
			incViterbi(R,TOP,R,0,s,s);
			//pos->viterbiProb[R][0]=grammar->prob_rule(R,0,sentence[s]);
			//pos->viterbiProb[R][TOP]=grammar->prob_rule(R,TOP,0,sentence[s])*pos->viterbiProb[R][0];
		}
			
	}
	for (gap = 1; gap < N; gap++){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
		     for (m=s;m<e;m++) {
			//cout<<"s,m,e = "<<s<<'\t'<<m<<'\t'<<e<<endl;
			if(even(s)&&even(e)){// L parent
				// L -> L ML
				incViterbi(L,TOP-1,L,TOP,ML,TOP-1,s,m,e);
				for (U n=1;n<TOP-1;n++){
					incViterbi(L,n,L,TOP,ML,n,s,m,e);
				}
				
			}		
			else if(!even(s)&&!even(e)){ //R parent
				// R -> MR R
				incViterbi(R,TOP-1,MR,TOP-1,R,TOP,s,m,e);//continue generating
				for (U n=1;n<TOP-1;n++){
					incViterbi(R,n,MR,n,R,TOP,s,m,e);
				}
			}		
			else if(!even(s)&&even(e)){   //M parent
				// MLn --> R Ln | n =0,1,2,...,TOP-1
				// MRn --> Rn L
				incViterbi(ML,TOP-1,R,TOP,L,TOP-1,s,m,e);
				incViterbi(MR,TOP-1,R,TOP-1,L,TOP,s,m,e);
				for (U n=1;n<TOP;n++){
					incViterbi(ML,n,R,TOP,L,n-1,s,m,e);
					incViterbi(MR,n,R,n-1,L,TOP,s,m,e);
				}
			}
			else if(s==0&&e==N-1){  //S parent
				//S -> L R
				incViterbi(S,TOP,L,TOP,R,TOP,s,m,e);
			}		
			
		     }
		}
    	     if(even(s)&&even(e)){// L parent
			// L -> L ML
			for (U n=1;n<=TOP-1;n++){
				incViterbi(L,TOP,L,n,s,e);
				
			}
			
	     }		
    	     else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			for (U n=1;n<=TOP-1;n++){
				incViterbi(R,TOP,R,n,s,e);
			}
	    }
         }
	}
	if(pos->viterbiProb[S][TOP]==0)
		return TFPair(NULL,0);
	else
		return TFPair(extractTree(pos,S,TOP),pos->viterbiProb[S][TOP]);
}
Tree * Chart::sampleTree(ChartPos * pos,U p,U pc){
	U N=sentence.size();
	if(!pos)
		pos=get(0,N-1);
	//cout<<"sampleTree ("<<pos->s<<','<<pos->e<<") "<<p<<'\t'<<pc<<endl;
	Tree * tree = new Tree(p,pc,getHead(p,pos->s,pos->e),pos->s,pos->e,NULL,NULL,sentence);
	assert(tree);
	if(p==UL||p==UR) return tree;
	if(tree->s==tree->e){
		if(p==L||p==R){
			if(pc==TOP){
				//assert(pos->viterbiRule[p][pc].first==p);
				//assert(pos->viterbiRuleC[p][pc].first==0);
				tree->left = extractTree(pos,p,0);
			}
			else if(pc==0){
				//assert(pos->viterbiRule[p][pc].first==(p==L?UL:UR));
				//assert(pos->viterbiRuleC[p][pc].first==TOP);
				tree->left = extractTree(pos,(p==L?UL:UR),TOP);
			}

		}
		else assert(false);
		return tree;
	}
	if((p==L||p==R)&&pc==TOP){
		F total = pos->insideProb[p][pc];
		assert(total>0);
		F threshold=random1()*total;
		F probsofar=0;
		for (U n=0;n<TOP;n++){
			if(pos->insideProb[p][n]){
				F pr_rule=grammar->prob_rule(p,TOP,p,n,sentence[(p==R)?pos->s:pos->e]);
				F pr_inside=pr_rule
					* pos->insideProb[p][n];

				probsofar+=pr_inside;
				if(probsofar>=threshold){
					assert(pr_rule>0);
					tree->left=sampleTree(pos,p,n);
					break;
				}

			}
		}
	}
	else{
		F total = pos->insideProb[p][pc];
		assert(total>0);
		F threshold=random1()*total;
		//cout<<"threshold = "<<threshold<<'\t'<<total<<endl;
		F probsofar=0;
		F pr=0;
		U s=pos->s;
		U e=pos->e;
		     for (U m=s;m<e;m++) {
			if(even(s)&&even(e)){// L parent
				// L -> L ML
				pr=getInside(L,TOP-1,L,TOP,ML,TOP-1,s,m,e);
				if((probsofar+=pr)>threshold){
					//cout<<"picked L,"<<m<<" "<<endl;
					tree->left=sampleTree(get(s,m),L,TOP);
					tree->right=sampleTree(get(m+1,e),ML,TOP-1);
					return tree;
				}
				for (U n=1;n<TOP-1;n++){
					pr=getInside(L,n,L,TOP,ML,n,s,m,e);
					if((probsofar+=pr)>threshold){
						//cout<<"picked L,"<<m<<" "<<endl;
						tree->left=sampleTree(get(s,m),L,TOP);
						tree->right=sampleTree(get(m+1,e),ML,n);
						return tree;
					}
				}
				
			}		
			else if(!even(s)&&!even(e)){ //R parent
				// R -> MR R
				pr=getInside(R,TOP-1,MR,TOP-1,R,TOP,s,m,e);//continue generating
				if((probsofar+=pr)>threshold){
					//cout<<"picked R,"<<m<<" "<<endl;
					tree->left=sampleTree(get(s,m),MR,TOP-1);
					tree->right=sampleTree(get(m+1,e),R,TOP);
						return tree;
				}
				for (U n=1;n<TOP-1;n++){
					pr=getInside(R,n,MR,n,R,TOP,s,m,e);
					if((probsofar+=pr)>threshold){
						//cout<<"picked R,"<<m<<" "<<endl;
						tree->left=sampleTree(get(s,m),MR,n);
						tree->right=sampleTree(get(m+1,e),R,TOP);
						return tree;
					}
				}
			}		
			else if(!even(s)&&even(e)){   //M parent
				// MLn --> R Ln | n =0,1,2,...,TOP-1
				// MRn --> Rn L
				pr=getInside(ML,TOP-1,R,TOP,L,TOP-1,s,m,e);
				if((probsofar+=pr)>threshold){
					//cout<<"picked ML,"<<m<<" "<<endl;
					tree->left=sampleTree(get(s,m),R,TOP);
					tree->right=sampleTree(get(m+1,e),L,TOP-1);
						return tree;
				}
				pr=getInside(MR,TOP-1,R,TOP-1,L,TOP,s,m,e);
				if((probsofar+=pr)>threshold){
					//cout<<"picked MR,"<<m<<" "<<endl;
					tree->left=sampleTree(get(s,m),R,TOP-1);
					tree->right=sampleTree(get(m+1,e),L,TOP);
						return tree;
				}
				for (U n=1;n<TOP;n++){
					pr=getInside(ML,n,R,TOP,L,n-1,s,m,e);
					if((probsofar+=pr)>threshold){
						//cout<<"picked ML,"<<m<<" "<<endl;
						tree->left=sampleTree(get(s,m),R,TOP);
						tree->right=sampleTree(get(m+1,e),L,n-1);
						return tree;
					}
					pr=getInside(MR,n,R,n-1,L,TOP,s,m,e);
					if((probsofar+=pr)>threshold){
						//cout<<"picked MR,"<<m<<" "<<endl;
						tree->left=sampleTree(get(s,m),R,n-1);
						tree->right=sampleTree(get(m+1,e),L,TOP);
						return tree;
					}
				}
			}
			else if(s==0&&e==N-1){  //S parent
				//S -> L R
				pr=getInside(S,TOP,L,TOP,R,TOP,s,m,e);
				if((probsofar+=pr)>threshold){
					//cout<<"picked S,"<<m<<endl;
					tree->left=sampleTree(get(s,m),L,TOP);
					tree->right=sampleTree(get(m+1,e),R,TOP);
						return tree;
				}
			}		
			
		     }
//    	     if(even(s)&&even(e)){// L parent
//			// L -> L ML
//			for (U n=1;n<=TOP-1;n++){
//				pr=getInside(L,TOP,L,n,s,e);
//				if(probsofar+=pr>threshold){
//					tree->left=sampleTree(get(s,e),L,n);
//				}
//				
//			}
//			
//	     }		
//    	     else if(!even(s)&&!even(e)){ //R parent
//			// R -> MR R
//			for (U n=1;n<=TOP-1;n++){
//				pr=getInside(R,TOP,R,n,s,e);
//				if(probsofar+=pr>threshold){
//					tree->left=sampleTree(get(s,e),R,n);
//				}
//			}
//	    }
	}
	return tree;
}
Tree * Chart::extractTree(ChartPos * pos,U p,U pc){
	assert(pos);
	Tree * tree = new Tree(p,pc,getHead(p,pos->s,pos->e),pos->s,pos->e,NULL,NULL,sentence);
	assert(tree);
	if(p==UL||p==UR) return tree;
	if(tree->s==tree->e){
		if(p==L||p==R){
			if(pc==TOP){
				tree->left = extractTree(pos,p,0);
			}
			else if(pc==0){
				tree->left = extractTree(pos,(p==L?UL:UR),TOP);
			}

		}
		else assert(false);
		return tree;
	}
	if((p==L||p==R)&&pc==TOP){
		assert(pos->viterbiRule[p][pc].second==((U)-1));
		tree->left=extractTree(pos->viterbiPos[p][pc].first,pos->viterbiRule[p][pc].first,pos->viterbiRuleC[p][pc].first);
	}
	else{
		tree->left=extractTree(pos->viterbiPos[p][pc].first,pos->viterbiRule[p][pc].first,pos->viterbiRuleC[p][pc].first);
		tree->right=extractTree(pos->viterbiPos[p][pc].second,pos->viterbiRule[p][pc].second,pos->viterbiRuleC[p][pc].second);
	}
	return tree;
}
F Chart::inside(bool debugging){

	if(debugging) cout<<"\nInside:"<<endl;
	size_t N=sentence.size();
	size_t s,e,gap,m;
	ChartPos * pos=NULL;
	for(s=0;s<N;s++){
		pos=get(s,s);
		if(even(s)){
			pos->insideProb[L][0]=grammar->prob_rule(L,0,sentence[s]);
			pos->insideProb[UL][TOP]=1;
			pos->insideProb[L][TOP]=grammar->prob_rule(L,TOP,L,0,sentence[s])*pos->insideProb[L][0];
			if(debugging) printInside(L,0,s,s);
			if(debugging) printInside(L,TOP,s,s);
		}
		else{
			pos->insideProb[R][0]=grammar->prob_rule(R,0,sentence[s]);
			
			pos->insideProb[UR][TOP]=1;
			pos->insideProb[R][TOP]=grammar->prob_rule(R,TOP,R,0,sentence[s])*pos->insideProb[R][0];
			if(debugging) printInside(R,0,s,s);
			if(debugging) printInside(R,TOP,s,s);
		}
			
	}
	for (gap = 1; gap < N; gap++){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
	     for (m=s;m<e;m++) {
		if(even(s)&&even(e)){// L parent
			// L -> L ML
			incInside(L,TOP-1,L,TOP,ML,TOP-1,s,m,e);
			for (U n=1;n<TOP-1;n++){
				incInside(L,n,L,TOP,ML,n,s,m,e);
			}
			
		}		
		else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			incInside(R,TOP-1,MR,TOP-1,R,TOP,s,m,e);//continue generating
			for (U n=1;n<TOP-1;n++){
				incInside(R,n,MR,n,R,TOP,s,m,e);
			}
		}		
		else if(!even(s)&&even(e)){   //M parent
			// MLn --> R Ln | n =0,1,2,...,TOP-1
			// MRn --> Rn L
			incInside(ML,TOP-1,R,TOP,L,TOP-1,s,m,e);
			incInside(MR,TOP-1,R,TOP-1,L,TOP,s,m,e);
			for (U n=1;n<TOP;n++){
				incInside(ML,n,R,TOP,L,n-1,s,m,e);
				incInside(MR,n,R,n-1,L,TOP,s,m,e);
			}
		}
		else if(s==0&&e==N-1){  //S parent
			//S -> L R
			incInside(S,TOP,L,TOP,R,TOP,s,m,e);
		}		
		
	     }
		}
    	     if(even(s)&&even(e)){// L parent
			// L -> L ML
			for (U n=1;n<=TOP-1;n++){
				incInside(L,TOP,L,n,s,e);
				
			}
			
	     }		
    	     else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			for (U n=1;n<=TOP-1;n++){
				incInside(R,TOP,R,n,s,e);
			}
	    }
	    //print:
    		if(even(s)&&even(e)){// L parent
			// L -> L ML
			for (U n=1;n<=TOP;n++){
				if(debugging) printInside(L,n,s,e);
			}
			
		}		
    		else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			for (U n=1;n<=TOP;n++){
				if(debugging) printInside(R,n,s,e);
			}
		}		
    		else if(!even(s)&&even(e)){   //M parent
			// MLn --> R Ln | n =0,1,2,...,TOP-1
			// MRn --> Rn L
			for (U n=1;n<TOP;n++){
				if(debugging) printInside(ML,n,s,e);
			}
			for (U n=1;n<TOP;n++){
				if(debugging) printInside(MR,n,s,e);
			}
		}
		else if(s==0&&e==N-1){  //S parent
			//S -> L R
			if(debugging) printInside(S,TOP,s,e);
		}		
    	     }//for all s
		
         }//for all gap
	assert(get(0,N-1)->insideProb[S][TOP]>=0);
	if(get(0,N-1)->insideProb[S][TOP]>1){
		cout<<"psent="<<get(0,N-1)->insideProb[S][TOP]<<endl;
		assert(get(0,N-1)->insideProb[S][TOP]<=1);
	}
	//outside();
	//assert(get(0,N-1)->insideProb[S][TOP]>0);
	return get(0,N-1)->insideProb[S][TOP];
}
/*
Chart::TFPair Chart::sampleNewTree(U par,U pc,U s,U e){
	Tree * tree = new Tree(par,pc,getHead(par,s,e),s,e,NULL,NULL);
	F pr=1;
	TFPair tfpair_left;
	TFPair tfpair_right;
	if(s==e){
	   if(par==L||par==R){
		   if(pc==TOP){
			   tfpair_left=sampleNewTree(par,0,s,e);
			   tree->left=tfpair_left.tree;
			   pr*=tfpair_left.prob;
			   pr*=grammar->prob_rule(par,TOP,0,sentence[s]);

		   }
		   else{
			   U left=((par==L)?UL:UR);
			   assert(pc==0);
			   tfpair_left=sampleNewTree(left,TOP,s,e);
			   tree->left=tfpair_left.tree;
			   pr*=tfpair_left.prob;
			   pr*=grammar->prob_rule(par,0,sentence[s]);
		   }
	   }
	   else assert(par==UL||par==UR);
	   //cout<<"s==e=="<<s<<" par="<<grammar->translate[par]<<" pr="<<pr<<endl; 
	   return TFPair(tree,pr);
	}
	F parentprob=get(s,e)->insideProb[par][pc];
	F threshold=random1()*parentprob;
	F probsofar=0;
	assert(parentprob>0);
        U m;
	U left=-1,right=-1,lc=TOP,rc=TOP;
	probsofar=0;
	//pick valency class
	if(pc==TOP){
		if(par==L||par==R){
			left=par;
		   //L -> L^n, R -> R^n	
		   for(U n=0;n<TOP;n++){
			F pr_rule=0;
			if(get(s,e)->insideProb[left][n]){
				pr_rule=grammar->prob_rule(par,TOP,n,sentence[(par==R)?s:e]);
				F pr_inside=pr_rule
					* get(s,e)->insideProb[left][n];

				probsofar+=pr_inside;
				if(probsofar>=threshold){
					assert(pr_rule>0);
					tfpair_left=sampleNewTree(left,n,s,e);
					tree->left=tfpair_left.tree;
					pr*=tfpair_left.prob;
					pr*=pr_rule;
					return TFPair(tree,pr);
				}
			}
		  }
			
		}
	}
       for (m=s;m<e;m++) {
		if((pc==TOP-1)&&(par==ML||par==MR)){
				left=R;
				right=L;
				if(par==ML){
					lc=TOP;
					rc=TOP-1;
				}
				else if(par==MR){
					lc=TOP-1;
					rc=TOP;
				}
				else assert(false);
				if(get(s,m)->insideProb[left][lc]>0&&get(m+1,e)->insideProb[right][rc]>0){
					F pr_rule=grammar->prob_rule(par,pc,left,lc,right,rc,sentence[s],sentence[m],sentence[e]);	
					F pr_inside=pr_rule
						* get(s,m)->insideProb[left][lc]
						* get(m+1,e)->insideProb[right][rc];
					probsofar+=pr_inside;
					if(probsofar>=threshold){
						assert(pr_rule>0);
						tfpair_left=sampleNewTree(left,lc,s,m);
						tfpair_right=sampleNewTree(right,rc,m+1,e);

						tree->left=tfpair_left.tree;
						tree->right=tfpair_right.tree;

						pr*=tfpair_left.prob*tfpair_right.prob;
						pr*=pr_rule;
						return TFPair(tree,pr);
					}

				}
			
			
		}
		if(pc<TOP&&(par==L||par==R||par==ML||par==MR)){
				if(par==L){
					left=L;
					lc=TOP;
					right=ML;
					rc=pc;
				}
				else if(par==R){
					left=MR;
					lc=pc;
					right=R;
					rc=TOP;
				
				}
				else if(par==ML){
					left=R;
					lc=TOP;
					right=L;
					rc=pc-1;
				}
				else if(par==MR){
					left=R;
					lc=pc-1;
					right=L;
					rc=TOP;
				}
				if(get(s,m)->insideProb[left][lc]>0&&get(m+1,e)->insideProb[right][rc]>0){
					F pr_rule=grammar->prob_rule(par,pc,left,lc,right,rc,sentence[s],sentence[m],sentence[e]);	
					F pr_inside=pr_rule
						* get(s,m)->insideProb[left][lc]
						* get(m+1,e)->insideProb[right][rc];
					probsofar+=pr_inside;
					if(probsofar>=threshold){
						assert(pr_rule>0);
						tfpair_left=sampleNewTree(left,lc,s,m);
						tfpair_right=sampleNewTree(right,rc,m+1,e);

						tree->left=tfpair_left.tree;
						tree->right=tfpair_right.tree;

						pr*=tfpair_left.prob*tfpair_right.prob;
						pr*=pr_rule;
						return TFPair(tree,pr);
					}

				}
		}
		else if(par==S){
			left=L;
			lc=TOP;
			right=R;
			rc=TOP;
			if(get(s,m)->insideProb[left][lc]>0&&get(m+1,e)->insideProb[right][rc]>0){
				F pr_rule=grammar->prob_rule(par,pc,left,lc,right,rc,sentence[s],sentence[m],sentence[e]);	
				F pr_inside=pr_rule
					* get(s,m)->insideProb[left][lc]
					* get(m+1,e)->insideProb[right][rc];
				probsofar+=pr_inside;
				if(probsofar>=threshold){
					assert(pr_rule>0);
					tfpair_left=sampleNewTree(left,lc,s,m);
					tfpair_right=sampleNewTree(right,rc,m+1,e);

					tree->left=tfpair_left.tree;
					tree->right=tfpair_right.tree;

					pr*=tfpair_left.prob*tfpair_right.prob;
					pr*=pr_rule;
					return TFPair(tree,pr);
				}

			}

		}
		else assert(false);



        }
	cout<<"probssofar = "<<probsofar<<" of "<< parentprob <<endl;
	assert(false);
	return TFPair(NULL,0);	
}
*/
void Chart::constructHarmonicChart(){
	U N = sentence.size();
	F p_sent=get(0,N-1)->insideProb[S][TOP];
	assert(p_sent>0);
	ChartPos * pos;
	U gap, s,e,m;
	for (gap = 1; gap < N; gap++){
          for (s=0; s+gap<N; s++) {
    	     e = s + gap;
	     pos=get(s,e);
	     if((s==0&&e==N-1)||!(even(s)&&!even(e))){
		     for (m=s;m<e;m++) {
			if(even(s)&&even(e)){// L parent
				// L -> L ML
				for (U n=1;n<TOP;n++){
					incHarmonicErule(L,n,L,TOP,ML,n,s,m,e);
				}
				
			}		
			else if(!even(s)&&!even(e)){ //R parent
				// R -> MR R
				for (U n=1;n<TOP;n++){
					incHarmonicErule(R,n,MR,n,R,TOP,s,m,e);
				}
			}		
			else if(!even(s)&&even(e)){   //M parent
			}
			else if(s==0&&e==N-1){  //S parent
				//S -> L R
				incHarmonicErule(S,TOP,L,TOP,R,TOP,s,m,e);
			}		
			
		     }
	     }
    	     if(even(s)&&even(e)){// L parent
			// L -> L ML
			//for (U n=1;n<=TOP-1;n++){
			//	incHarmonicErule(L,TOP,L,n,s,e);
			//	
			//}
			
	     }		
    	     else if(!even(s)&&!even(e)){ //R parent
			// R -> MR R
			//for (U n=1;n<=TOP-1;n++){
			//	incHarmonicErule(R,TOP,R,n,s,e);
			//}
	    }
         }
	}



}
F Chart::prob_rule_harmonic(U par,U pc, U lchild, U lc, U rchild,U rc, U s,U m, U e){
	// L -> L ML
	F pr=1;
	if(par==R||par==L){
	    //s --> m
	    int head = (par==R?s/2:e/2);
	    int arg = (par==R?m+1:m)/2;
	    
	    assert(arg!=head);
	    F dist=abs(arg-head);
	    F total=0;
            for(int j=0;j<(int)sentence.size()/2;j++){
		if(j!=arg)
			total+=1/abs(j-arg);
	    }
	    pr*=(1.0-2.0/sentence.size())/(dist)/total;
	}
	// ML --> R L
	else if(par==ML||par==MR){
	   //prob stopping left \propto number of things headed by par_pc without left children, divided by number of things headed by par_pc with or without left children
	   /*
	   U head = par==ML?e/2:s/2;
	   U arg = m/2;
	   U dist=abs(arg-head);
	   F total=0;
           for(j=0;j<sentence.size()/2;j++){
		if(j!=arg)
			total+=1/abs(j-arg);
	   }
	   F p_nonstop=(1.0-2.0/sentence.size())/(dist)/total;
	   F pstop=1.0-p_nonstop;
	   if(pc==TOP-1)//ML^Np -->R L^Np | R L^N-1
		if(rc==TOP-1)
		   pr*=p_nonstop;
		else{
		   assert(rc==TOP-2);
		   pr*=pstop;
		}
	   */
	}
	else if(par==S){
	  assert(lchild==L && rchild==R);
	   pr=2.0/sentence.size();

	}
	else assert(false);
	//S -> L R
	//cout<<"prob_rule("<<translate[par]<<pc<<" --> "<<translate[lchild]<<lc<<' '<<translate[rchild]<<rc<<'\t'<<vocab.lookup(m)<<") =\t"<<pr<<endl;
	assert(pr>0);
	return pr;

}
