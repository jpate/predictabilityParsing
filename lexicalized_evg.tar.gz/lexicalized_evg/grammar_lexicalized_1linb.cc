/*
 * Copyright William Headden 2009
 *
*/

#include"grammar_lexicalized_1linb.h"
#include<math.h>
U Grammar_lexicalized_1linb::NUMSTOP=2;
U Grammar_lexicalized_1linb::NUMARG=2;
string Grammar_lexicalized_1linb::type_id="Grammar_lexicalized_1linb";

Grammar_lexicalized_1linb::Grammar_lexicalized_1linb(MetaGrammar * mg):Grammar(mg),
	aw_given_arg(),
	numTagMixBuckets(8),
	tagBucket(numTagMixBuckets,mg->tagCount),
	numWordTagMixBuckets(10),
	wordTagBucket(numWordTagMixBuckets,mg->tagWordCount),
	S_root_att(this,getArgs(),getWords(),getTagVocab(),getWordVocab()),
	L_att(this,getArgs(),getWords(),mg->stop_symbols,"L",getTagVocab(),getWordVocab()),
	R_att(this,getArgs(),getWords(),mg->stop_symbols,"R",getTagVocab(),getWordVocab())
{
	string id="aw_given_argt_";
	foreach(UFList,arg,getArgs()){
		string ida=id+getTagVocab().lookup(arg->first);
		aw_given_arg.insert(pair<U,MD*>(arg->first,new MD(getWords().size(),getWords(),ida)));
	}
	setCollapsed(false,true,true);
	assert(false);
}
Grammar_lexicalized_1linb::Grammar_lexicalized_1linb(Grammar_uvg_6lin * model0, MetaGrammar * mg)://,W_MD & aw_given_arg_real):
	Grammar(mg),
	numTagMixBuckets(8),
	tagBucket(numTagMixBuckets,mg->tagCount),
	numWordTagMixBuckets(10),
	aw_given_arg(),
	wordTagBucket(numWordTagMixBuckets,mg->tagWordCount),
	S_root_att(this,getArgs(),getWords(),getTagVocab(),getWordVocab()),
	L_att(this,getArgs(),getWords(),mg->stop_symbols,"L",getTagVocab(),getWordVocab()),
	R_att(this,getArgs(),getWords(),mg->stop_symbols,"R",getTagVocab(),getWordVocab())
{
	setCollapsed(false,false,false);
	string id="aw_given_argt_";
	foreach(UFList,arg,getArgs()){
		string ida=id+getTagVocab().lookup(arg->first);
		aw_given_arg.insert(pair<U,MD*>(arg->first,new MD(getWords().size(),getWords(),ida)));
		get_aw_given_arg(arg->first)->reestimate(MD::VAR,*get_aw_given_arg(arg->first));//initialize to uniform
		add_nonmix_dist(get_aw_given_arg(arg->first));
	}
	//initialize others from model0
	get_arg_given_root()->initialize(model0->get_arg_given_root());
	add_nonmix_dist(get_arg_given_root());
	typedef pair<U,U> UPair;
	cforeach(UFList,iter,getArgs()){
		for(U n=0;n<NUMSTOP;n++){
			L_att.get_stop_given_head_valence(iter->first,n)->initialize(*(model0->L_att.get_stop_given_head_valence(iter->first,n)));
			R_att.get_stop_given_head_valence(iter->first,n)->initialize(*(model0->R_att.get_stop_given_head_valence(iter->first,n)));
		}
	}
	cforeach(UFList,iter,getArgs()){
		get_aw_given_arg(iter->first)->setCollapsed(false);//initialize(*(model0->get_aw_given_arg(iter->first)));
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_head_valence(iter->first,n)->initialize(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_head_valence(iter->first,n)->initialize(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
			L_att.get_arg_mix_given_head_valence(iter->first,n)->initialize(
				*(model0->L_att.get_arg_mix_given_head_valence(iter->first,n)));
			R_att.get_arg_mix_given_head_valence(iter->first,n)->initialize(
				*(model0->R_att.get_arg_mix_given_head_valence(iter->first,n)));

			cforeach(UFList,aw,getWordList(iter->first)){
				//this is newly introduced, so we will init from the backoff distribution, and then let the data break ties
				L_att.get_arg_given_head_valence_hw(iter->first,n,aw->first)->initialize(*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
				R_att.get_arg_given_head_valence_hw(iter->first,n,aw->first)->initialize(*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
				L_att.get_arg_mix_given_head_valence_hw(iter->first,n,aw->first)->initToPrior(MD::VAR);
				R_att.get_arg_mix_given_head_valence_hw(iter->first,n,aw->first)->initToPrior(MD::VAR);
			}
		}

	}
	for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
		L_att.get_arg_given_valence(n)->initialize(
			*(model0->L_att.get_arg_given_valence(n)));
		R_att.get_arg_given_valence(n)->initialize(
			*(model0->R_att.get_arg_given_valence(n)));
	}
	

}
F Grammar_lexicalized_1linb::increment_rule(U par,U pc, U l,U lc, const word_type & head,F weight,bool delete_table){
	assert(pc==TOP);
	assert(lc<TOP);
	// If lc==0, then 1 stop, no nonstops
	// if lc==1, then 1 stop, 1 nonstop
	// if lc==2, then 1 stop, 2 nonstop...
	// if lc==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}
			
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}

	}
	else assert(false);
	return pr;
}

F Grammar_lexicalized_1linb::increment_rule(U par, U pc,U lchild,U lc, U rchild, U rc, const word_type & s,const word_type & m, const word_type & e,F weight,bool delete_table){
    F pr=1;
	//assert(weight==1||weight==-1);
	if(weight==1)assert(!delete_table);
	
	// L^pc -> L ML^pc
	if(par==L){
	    assert(pc==rc);
	    assert(lc==TOP);
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(lchild==L&&rchild==ML);
	    //pr*=L_att.get_arg_given_head(head,pc)->insert(arg,weight,delete_table);
	    //pr*=L_att.arg_given_head_inc(head,pc,arg,weight);
	    pr*=L_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=L_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(pc==lc);
	    assert(rc==TOP);
	    assert(lchild==MR&&rchild==R);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    //pr*=R_att.arg_given_head_inc(head,pc,arg,weight);
	    pr*=R_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=R_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(rc==TOP-1||rc==TOP-2);
  	   
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }


	}
	// MR --> R L
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(lc==TOP-1||lc==TOP-2);
	   assert(lchild==R&&rchild==L);
	   assert(rc==TOP);
	   if(pc==TOP-1){
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }

	}
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_inc(m.tag,weight);
	  pr*=  S_root_att.aw_given_root_arg_inc(m.tag,m.word,weight);
	}
	//S -> L R
    return pr;
}
/*
F Grammar_lexicalized_1linb::logKLPosteriorPrior(){
	//assert(count0);
	typedef ExtendedHashCount<U,U,F> ECounter;
	typedef HashCount<U,F> Counter;
	typedef pair<U,U> UPair;
	F log_p=0;
	{
		log_p+=S_root_att.KLQ_P();
	}

	cforeach(UFList,iter,getArgs()){
		log_p+=get_aw_given_arg(iter->first)->KLQ_P();
		for(U n=0;n<NUMSTOP;n++){
			log_p+=L_att.get_stop_given_head_valence(iter->first,n)->KLQ_P();
			log_p+=R_att.get_stop_given_head_valence(iter->first,n)->KLQ_P();
		}
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			log_p+=L_att.get_arg_given_head_valence(iter->first,n)->KLQ_P();
			log_p+=R_att.get_arg_given_head_valence(iter->first,n)->KLQ_P();
			log_p+=L_att.get_arg_mix_given_head_valence(iter->first,n)->KLQ_P();
			log_p+=R_att.get_arg_mix_given_head_valence(iter->first,n)->KLQ_P();
			cforeach(UFList,aw,getWordList(iter->first)){
				log_p+=L_att.get_arg_given_head_valence_hw(iter->first,n,aw->first)->KLQ_P();
				log_p+=R_att.get_arg_given_head_valence_hw(iter->first,n,aw->first)->KLQ_P();
				log_p+=L_att.get_arg_mix_given_head_valence_hw(iter->first,n,aw->first)->KLQ_P();
				log_p+=R_att.get_arg_mix_given_head_valence_hw(iter->first,n,aw->first)->KLQ_P();
			}
		}
	}
	for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
		log_p+=L_att.get_arg_given_valence(n)->KLQ_P();
		log_p+=R_att.get_arg_given_valence(n)->KLQ_P();
	}
	return log_p;
}
*/
F Grammar_lexicalized_1linb::prob_rule(U par,U pc,U l,U lc, const word_type & head){
	assert(pc==TOP);
	assert(lc<TOP);
	assert(par==l);
	// If pc2==0, then 1 stop, no nonstops
	// if pc2==1, then 1 stop, 1 nonstop
	// if pc2==2, then 1 stop, 2 nonstop...
	// if pc2==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);

	}
	else assert(false);
	assert(pr<=1);
        return pr;
}

F Grammar_lexicalized_1linb::prob_rule(U par,U pc, U lchild, U lc, U rchild,U rc, const word_type & s,const word_type & m,const word_type & e){
	// L -> L ML
	assert(pc>0);
	assert(pc<NUMVAL);
	assert(lc<NUMVAL);
	assert(rc<NUMVAL);
	F pr=1;
	if(par==L){
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(pc==rc);
	    assert(lc==TOP);
	    assert(lchild==L&&rchild==ML);
	    pr*=L_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=L_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(lchild==MR&&rchild==R);
	    assert(pc==lc);
	    assert(rc==TOP);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    //pr*=R_att.arg_given_head_prob(head,pc,arg);
	    pr*=R_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=R_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(pc-1==rc||pc==rc);
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//ML^Np -->R L^Np | R L^N-1
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
           }
	}
	// MR --> UR L
	// MR --> MR M
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(pc-1==lc||pc==lc);
	   assert(rc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//MR^Np -->R^Np L | R^N-1 L
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
	   }
	}
	// M --> R L 
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_prob(m.tag);
	  pr*=  S_root_att.aw_given_root_arg_prob(m.tag,m.word);

	}
	else assert(false);
	//S -> L R
	assert(pr<=1);
	return pr;

}
void Grammar_lexicalized_1linb::write(ostream & out){
	out<<"Grammar: "<<endl;
	out<<"left:"<<endl;
	L_att.write(out);
	out<<"right:"<<endl;
	R_att.write(out);
}
void Grammar_lexicalized_1linb::AttDist::write(ostream & out){}
MD * Grammar_lexicalized_1linb::AttDist::get_stop_given_head_valence(U  h,U v){ 
	if(v>=NUMSTOP) v=NUMSTOP-1;//cap valence
	return getMD(h,v,stop_given_head_valence);
}
F Grammar_lexicalized_1linb::AttDist::stop_given_head_valence_hw_prob(U h,U v, U hw,U arg){
	return get_stop_given_head_valence(h,v)->prob(arg);
}
F Grammar_lexicalized_1linb::AttDist::stop_given_head_valence_hw_inc(U h,U v, U hw,U arg,F weight){
	return get_stop_given_head_valence(h,v)->insert(arg,weight,false);
}
F Grammar_lexicalized_1linb::AttDist::arg_given_head_valence_hw_inc(U h,U v,U hw, U arg,F weight){
	assert(v>0);
	U size=2;
	//MD * md[size];
	MD * md0 = get_arg_given_head_valence_hw(h,v,hw);
	F md1Prob = arg_given_head_valence_prob(h,v,arg);
	MD * mix_dist=get_arg_mix_given_head_valence_hw(h,v,hw);
	F mix[2]= {mix_dist->prob(nobackoffToHeadValence.first),mix_dist->prob(backoffToHeadValence.first)};
	F total=0;
	F probTrans[size];
	{
		probTrans[0]=md0->prob(arg)*mix[0];
		total+=probTrans[0];

		probTrans[1]=md1Prob*mix[1];
		total+=probTrans[1];
	}
	if(total==0) total=1;//in case there is zero mass

	{
		md0->insert(arg,weight*probTrans[0]/total,false);
		arg_given_head_valence_inc(h,v,arg,weight*probTrans[1]/total);
	}
	mix_dist->insert(nobackoffToHeadValence.first,weight*(probTrans[0]/total),false);
	mix_dist->insert(backoffToHeadValence.first,weight*(probTrans[1]/total),false);
	return total;
}
F Grammar_lexicalized_1linb::AttDist::arg_given_head_valence_inc(U h,U v, U arg,F weight){
	assert(v>0);
	U size=2;
	MD * md[size];
	md[0] = get_arg_given_head_valence(h,v);
	md[1] = get_arg_given_valence(v);
	MD * mix_dist=get_arg_mix_given_head_valence(h,v);
	F mix[2]= {mix_dist->prob(nobackoffToValence.first),mix_dist->prob(backoffToValence.first)};
	F total=0;
	F probTrans[size];
	for(U i=0;i<size;i++){
		probTrans[i]=md[i]->prob(arg)*mix[i];
		total+=probTrans[i];
	}
	if(total==0) total=1;//in case there is zero mass

	for(U i=0;i<size;i++){
		md[i]->insert(arg,weight*probTrans[i]/total,false);
	}
	mix_dist->insert(nobackoffToValence.first,weight*(probTrans[0]/total),false);
	mix_dist->insert(backoffToValence.first,weight*(probTrans[1]/total),false);
	return total;
}

F Grammar_lexicalized_1linb::AttDist::arg_given_head_valence_prob(U h,U v, U argt){
	MD * md1 = get_arg_given_head_valence(h,v);
	MD * md2 = get_arg_given_valence(v);
	MD * mix = get_arg_mix_given_head_valence(h,v);
	F pr=mix->prob(nobackoffToValence.first)*md1->prob(argt)+mix->prob(backoffToValence.first)*md2->prob(argt);
	
	assert(pr>=0&&pr<=1.0000001);
	return pr;
}
F Grammar_lexicalized_1linb::AttDist::arg_given_head_valence_hw_prob(U ht,U v,U hw, U argt){
	MD * md0 = get_arg_given_head_valence_hw(ht,v,hw);
	//MD * md1 = get_arg_given_head_valence(h,v);
	//MD * md2 = get_arg_given_valence(v);
	MD * mix = get_arg_mix_given_head_valence_hw(ht,v,hw);
	F pr=mix->prob(nobackoffToHeadValence.first)*md0->prob(argt)
		+mix->prob(backoffToHeadValence.first)*arg_given_head_valence_prob(ht,v,argt);
	if(!(pr<=1.00001&&pr>=0)){
		cout<<"pr="<<0<<endl;
		assert(pr<=1.00001&&pr>=0);
	}
	return pr;
}
MD * Grammar_lexicalized_1linb::get_aw_given_arg(U argt){
	return getMD(argt,aw_given_arg);
}
MD * Grammar_lexicalized_1linb::AttDist::get_aw_given_arg(U argt){
	return getMD(argt,g->aw_given_arg);
}
F Grammar_lexicalized_1linb::AttDist::aw_given_arg_head_valence_hw_prob(U argt,U ht,U v,U hw, U aw){
	MD * md0 = get_aw_given_arg(argt);
	F pr=md0->prob(aw);
	return pr;
}
F Grammar_lexicalized_1linb::AttDist::aw_given_arg_head_valence_hw_inc(U arg,U head, U v,U hw, U aw, F weight){
	MD * md0 = get_aw_given_arg(arg);
	return md0->insert(aw,weight,false);
}

MD * Grammar_lexicalized_1linb::AttDist::get_arg_given_head_valence_hw(U  h,U v, U hw){ 
	assert(v>0);
	if(v>NUMARG) v=NUMARG;//cap valence
	//cout<<"get_arg_given_head_valence_hw"<<getTagVocab().lookup(h)<<'\t'<<v<<'\t'<<getWordVocab().lookup(hw)<<endl;
	return getMD(hw,h,v,arg_given_head_valence_hw);
}
MD * Grammar_lexicalized_1linb::AttDist::get_arg_given_head_valence(U  h,U v){ 
	assert(v>0);
	//if(v>NUMARG) cout<<"capped valence "<<v<<" to "<<NUMARG<<endl;
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(h,v,arg_given_head_valence);
}
MD * Grammar_lexicalized_1linb::AttDist::get_arg_mix_given_head_valence_hw(U  h,U v, U hw){ 
	assert(v>0);
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(h,v,arg_mix_given_head_valence_hw);
}
MD * Grammar_lexicalized_1linb::AttDist::get_arg_mix_given_head_valence(U  h,U v){ 
	assert(v>0);
	//if(v>NUMARG) cout<<"capped valence "<<v<<" to "<<NUMARG<<endl;
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(h,v,arg_mix_given_head_valence);
}
MD * Grammar_lexicalized_1linb::AttDist::get_arg_given_valence(U v){ 
	assert(v>0);
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(v,arg_given_valence);
}
Grammar_lexicalized_1linb::AttDist::AttDist(Grammar_lexicalized_1linb * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, list<pair<U,F> > & stop,const string & direction,Vocab & tv,Vocab & wv):
	tagVocab(tv),
	wordVocab(wv),
	dir(direction),
	args(arg),
	words(word),
	stops(stop),
	stop_given_head_valence(NUMSTOP),
	arg_given_head_valence_hw(NUMARG+1),
	arg_given_head_valence(NUMARG+1),
	arg_mix_given_head_valence_hw(NUMARG+1),
	arg_mix_given_head_valence(NUMARG+1),
	backoffToHeadValence(tagVocab.lookup("BACKOFF"),gram->getMetaGrammar()->backoffAlpha2.first),
	nobackoffToHeadValence(tagVocab.lookup("NOBACKOFF"),gram->getMetaGrammar()->backoffAlpha2.second),
	backoffToValence(tagVocab.lookup("BACKOFF"),args.size()*2),
	nobackoffToValence(tagVocab.lookup("NOBACKOFF"),args.size()),
	g(gram)
{
	backoffs2.push_back(nobackoffToHeadValence);
	backoffs2.push_back(backoffToHeadValence);
	backoffs.push_back(nobackoffToValence);
	backoffs.push_back(backoffToValence);
	foreach(UFList,arg,getArgs()){
		string id=dir+"_stop_given_";
		string id3=dir+"_arg_given_";
		string id2=dir+"_arg_given_";
		string argstr=tagVocab.lookup(arg->first);
		id+=argstr;
		id3+=argstr;
		for(U n=0;n<NUMSTOP;n++){
			char nc='0'+n;
			string ida=id+nc;
			stop_given_head_valence[n].insert(pair<U,MD*>(arg->first,new MD(2,stops,ida)));
			g->add_nonmix_dist(get_stop_given_head_valence(arg->first,n));
			}
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
			char nc='0'+n;
			string ida=id3+nc;
			arg_given_head_valence[n].insert(pair<U,MD*>(arg->first,new MD(args.size(),args,ida)));
			g->add_nonmix_dist(get_arg_given_head_valence(arg->first,n));
			string ida_mix="mix_";
			ida_mix+=id3+nc;
			arg_mix_given_head_valence[n].insert(pair<U,MD*>(arg->first,new MD(backoffs.size(), backoffs,ida_mix)));
			g->add_mix_dist(get_arg_mix_given_head_valence(arg->first,n));
			//cout<<getTagVocab().lookup(arg->first)<<" wordListSize="<<getWordList(arg->first).size()<<endl;
			cforeach(UFList,aw,getWordList(arg->first)){
				string idb=ida+wordVocab.lookup(aw->first);
				arg_given_head_valence_hw[n][arg->first].insert(pair<U,MD*>(aw->first,new MD(args.size(),args,idb)));
				g->add_nonmix_dist(get_arg_given_head_valence_hw(arg->first,n,aw->first));
				//cout<<"adding nonmix arg_given_stuff: hw="<<getWordVocab().lookup(aw->first)<<endl;
				
			}
			string idb=ida_mix;
			arg_mix_given_head_valence_hw[n].insert(pair<U,MD*>(arg->first,new MD(backoffs2.size(),backoffs2,idb)));
			g->add_mix_dist((arg_mix_given_head_valence_hw[n][arg->first]));
		}
	}
	for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
		char nc='0'+n;
		string id2=dir+"_arg_given_";
		string ida=id2+nc;
		arg_given_valence.insert(pair<U,MD* >(n,new MD(args.size(),args,ida)));
		g->add_nonmix_dist(get_arg_given_valence(n));
	}
		
}

Grammar_lexicalized_1linb::RootAttDist::RootAttDist(Grammar_lexicalized_1linb * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, Vocab & tv,Vocab & wv):
	tagVocab(tv),
	wordVocab(wv),
	args(arg),
	words(word),
	arg_given_root(args.size(),args,"S_arg_given_root"),
	g(gram)
{
		
}
F Grammar_lexicalized_1linb::RootAttDist::arg_given_root_prob(U arg){
	return arg_given_root.prob(arg);
}
F Grammar_lexicalized_1linb::RootAttDist::aw_given_root_arg_prob(U arg,U aw){
	return get_aw_given_arg(arg)->prob(aw);
}

F Grammar_lexicalized_1linb::RootAttDist::arg_given_root_inc(U arg,F weight){
	return arg_given_root.insert(arg,weight,false);
}
F Grammar_lexicalized_1linb::RootAttDist::aw_given_root_arg_inc(U arg,U aw,F weight){
	return get_aw_given_arg(arg)->insert(aw,weight,false);
}
void Grammar_lexicalized_1linb::RootAttDist::reestimate(int type,Grammar_lexicalized_1linb::RootAttDist & d){
	arg_given_root.reestimate(type,d.arg_given_root);
}

MD * Grammar_lexicalized_1linb::RootAttDist::get_aw_given_arg(U argt){
	return getMD(argt,g->aw_given_arg);
}
MD * Grammar_lexicalized_1linb::RootAttDist::getMD(const U & h, W_MD & md){
	W_MD::iterator i=md.find(h);
	if(i==md.end()){
		cout<<"didn't find "<<h<<endl;
		assert(false);
	}
	else 
		return (i->second);
	assert(false);
	return NULL;
}
F Grammar_lexicalized_1linb::RootAttDist::KLQ_P(){
	return arg_given_root.KLQ_P();
}
void Grammar_lexicalized_1linb::RootAttDist::setCollapsed(bool c){
	arg_given_root.setCollapsed(c);
}
