#ifndef RANDOM_H
#define RANDOM_H
#include "mt19937ar.h"
// inline F random1() { return rand()/(RAND_MAX+1.0); }
inline long double random1() { return mt_genrand_res53(); }
#endif
