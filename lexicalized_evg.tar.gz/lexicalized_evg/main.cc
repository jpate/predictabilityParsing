/*
 * Copyright William Headden 2009
 *
*/

//
// Perform Variational Bayesian inference for Dependency PCFGs
//
#include"Tree.h"
#include"grammar.h"
#include"Chart.h"
#include"grammar_lexicalized_1linb.h"
#include"grammar_uvg_6lin.h"
#include"Count.h"
#include"grammar_uvg.h"

const char usage[] =
"[executable] [options]\n"
"\n"
" -l language       -- language number (used for removing punctuation). Punc set in dependency.h This version only does English (0) \n"
" -P 1              -- set estimation of mixing parameters to false\n"
" -q 1              -- set estimation of mixing parameters from dev to true\n"
" -A analyses_path  -- file stem to place output parses\n"
" -J ownTagCutoff   -- set top K most frequent words to their own POS tag\n"
" -S 1              -- initialize from gold dependencies\n"
" -V estimationType -- 1=EM, 2=VB, 3=MAP\n"
" -D 1              --use conLL-X input\n"
" -U unkNum         -- set unkCutoff to keep unkNum words\n"
" -u unkCutoff      -- set words seen this number or fewer to UNK\n"
" -W filename       -- write final model to filename\n"
" -R filename       -- read model frrom filename\n"
" -k 1              -- set initialization to harmonic initializer of Klein & Manning\n"
" -B beam_iters     -- number of iterations to use in beam search. Default 40\n"
" -b beam_width     -- width of beam search\n"
" -s numStop        -- number of stop distributions.    EVG=2,DMV=2 \n"
" -a numArg         -- number of argument distributions. EVG=2, DMV=1\n"
" -X max_sent_len   -- maximum sentence length for training \n"
" -d debug          -- debug level\n"
" -n num_iterations -- number of iterations for second stage\n"
" -r randomSeed     -- random seed\n"
" -t trainPath      -- training path\n"
" -d devPath        -- dev path\n"
" -T testPath       -- test path\n";

             
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <utility>
#include <vector>

#include "mt19937ar.h"
#include "random.h"
#include "utility.h"
int debug = 0;

inline float power(float x, float y) { return powf(x, y); }
inline double power(double x, double y) { return pow(x, y); }
inline long double power(long double x, long double y) { return powl(x, y); }
#include "dependency.h"
typedef pair<U,U> Upair;
typedef vector<Upair> Uvec;
typedef vector<Uvec> UUvec;
#include"Tree.h"

//given a set of dependencies, a Sentence, tag and word dictionaries, and an ostream, output the sentence + dependencies in CoNLL-X format
void printCoNLL(const set<Upair> & depset,const Sentence & sentence,ostream * out,Vocab & tv,Vocab & wv){
	vector<int> depvec(depset.size()+1);
	cforeach(set<Upair>,dep,depset){
		depvec[dep->second+1]=dep->first+1;
	}
	for(int i=1;i<(int)(depvec.size());i++){
		*out	<<i<<'\t'
			<<wv.lookup(sentence[(i-1)*2].original_word)<<'\t'
			<<"_\t"
			<<tv.lookup(sentence[(i-1)*2].tag)<<'\t'
			<<tv.lookup(sentence[(i-1)*2].tag)<<'\t'
			<<"_\t"
			<<depvec[i]<<"\t_\t"
			<<depvec[i]<<'\t'
			<<"_"<<endl;
	
	}
	*out<<endl;
}

//Borrowed from Mark.  reads a line of strings into syms
std::istream& readline_symbols(std::istream& is, std::vector<string>& syms) {
  syms.clear();
  std::string line;
  if (std::getline(is, line)) {
    std::istringstream iss(line);
    std::string s;
    while (iss >> s)
      syms.push_back(s);
  }
  return is;
}  // readline_symbols()
void score_deps2(const Sentences & tests,const vector<set<Upair> > * gold_deps,const vector<set<Upair> > & test_deps, ostream * out,bool point_estimate,bool newline){
			bool old=MultDir2<U>::point_estimate;
			MultDir2<U>::point_estimate=point_estimate;
			assert(gold_deps);
			U n=tests.size();
			DepScore dir_acc;
			DepScore undir_acc;
			assert(gold_deps->size()==tests.size());
			for(U i=0;i<n;i++){
				//cout<<"scoring sentence "<<i<<'\t'<<(*gold_deps)[i].size()<<'\t'<<test_deps[i].size()<<endl;
				//assert((*gold_deps)[i].size()==test_deps[i].size());
				pair<DepScore,DepScore> d=CoNLLDependency::score_deps((*gold_deps)[i],test_deps[i]);
				dir_acc+=d.first;
				undir_acc+=d.second;
			}
			*out<< "\tDA: "<<dir_acc.matched/(float)dir_acc.total
					  << '\t'<< "UA: "<<undir_acc.matched/(float)undir_acc.total;
			if(newline) *out<<endl;
			MultDir2<U>::point_estimate=old;
		

}
void score_deps(const Sentences & tests,const vector<set<Upair> > * gold_deps, Grammar * model0,ostream * out,bool point_estimate,bool newline,ostream * outA){
			bool old=MultDir2<U>::point_estimate;
			MultDir2<U>::point_estimate=point_estimate;
			assert(gold_deps);
			U n=tests.size();
			DepScore dir_acc;
			DepScore undir_acc;
			vector<set<Upair> > test_deps(n);
			assert(gold_deps->size()==tests.size());
			//Vocab & tv=model0->getTagVocab();
			//Vocab & wv=model0->getWordVocab();
			for(U i=0;i<n;i++){
				if(i>7422) break;
				Chart p(tests[i],model0);
				Tree * tps_i=p.viterbiTree().tree;
				if(!tps_i){
					dir_acc.total+=(*gold_deps)[i].size();
					undir_acc.total+=(*gold_deps)[i].size();
					continue;
				
				}
				assert(tps_i);
				tps_i->extract_dependency_set(test_deps[i]);
				Tree * tree2=new Tree(test_deps[i],tests[i]);
				assert(*tps_i==*tree2);
				delete tree2;
				//tps_i->write(cout,*model0);
				//cout<<endl;
				//tree2->write(cout,*model0);
				//cout<<endl;
				if(outA){
					printCoNLL((test_deps)[i],tests[i],outA,model0->getTagVocab(),model0->getWordVocab());
				}
				assert((*gold_deps)[i].size()==test_deps[i].size());
				pair<DepScore,DepScore> d=CoNLLDependency::score_deps((*gold_deps)[i],test_deps[i]);
				dir_acc+=d.first;
				undir_acc+=d.second;
				delete tps_i;
			}
			if(!outA){	
				*out<< "\tDA: "<<dir_acc.matched/(float)dir_acc.total
						  << '\t'<< "UA: "<<undir_acc.matched/(float)undir_acc.total;
				if(newline) *out<<endl;
			}
			MultDir2<U>::point_estimate=old;
		

}
template<class g_type>
F eval_dev_likelihood(g_type *model0,const Sentences & devs){
  U n=devs.size();
  MultDir2<U>::point_estimate=true;
  F log_p0=0;
  for (U i = 0; i < n; ++i) {
	assert(devs[i].size()>0);
	Chart p(devs[i],model0);
	F tprob = p.inside();
	assert(tprob>=0&&tprob<=1);
	if(tprob==0){
		log_p0+=-240;//smoothing has failed us.  only a problem for unsmoothed EM
	}
	else
		log_p0+=log(tprob);
  }
  MultDir2<U>::point_estimate=false;
  return log_p0;
}
template<class g_type>
F variational_iterate(
	g_type * model0,
	const Sentences & trains,
	const Sentences & trains2,
	const Sentences & devs,
	const Sentences & tests,
	const vector<set<Upair> > *train_deps,
	const vector<set<Upair> > * dev_deps,
	const vector<set<Upair> > * gold_deps,
	U niterations,
	std::ostream * trace_stream_ptr,
	F log_p0,
	bool verbose,
	U n,
	int varType,
	bool early_end,
	bool est_mix_from_dev,
	bool est_mix){
  //U n = trains.size();
  F log_p1=0;
  assert(model0);	
  typedef std::vector<U> Us;
  time_t t0=time(0);
  time_t t1=time(0);
  F freeEnergy=-log(0.0);
  F log2prob_corpus = 0;//model0->log2prob_corpus();
  MultDir2<U>::point_estimate=false;
  for (U i = 0; i < trains.size(); ++i) {
	assert(trains[i].size()>0);
	Chart p(trains[i],model0);
	F tprob = p.inside();
	assert(tprob>=0&&tprob<=1);
	p.outside();
	p.incrementExpectedCounts();//count0);
	log_p0+=log(tprob);
  }
  for (U i = 0; i < n; ++i) {
	assert(trains2[i].size()>0);
	Chart p(trains2[i],model0);
	F tprob = p.inside();
	if(!(tprob>0)){
		 cerr<<"error, tprob="<<tprob<<" for sentence ";
		for(U j=0;j<trains2[i].size();j++)
			cerr<<model0->getTagVocab().lookup(trains2[i][j].tag)<<'_'<<model0->getWordVocab().lookup(trains2[i][j].word)<<" "<<endl;
	}
	assert(tprob>0);
	//cout<<"initial tprob "<<i<<" = "<<tprob<<endl;
	assert(tprob>=0&&tprob<=1);
	p.outside();
	p.incrementExpectedCounts();//count0);
	log_p0+=log(tprob);
  }
  F logKL2=0;
  F logKL=0;
  if(varType==MultDir2<U>::VAR)
	  logKL=model0->logKLPosteriorPrior(true,est_mix&&(!est_mix_from_dev));
  else if(varType==MultDir2<U>::MLE)
	logKL=0;
  if (verbose) cout<<"And they're off!!!"<<endl;
  F time_eval=0;
  F time_per_sent=0;
  F time_other=0;
  time_t t3,t4;
  F log_dev_likelihood=log(0.0);
  U iteration=0;
  for (iteration = 0; iteration <= niterations; ++iteration) {
	log_p1=0;
	t0=t1;
	t1=time(0);

    F freeEnergy2=logKL-log_p0;
    
    F log_dev_likelihood2=eval_dev_likelihood(model0,devs);

    if((iteration>40&&early_end&&(log_dev_likelihood2<log_dev_likelihood-1||(freeEnergy2-freeEnergy<.0001*freeEnergy)))||iteration==niterations){
		if(verbose)
			 *trace_stream_ptr <<"Finished: "<< iteration<<endl;
    }
    if (trace_stream_ptr&&verbose){
		t4=time(0);
		//cout<<"evaluating"<<endl;
	        *trace_stream_ptr << iteration << '\t'            // iteration
			<< 1 << '\t'         // temperature
			<< freeEnergy2 << '\t'     // - log2 P(corpus)
			<< log2prob_corpus << '\t' 
			<< log_dev_likelihood <<'\t'
			<< log_dev_likelihood2 <<'\t'
			<< -log_p0 << '\t'       // - log likelihood
			<< logKL << '\t'       // - log likelihood
			<<-log_p0+logKL-freeEnergy << '\t'       // - log likelihood
			<< t1-t0 << "_tics";//<<endl;       // # parses rejected
		if(iteration % 1 ==0 && gold_deps){
			score_deps(trains, train_deps, model0, trace_stream_ptr,true,false);
			score_deps(tests, gold_deps, model0, trace_stream_ptr,true,false);
			score_deps(devs, dev_deps, model0, trace_stream_ptr,true,false);
		}
		time_eval+=time(0)-t4;
    }
    if((iteration>40&&early_end&&(log_dev_likelihood2<log_dev_likelihood-1||(freeEnergy2-freeEnergy<.0001*freeEnergy)))||iteration==niterations){
		//cout<<"iteration: "<<iteration<<endl;
		break;
    }
    else if (verbose) *trace_stream_ptr<<endl;
    log_dev_likelihood=log_dev_likelihood2;
    assert(log_p0<=0);
    assert(logKL>=0);
    if(!(freeEnergy2<=freeEnergy+.001)&&iteration>=2){
	    cout<<" current freeEnergy= "<<logKL-log_p0
	        <<" previous freeEnergy= "<<freeEnergy
                <<" diff="<<freeEnergy-freeEnergy2<<endl;
	    cout<<"diff="<<-log_p0+logKL-freeEnergy
                <<" -log_p0="<<-log_p0<<" logKL= "
                <<logKL<<endl;
           //assert(freeEnergy-freeEnergy2>-.001);
	   //assert(false);
    }
    if(varType==MD::VAR)
	    freeEnergy =  -log_p0+logKL;
    else if(varType==MD::MLE)
	    freeEnergy=-log_p0;
    else assert(false);
    t4=time(0);
    model0->reestimate(varType,true,est_mix&&(!est_mix_from_dev));
    if(est_mix&&est_mix_from_dev&&((iteration>40&&early_end)||!early_end)){
	    model0->clearCounts(false,true);
	    for (U i = 0; i < devs.size(); i++) {
			assert(devs[i].size()>0);
			Chart p(devs[i],model0);
			F tprob = p.inside();
			p.outside();
			p.incrementExpectedCounts();//count1);
			log_p1+=log(tprob);
	    }
	    model0->reestimate(varType,false,true);
	    model0->clearCounts(true,false);

    }
    t3=time(0);
    time_other+=t3-t4;
    //variational E-step:
    MultDir2<U>::point_estimate=false;
    for (U i = 0; i < trains.size(); i++) {
		assert(trains[i].size()>0);
		Chart p(trains[i],model0);
		F tprob = p.inside();
		p.outside();
		p.incrementExpectedCounts();//count1);
		log_p1+=log(tprob);
    }
    for (U i = 0; i < n; ++i) {
		assert(trains2[i].size()>0);
		Chart p(trains2[i],model0);
		F tprob = p.inside();
		p.outside();
		p.incrementExpectedCounts();//count0);
		log_p1+=log(tprob);
    }
    t4=time(0);
    time_per_sent+=t4-t3;
  logKL2=logKL;
  logKL=0;
  if(varType==MultDir2<U>::VAR)
	  logKL=model0->logKLPosteriorPrior(true,est_mix&&(!est_mix_from_dev));
    time_other+=time(0)-t4;

    log_p0=log_p1;


  }
  if(!verbose)
	  cout<<iteration<<"\ttimes: "<<time_per_sent<<'\t'<<time_other<<'\t'<<time_eval<<endl;
  if(varType==MultDir2<U>::VAR)
	  return logKL-log_p0;
  else if(varType==MultDir2<U>::MLE)
	return -log_p0;
  else if(varType==MultDir2<U>::MAP){
	assert(false);
	return -log_p0;
  }
  else assert(false);
  return 0;

}

//generate leftbranching and right-branching baselines
void generate_baseline_deps(const Sentences & sents, vector<set<Upair> > & deps,bool left){
	deps.resize(sents.size());
	for(U i=0;i<sents.size();i++){
		for(U j=0;j<sents[i].size()/2-1;j++){
			if(left)
				deps[i].insert(Upair(j,j+1));
			else
				deps[i].insert(Upair(j+1,j));

		}
	}
}


F variational_estimate(MetaGrammar & g, const Sentences& trains,const Sentences & trains2 ,const Sentences & devs,const Sentences & tests,const Sentences & tests10,const vector<set<Upair> > * train_deps,
		const vector<set<Upair> > * dev_deps,
		const vector<set<Upair> > * gold_deps10,
		const vector<set<Upair> > * gold_deps,
		U stage2BeamWidth,
		U niterations,
		int varType, 
		 int initializerBeamWidth,
		int numBeamIters,
		 std::ostream* train_analyses_stream_ptr = NULL,
		 std::ostream* test_analyses_stream_ptr = NULL,
		 std::ostream* trace_stream_ptr = NULL,
		 bool init_from_deps=false, bool klein_init=false,F random_klein=0,bool est_mix_from_dev=false,bool useTrains2Beam=true,istream * readFromFile=NULL,ostream* writeOnFinish=NULL,bool initSupervised=false,bool est_mix=true) {
  cout<<"Performing Variational Bayes with models "<<GRAMMAR_TYPE_1::type_id<<" for the first stage, ";
#ifdef GRAMMAR_TYPE_2  
  cout<<GRAMMAR_TYPE_2::type_id<<" for the second ";
#endif
  //cout<<endl;
  //U n = trains2.size();
  cout<<trains.size()<<"train sentences"<<endl;
  cout<<trains2.size()<<"extra train sentences"<<endl;
  cout<<devs.size()<<"dev sentences"<<endl;
  cout<<tests.size()<<"test sentences"<<endl;
  cout<<tests10.size()<<"additional test sentences"<<endl;


  vector<set<Upair> > train_left_deps;
  vector<set<Upair> > train_right_deps;
  vector<set<Upair> > test_left_deps;
  vector<set<Upair> > test_right_deps;
  generate_baseline_deps(trains,train_left_deps,true);
  generate_baseline_deps(trains,train_right_deps,false);
  generate_baseline_deps(tests,test_left_deps,true);
  generate_baseline_deps(tests,test_right_deps,false);
  cout<<"attach-left :\t";
  score_deps2(trains,train_deps,train_left_deps,&cout,true,false);
  score_deps2(tests,gold_deps,test_left_deps,&cout,true,true);
  cout<<"attach-right:\t";
  score_deps2(trains,train_deps,train_right_deps,&cout,true,false);
  score_deps2(tests,gold_deps,test_right_deps,&cout,true,true);

  typedef std::vector<U> Us;



  GRAMMAR_TYPE_1 * bestModel=NULL;
  F bestScore=0;
  time_t t0=time(0);
  if(readFromFile){
	bestModel=new GRAMMAR_TYPE_1(&g);
	bestModel->readFromFile(*readFromFile);
  }
  else{
	  for(int j=0;j<initializerBeamWidth;j++){
		 GRAMMAR_TYPE_1 * model0 = new GRAMMAR_TYPE_1(&g);
		  F log_p0=0;
		  if(initSupervised){
			  for (U i = 0; i < trains.size(); ++i) {
				assert(trains[i].size()>0);
				Tree * tree=new Tree((*train_deps)[i],trains[i]);
				model0->increment(tree,trains[i],1,false);
				//tree->incErule(model0);
			   }
			   model0->reestimate(varType,true,true);

		  }	
		  else if(!klein_init){
			  for (U i = 0; i < trains.size(); ++i) {
				assert(trains[i].size()>0);
				Chart p(trains[i],model0);
				F tprob = p.inside();
				//cout<<"initial tprob "<<i<<" = "<<tprob<<endl;
				assert(tprob>=0&&tprob<=1);
				p.outside();
				//if(klein_init)
				//	p.constructHarmonicChart();
				//else
					p.incrementExpectedCounts();//count0);
				log_p0+=log(tprob);
			   }
		  }
		  else{
			#ifdef KLEIN
			cout<<"initKlein: "<<random_klein<<endl;
			model0->initKlein(trains,random_klein,varType,train_deps);
			
			if(random_klein==0){
				model0->reestimate(varType,true,true);
			}
			#else
			assert(false);
			#endif
		  }
		F adist=0;
		F sdist=0;
		F ildist=0;
		//F oneDirBranch=0;
		F numWords=0;
		F dHeight=0;
		for (U i = 0; i < trains.size(); ++i) {
			assert(trains[i].size()>0);
			Chart p(trains[i],model0);
			numWords+=trains[i].size()/2;
			F tprob = p.inside();
			assert(tprob>=0&&tprob<=1);
			p.outside();

		}
		  F score =  variational_iterate<GRAMMAR_TYPE_1>(model0, trains,trains2,devs,tests,train_deps,dev_deps, gold_deps,numBeamIters,trace_stream_ptr,log_p0,false,useTrains2Beam?trains2.size():0,varType,false,est_mix_from_dev,est_mix);
			 
		  score_deps(trains, train_deps, model0, trace_stream_ptr,true,false);
		  //score_deps(tests, gold_deps, bestModel, trace_stream_ptr,true);
		cout<<"absolute distance= "<<adist/numWords<<'\t'<<"invLog distance= "<<ildist/numWords<<'\t'<<"sq dist= "<<sdist/numWords<<'\t'<<"dirHeight=\t"<<dHeight<<endl;
		  if(!bestModel || score< bestScore){
			if(bestModel) delete bestModel;
			bestModel=model0;
			bestScore=score;
			cout<<"new best free energy = "<<bestScore<<endl;
			if(j!=initializerBeamWidth-1)
				model0 = NULL;//new GRAMMAR_TYPE_1(&g);
		  }
		  else{
			assert(bestModel);
			assert(model0!=bestModel);
			delete model0;	
			//model0 = NULL;//new GRAMMAR_TYPE_1(&g);
			model0 = NULL;//new GRAMMAR_TYPE_1(&g);
		  }
		  time_t t1=time(0);
		  cout<<"After Beam iteration "<<j<<'\t'<<bestScore<<'\t'<<t1-t0<<"_tics\t";
		  t0=t1;
	  }
	  cout<<"post beam"<<endl;
  }
#ifdef GRAMMAR_TYPE_2
  g.backoffAlpha=g.backoffAlpha2;
  g.backoff_symbols.clear();
  g.backoff_symbols.push_back(pair<U,F>(g.tagVocab.lookup("BACKOFF"),g.backoffAlpha.first));
  g.backoff_symbols.push_back(pair<U,F>(g.tagVocab.lookup("NOBACKOFF"),g.backoffAlpha.second));
  GRAMMAR_TYPE_2 * bestModel2= NULL;
  bestScore=0;
  for(U j=0;j<stage2BeamWidth;j++){
	  GRAMMAR_TYPE_2 * model1=new GRAMMAR_TYPE_2(bestModel,&g);
	  F score=variational_iterate<GRAMMAR_TYPE_2>(model1,    trains,trains2,devs,tests,train_deps,dev_deps,gold_deps,niterations,trace_stream_ptr,0,true,trains2.size(),varType,false,est_mix_from_dev,est_mix);
	  score_deps(trains, train_deps, model1, trace_stream_ptr,true,false);
	  //variational_iterate<GRAMMAR_TYPE_2>(model1,trains,devs,tests,train_deps,gold_deps,niterations,trace_stream_ptr,0,true,0,varType,true);
	  //model1->printStatistics(*trace_stream_ptr);
	  cout<<"\nscore:"<<score<<'\t'<<bestScore<<endl;
	  if(!bestModel2 || score< bestScore){
		if(bestModel2) delete bestModel2;
		bestModel2=model1;
		bestScore=score;
		cout<<j<<" new best free energy Stage 2= "<<bestScore<<endl;
		if(j!=stage2BeamWidth-1)
			model1 = NULL;
	  }
	  else{
		assert(bestModel2);
		assert(model1!=bestModel2);
		cout<<"deleting model1: "<<model1<<endl;
		delete model1;	
		cout<<"not best model: "<<j<<endl;
		model1 = NULL;
	  }
  }
  variational_iterate<GRAMMAR_TYPE_2>(bestModel2,trains,trains2,devs,tests,train_deps,dev_deps,gold_deps,1,trace_stream_ptr,0,true,trains2.size(),varType,true,est_mix_from_dev,est_mix);
  score_deps(tests10,gold_deps10,bestModel2,trace_stream_ptr,true,true);
  if(train_analyses_stream_ptr){
	score_deps(trains,train_deps,bestModel2,trace_stream_ptr,true,true,train_analyses_stream_ptr);
	score_deps(tests10,gold_deps10,bestModel2,trace_stream_ptr,true,true,test_analyses_stream_ptr);
  }
  delete bestModel;
#else
  variational_iterate<GRAMMAR_TYPE_1>(bestModel,trains,trains2,devs,tests,train_deps,dev_deps,gold_deps,niterations,trace_stream_ptr,0,true,trains2.size(),varType,true,est_mix_from_dev,est_mix);
  if(train_analyses_stream_ptr){
	cout<<"print analyses"<<endl;
	score_deps(trains,train_deps,bestModel,trace_stream_ptr,true,true,train_analyses_stream_ptr);
	score_deps(tests10,gold_deps10,bestModel,trace_stream_ptr,true,true,test_analyses_stream_ptr);
  }
  if(writeOnFinish){
	bestModel->writeToFile(*writeOnFinish);
  }
  delete bestModel;
#endif
  
  return 0;
}  // variational_estimate()

#include"dependency.h"
int main(int argc, char** argv) {
  bool useLowerCase=true;
  bool ignoreTagCount=true;
  bool est_mix=true;
  bool iteratedLocalSearch=false;
  ostream * writeOnFinish=NULL;
  istream * readFromFile=NULL;
  bool useTrains2Beam=false;
  F gb_prior_hyp=1;
  F gb_prior_hyp2=0;
  bool est_mix_from_dev=false;
  bool tied_init=false;
  int numBeamIters=40;
  U max_sent_len=10;
  U max_sent_len_test=max_sent_len;
  cout.setf(ios::fixed,ios::floatfield);
  cout.precision(5);
  pair<F,F> backAlpha(70,35);
  pair<F,F> backAlpha2(-1,-1);
  F random_klein = 0;
  U niterations = 100;
  F z_temp = 1;
  unsigned long rand_init = 0;
  std::ostream* train_analyses_stream_ptr = NULL;
  std::ostream* test_analyses_stream_ptr = NULL;
  std::istream* init_str = NULL;
  std::ostream* trace_stream_ptr = &cout;
  string unkTag = "UNKNOWN_TAG";
  string unkWord= "UNKNOWN_WORD";
  Vocab tagVocab(unkTag);
  Vocab wordVocab(unkWord);
  int chr;
  F alpha=1;
  int initializerBeamWidth=10;
  int stage2BeamWidth=1;
  bool read_from_deps=false;
  bool init_from_deps=false;
  U block_size=1;
  bool klein_init=false;
  U unkCutoff=5;
  U unkNum=0;
  bool variational_bayes=false;
  string trainPath;
  string devPath;
  string testPath;
  string goldPath;
  bool useBuckets=false;
  istream * trainStream=NULL;
  istream * devStream=NULL;
  istream * testStream=NULL;
  int varType=MultDir2<U>::VAR;
  F arg_alpha=1,stop_alpha=1,nonstop_alpha=1;
  bool use_induced_tags=false;
  bool use_additional_tags=false;
  string induced_tag_path;
  string additional_tag_path;
  bool initSupervised=false;
  U ownTagCutoff=0;
  U language=0;//English
  while ((chr = getopt(argc, argv, "A:B:C:D:E:F:G:H:I:J:K:L:M:N:P:R:S:T:U:V:W:X:Z:a:b:c:d:e:g:h:i:k:l:m:n:p:q:r:s:t:u:v:w:x:z")) != -1){
	cout<<"chr="<<(char)chr<<endl;
    switch (chr) {
    
    case 'L':
      iteratedLocalSearch=true;
      std::cerr<<"iterated Local Search deprecated: option L invalid"<<std::endl;
      break;
    case 'l':
      language=atoi(optarg);
      break;
    case 'P':
      cerr<<"don't reestimate mixing parameters"<<endl;
      est_mix=false;
      break;
    case 'A':
      {
      string analyses_filename(optarg);
      string train_analyses_filename=analyses_filename+".train";
      train_analyses_stream_ptr = new std::ofstream(train_analyses_filename.c_str());
      assert(train_analyses_stream_ptr);
      assert(*train_analyses_stream_ptr);

      string test_analyses_filename=analyses_filename+".test";
      test_analyses_stream_ptr = new std::ofstream(test_analyses_filename.c_str());
      assert(test_analyses_stream_ptr);
      assert(*test_analyses_stream_ptr);
      }
      break;
    case 'J':
	ownTagCutoff=atoi(optarg);
	break;
    case 'S':
      initSupervised=true;
      break;
    case 'F':
      trace_stream_ptr = new std::ofstream(optarg);
      break;
    case 'C':
	gb_prior_hyp=atof(optarg);
      break;
    case 'E':
      	useTrains2Beam=true;
	break;
    case 'h':
	additional_tag_path=optarg;
	use_additional_tags=true;
      break;
    case 'H':
	induced_tag_path=optarg;
	use_induced_tags=true;
      break;
    case 'V':
      varType=atoi(optarg);
      assert(varType==MultDir2<U>::MLE||varType==MultDir2<U>::VAR||varType==MultDir2<U>::MAP);
      variational_bayes= true;
      break;
    case 'D':
      read_from_deps = true;
      break;
    case 'U':
	unkNum=atoi(optarg);
	break;
    case 'W':
	writeOnFinish=new ofstream(optarg);
	assert(writeOnFinish);
	break;
    case 'R':
	readFromFile=new ifstream(optarg);
	assert(readFromFile);
	break;
    case 'u':
	unkCutoff=atoi(optarg);
	break;
    case 'c':
	gb_prior_hyp2=atof(optarg);
      break;
    case 'k':{
      klein_init=true;	
      F val=atof(optarg);
      random_klein=val-1;
      }
      break;
    case 'Z':
      tied_init =true;
      break;
    case 'q':
      est_mix_from_dev=true;
      break;
    case 'B':
      numBeamIters = atoi(optarg);
      break;
    case 'v':
      stop_alpha = atof(optarg);
      cout<<"stop_alpha="<<stop_alpha<<endl;
      break;
    case 's':{
      int i=atoi(optarg);
      GRAMMAR_TYPE_1::NUMSTOP = i;
      if(TOP<=i){
	cout<<"Error, need to recompile with higher max valence: TOP= "<<TOP<<endl;
	assert(false);
      }
#ifdef GRAMMAR_TYPE_2
      GRAMMAR_TYPE_2::NUMSTOP = atoi(optarg);
#endif
      cout<<"NUMSTOP="<<atoi(optarg)<<endl;
      break;
    }
    case 'a':
      GRAMMAR_TYPE_1::NUMARG = atoi(optarg);
      if(atoi(optarg)>=TOP){
	cout<<"Error, need to recompile with higher max valence: TOP= "<<TOP<<endl;
	assert(false);
      }
#ifdef GRAMMAR_TYPE_2
      GRAMMAR_TYPE_2::NUMARG = atoi(optarg);
#endif
      cout<<"NUMARG="<<atoi(optarg)<<endl;
      break;
    case 'N':
      stage2BeamWidth = atoi(optarg);
      cout<<"initializer Beam Width2="<<stage2BeamWidth<<endl;
      break;
    case 'b':
      initializerBeamWidth = atoi(optarg);
      cout<<"initializer Beam Width="<<initializerBeamWidth<<endl;
      break;
    case 'e':
	useBuckets=true;
	cout<<"use bucketed mixing parameters"<<endl;
	break;
    case 'g':
	goldPath = optarg;
      break;
    case 'X':
      max_sent_len = atoi(optarg);
      ignoreTagCount=true;
      cout<<"ignoreTagCount in generating possible tags"<<endl;
      break;
    case 'M':
      max_sent_len_test = atoi(optarg);
      ignoreTagCount=true;
      cout<<"ignoreTagCount in generating possible tags"<<endl;
      break;
    case 'n':
      niterations = atoi(optarg);
      cout<<"niterations="<<niterations<<endl;
      break;
    case 'G':
      backAlpha2.first = atof(optarg);
      break;
    case 'K':
      backAlpha2.second = atof(optarg);
      break;
    case 'm':
      backAlpha.first = atof(optarg);
      break;
    case 'p':
      backAlpha.second = atof(optarg);
      break;
    case 'r':
      rand_init = strtoul(optarg, NULL, 10);
      break;
    case 't':
        trainPath=optarg;
      break;
    case 'd':
        devPath=optarg;
      break;
    case 'T':
	testPath=optarg;
      break;
    case 'w':
      alpha = atof(optarg);
      break;
    default:
      std::cerr << "# Error in " << argv[0] 
		<< ": can't interpret argument -" << char(chr) << std::endl;
      std::cerr << usage << std::endl;
      exit(EXIT_FAILURE);
    }
   }
  cout<<"debug="<<debug<<endl;

  Sentences trains;
  Sentences trains2;
  Sentences devs;
  Sentences tests;
  Sentences  * tests10=&tests;
  Sentences all;
  vector<set<Upair> > * train_deps=NULL; 
  vector<set<Upair> > * dev_deps=NULL; 
  vector<set<Upair> > * gold_deps=NULL; 
  vector<set<Upair> > * gold_deps10=NULL; 
  vector<set<Upair> > * all_deps=NULL; 
  cout<<"NUMVAL="<<NUMVAL<<"\tTOP="<<TOP<<endl;
  assert(TOP==NUMVAL-1);
  cout<<"max_sent_len="<<max_sent_len<<'\t'<<max_sent_len_test<<endl;
  if(read_from_deps){
	if(use_induced_tags){
		cout<<"reading from induced_tags with deps: "<<induced_tag_path<<endl;
		ifstream inputStream2(induced_tag_path.c_str());
		assert(inputStream2);

		all_deps=new vector<set<Upair> >();
		assert(max_sent_len==max_sent_len_test);
		read_deps(inputStream2,all,all_deps,tagVocab,wordVocab,useLowerCase,true,max_sent_len,false,false,language);	
		read_flat2(inputStream2,trains2,tagVocab,wordVocab,useLowerCase,true,max_sent_len);	
		cout<<"read "<<all.size()<<" deps ("<<all_deps->size()<<")"<<endl;
		cout<<"read "<<trains2.size()<<"additional sentences "<<endl;
		U numTrain=atoi(trainPath.c_str());
		U numDev=atoi(devPath.c_str());
		U numTest=atoi(testPath.c_str());
		train_deps=new vector<set<Upair> >();
		if(numDev>0)
			dev_deps=new vector<set<Upair> >();
		if(numTest>0)
			gold_deps10=gold_deps=new vector<set<Upair> >();

		assert(numTrain>0);//&&numDev>0&&numTest>0);
		assert(numTrain+numDev+numTest==all.size());
		
		U i=0;
		trains.resize(numTrain);
		train_deps->resize(numTrain);
		devs.resize(numDev);
		if(numDev>0)
			dev_deps->resize(numDev);
		tests.resize(numTest);
		if(numTest>0)
			gold_deps->resize(numTest);
		U j=0;
		U b=0;
		for(i=0;i<trains.size();i++){
			assert((*train_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			trains[i]=all[i+j];
			(*train_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);

		}
		j=trains.size();
		for(i=0;i<devs.size();i++){
			assert((*dev_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			devs[i]=all[i+j];
			(*dev_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);
		}
		j=trains.size()+devs.size();
		for(i=0;i<tests.size();i++){
			assert((*gold_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			tests[i]=all[i+j];
			(*gold_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);
		}
		if(devs.size()==0){
			devs=trains;
			dev_deps=train_deps;
		}
		if(tests.size()==0){
			tests=trains;
			gold_deps=train_deps;
		}
		cout<<"read "<<all.size()<<" all"<<endl;
		printCoNLL((*all_deps)[0],all[0],&cout,tagVocab,wordVocab);

		cout<<"read "<<trains.size()<<" trains"<<endl;
		printCoNLL((*train_deps)[0],trains[0],&cout,tagVocab,wordVocab);
		cout<<"read "<<devs.size()<<" devs"<<endl;
		printCoNLL((*dev_deps)[0],devs[0],&cout,tagVocab,wordVocab);
		//printCoNLL((*dev_deps)[1],devs[1],&cout,tagVocab,wordVocab);
		cout<<"read "<<tests.size()<<" tests"<<endl;
		printCoNLL((*gold_deps)[0],tests[0],&cout,tagVocab,wordVocab);
		//printCoNLL((*gold_deps)[1],tests[1],&cout,tagVocab,wordVocab);
	}
	else{	
		cout<<"read from gold"<<endl;
		trainStream=new std::ifstream(trainPath.c_str());
		assert(trainStream);
		cout<<"opened "<<trainPath.c_str()<<" for training"<<endl;
		devStream=new std::ifstream(devPath.c_str());
		assert(devStream);
		cout<<"opened "<<devPath.c_str()<<" for dev"<<endl;
		testStream=new std::ifstream(testPath.c_str());
		assert(testStream);
		ifstream * testStream10=new std::ifstream(testPath.c_str());
		assert(testStream10);

		gold_deps10=new vector<set<Upair> >();
		gold_deps=new vector<set<Upair> >();
		tests10=new Sentences();
		dev_deps=new vector<set<Upair> >();
		train_deps=new vector<set<Upair> >();
		read_deps(*trainStream,trains,train_deps,tagVocab,wordVocab,useLowerCase,true,max_sent_len,true,false,language);
		delete trainStream;trainStream=NULL;
		read_deps(*devStream,devs,dev_deps,tagVocab,wordVocab,useLowerCase,true,max_sent_len,true,false,language);
		delete devStream;devStream=NULL;
		read_deps(*testStream10,*tests10,gold_deps10,tagVocab,wordVocab,useLowerCase,true,max_sent_len_test,true,false,language);
		read_deps(*testStream, tests,    gold_deps,  tagVocab,wordVocab,useLowerCase,true,max_sent_len,     true,false,language);
		cout<<"read gold_deps10 "<<gold_deps10->size()<<'\t'<<gold_deps->size()<<endl;
		if(max_sent_len==max_sent_len_test){
			cout<<"confirming that test and tests10 are the same"<<endl;
			Sentences & tests2=*tests10;
			assert(tests2.size()==tests.size());
			for(U i=0;i<tests2.size();i++){
				assert(tests2[i].size()==tests[i].size());
				for(U j=0;j<tests2[i].size();j++){
					assert(tests2[i][j].word==tests[i][j].word);
					assert(tests2[i][j].tag==tests[i][j].tag);
				}
			}
		}
		delete testStream10;testStream10=NULL;
		delete testStream;testStream=NULL;
		U k=trains.size()+devs.size()+tests.size();
		all.resize(k);
		U i=0;
		for(i=0;i<trains.size();i++)
			all[i]=trains[i];
		U j=trains.size();
		for(i=0;i<devs.size();i++)
			all[i+j]=devs[i];
		j=trains.size()+devs.size();
		for(i=0;i<tests.size();i++)
			all[i+j]=tests[i];
		if(use_additional_tags){
			cout<<"using additional tags"<<endl;
			ifstream moreStream(additional_tag_path.c_str());
			assert(moreStream);
			vector<string> line;
			while(moreStream){
				readline_symbols(moreStream,line);
				if(line.size()==0) continue;
				if(line.size()>max_sent_len) continue;
				Sentence terms;
				terms.resize(2*line.size());
				//cout<<trains2.size()<<'\t'<<endl;
				for(size_t i=0;i<line.size();i++){
					//cout<<line[i]<<' ';
					size_t p=line[i].find('_');
					string word=line[i].substr(0,p);
					string tag=line[i].substr(p+1,line[i].size()-p);
					//cout<<line[i]<<'\t'<<word<<'\t'<<tag<<endl;
					if(useLowerCase)
						for(U j=0;j<word.size();j++)
							word[j]=tolower(word[j]);
					terms[2*i]=terms[2*i+1]=word_type(tagVocab.lookup(tag),wordVocab.lookup(word));
						
				}
				//cout<<endl;
				trains2.push_back(terms);
			
			}
			cout<<"read "<<trains2.size()<<" sents"<<endl;
		}
		
	}
	
  }
  else { //not read_from_deps
	if(use_induced_tags){
		cout<<"reading from gold_deps: "<<goldPath<<endl;
		cout<<"reading from induced_tags: "<<induced_tag_path<<endl;
		ifstream inputStream2(induced_tag_path.c_str());
		ifstream inputStream(goldPath.c_str());
		assert(inputStream);
		assert(inputStream2);

		all_deps=new vector<set<Upair> >();
		assert(max_sent_len==max_sent_len_test);
		read_deps(inputStream,all,all_deps,tagVocab,wordVocab,useLowerCase,true,max_sent_len,false,false,language);	
		read_flat2(inputStream2,trains2,tagVocab,wordVocab,useLowerCase,true,max_sent_len);	
		cout<<"read "<<all.size()<<" deps ("<<all_deps->size()<<")"<<endl;
		cout<<"read "<<trains2.size()<<"additional sentences "<<endl;
		U numTrain=atoi(trainPath.c_str());
		U numDev=atoi(devPath.c_str());
		U numTest=atoi(testPath.c_str());
		train_deps=new vector<set<Upair> >();
		if(numDev>0)
			dev_deps=new vector<set<Upair> >();
		if(numTest>0)
			gold_deps=new vector<set<Upair> >();

		assert(numTrain>0);//&&numDev>0&&numTest>0);
		assert(numTrain+numDev+numTest==all.size());
		
		U i=0;
		trains.resize(numTrain);
		train_deps->resize(numTrain);
		devs.resize(numDev);
		if(numDev>0)
			dev_deps->resize(numDev);
		tests.resize(numTest);
		if(numTest>0)
			gold_deps->resize(numTest);
		U j=0;
		U b=0;
		for(i=0;i<trains.size();i++){
			assert((*train_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			trains[i]=all[i+j];
			(*train_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);
			//assert(all[i+j].size()==(*all_deps)[i+j].size());

		}
		j=trains.size();
		for(i=0;i<devs.size();i++){
			assert((*dev_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			devs[i]=all[i+j];
			(*dev_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);
		}
		j=trains.size()+devs.size();
		for(i=0;i<tests.size();i++){
			assert((*gold_deps).size()>i);
			assert((*all_deps).size()>i+j-b);
			assert(all.size()>i+j);
			tests[i]=all[i+j];
			(*gold_deps)[i]=(*all_deps)[i+j-b];
			assert(all[i+j].size()==(*all_deps)[i+j-b].size()*2);
		}
		if(devs.size()==0){
			devs=trains;
			dev_deps=train_deps;
		}
		if(tests.size()==0){
			tests=trains;
			gold_deps=train_deps;
		}
		cout<<"read "<<all.size()<<" all"<<endl;
		printCoNLL((*all_deps)[0],all[0],&cout,tagVocab,wordVocab);

		cout<<"read "<<trains.size()<<" trains"<<endl;
		printCoNLL((*train_deps)[0],trains[0],&cout,tagVocab,wordVocab);
		cout<<"read "<<devs.size()<<" devs"<<endl;
		printCoNLL((*dev_deps)[0],devs[0],&cout,tagVocab,wordVocab);
		//printCoNLL((*dev_deps)[1],devs[1],&cout,tagVocab,wordVocab);
		cout<<"read "<<tests.size()<<" tests"<<endl;
		printCoNLL((*gold_deps)[0],tests[0],&cout,tagVocab,wordVocab);
		//printCoNLL((*gold_deps)[1],tests[1],&cout,tagVocab,wordVocab);
	}
	else{
	    assert(false);
	}
    
  }
  if (debug >= 100)
     std::cerr << "# trains.size() = " << trains.size() << std::endl;

  typedef list<pair<U,F> > UFList;
  list<pair<U,F> > args;
  list<pair<U,F> > words;
  list<pair<U,F> > stops;
  list<pair<U,F> > backs;
  string unk="UNK";

  processWords(trains,trains2,devs,tests,*tests10,wordVocab,words,unkCutoff,unk,unkNum,tagVocab,ownTagCutoff);
  Count<U> tagCount;
  if (rand_init == 0)
    rand_init = time(NULL);

  mt_init_genrand(rand_init);
  U_LUF wordsByPOS; 
  U_SetU wbp_set;
  Count<U> wordCount;
  Count<pair<U,U>,int> tagWordCount;
  for(U i=0;i<trains.size();i++)
	for(U j=0;j<trains[i].size();j++){
		wbp_set[trains[i][j].tag].insert(trains[i][j].word);
		tagCount.inc(trains[i][j].tag,1);
		wordCount.inc(trains[i][j].word,1);
		tagWordCount.inc(pair<U,U>(trains[i][j].tag,trains[i][j].word),1);
	}
  for(U i=0;i<trains2.size();i++)
	for(U j=0;j<trains2[i].size();j++){
		wbp_set[trains2[i][j].tag].insert(trains2[i][j].word);
		tagCount.inc(trains2[i][j].tag,1);
		wordCount.inc(trains2[i][j].word,1);
		tagWordCount.inc(pair<U,U>(trains2[i][j].tag,trains2[i][j].word),1);
	}
  for(U i=0;i<devs.size();i++)
	for(U j=0;j<devs[i].size();j++)
		wbp_set[devs[i][j].tag].insert(devs[i][j].word);
  for(U i=0;i<tests.size();i++)
	for(U j=0;j<tests[i].size();j++)
		wbp_set[tests[i][j].tag].insert(tests[i][j].word);
  for(U i=0;i<tests10->size();i++)
	for(U j=0;j<(*tests10)[i].size();j++)
		wbp_set[(*tests10)[i][j].tag].insert((*tests10)[i][j].word);

  Grammar::generateSymbols(tagVocab,args,arg_alpha,stops,stop_alpha,nonstop_alpha,tagCount,ignoreTagCount);
  backs.push_back(pair<U,F>(tagVocab.lookup("BACKOFF"),backAlpha.first));
  backs.push_back(pair<U,F>(tagVocab.lookup("NOBACKOFF"),backAlpha.second));

  assert(args.size()>0);
  assert(stops.size()>0);
  foreach(UFList,arg,args)
	cout<<arg->first<<'\t'<<tagVocab.lookup(arg->first)<<endl;
  foreach(UFList,arg,stops)
	cout<<arg->first<<'\t'<<tagVocab.lookup(arg->first)<<endl;
  cout<<"grammar initialized"<<endl;
  foreach(UFList,arg,args){
	set<U> & s=wbp_set[arg->first];
	foreach(set<U>,si,s)
		wordsByPOS[arg->first].push_back(pair<U,F>(*si,1));
	cout<<arg->first<<'\t'<<tagVocab.lookup(arg->first)<<" has "<<wordsByPOS[arg->first].size()<<" words, "<<endl;
	
  }
  
  if (trace_stream_ptr) 
    *trace_stream_ptr << "# I = " << random_klein 
		      << ", n = " << niterations
		      << ", Z = " << z_temp
		      << ", r = " << rand_init
		      << ", B = " << block_size
		      << std::endl
		      << "# iteration temperature -logP -logL " 
		      << std::endl;
  if(init_from_deps)
	assert(gold_deps);
  if(variational_bayes){
	typedef ExtendedHashCount<U,U>  HCUU;
	typedef tr1::unordered_map<U,ExtendedHashCount<U,U> > HCUUU;
	typedef HashCount<U> HCU;
	HCUUU word_left_count;
	HCUUU word_right_count;
	if(backAlpha2.first==-1)
		backAlpha2=backAlpha;
	cout<<"backoff alpha params: "<<backAlpha<<endl;
	cout<<"backoff alpha params 2: "<<backAlpha2<<endl;
	//set common parameters
        MetaGrammar g2(tagVocab,wordVocab,args,words,backs,stops,wordsByPOS,backAlpha,backAlpha2,wordCount,tagCount,tagWordCount,tied_init,trains,varType,useBuckets,gb_prior_hyp,gb_prior_hyp2);
	  //g2.posMD=new MD(args.size(),args,string("posMD"));
	  foreach(UFList,arg,args){
		if(wordsByPOS[arg->first].size()==0){
			wordsByPOS[arg->first].push_back(pair<U,F>(wordVocab.lookup(unk),1));
			cout<<"no words for pos: "<<tagVocab.lookup(arg->first)<<endl;
		}
		g2.word_given_pos.insert(pair<U,MD*>(arg->first, new MD(wordsByPOS[arg->first].size(),wordsByPOS[arg->first],string("words_given_pos")+tagVocab.lookup(arg->first))));
	  }
	  //word_given_pos tracks which words are possible with which tags.
          //
	  for(U i=0;i<trains.size();i++)
		for(U j=0;j<trains[i].size();j++){
			g2.word_given_pos[trains[i][j].tag]->insert(trains[i][j].word,1);
			//g2.posMD->insert(trains[i][j].tag,1);
		}
	  for(U i=0;i<trains2.size();i++)
		for(U j=0;j<trains2[i].size();j++){
			g2.word_given_pos[trains2[i][j].tag]->insert(trains2[i][j].word,1);
			//g2.posMD->insert(trains2[i][j].tag,1);
		}

	//g2.posMD->reestimate(varType);
	variational_estimate(g2,trains,trains2,devs,tests,*tests10,train_deps,dev_deps,gold_deps10,gold_deps,stage2BeamWidth,niterations,varType,initializerBeamWidth,numBeamIters,train_analyses_stream_ptr,test_analyses_stream_ptr,trace_stream_ptr,init_from_deps,klein_init,random_klein,est_mix_from_dev,useTrains2Beam,readFromFile,writeOnFinish,initSupervised,est_mix);
  }
  else{
	  assert(false);
  }

  //clean up
  if (trace_stream_ptr!=&cout) 
	delete trace_stream_ptr;
 
  if(train_analyses_stream_ptr){
	*train_analyses_stream_ptr<<endl;
	assert(test_analyses_stream_ptr);
	*test_analyses_stream_ptr<<endl;

  }
  if(train_deps) delete train_deps;
  if(dev_deps) delete dev_deps;
  if(gold_deps) delete gold_deps;
  if(all_deps) delete all_deps;
  if(readFromFile) delete readFromFile;
 //         delete analyses_stream_ptr;
  //delete grammar_stream_ptr;
}
