/*
 * Copyright William Headden 2008
 *
*/

#ifndef COUNT_H
#define COUNT_H
#include"utility.h"
#include<map>

#ifdef LINUX
#include<tr1/unordered_map>
#endif
#ifdef OSX
#include<ext/hash_map>
#endif

#include<iostream>
#include<assert.h>

#ifndef ERROR
#define ERROR .0000001
#endif
using namespace std;
template< class T,class CountType = int>
class Count{
	public:
		typedef map<T,CountType> CountTable;
		typedef typename CountTable::iterator iterator;
		typedef typename CountTable::reverse_iterator reverse_iterator;
		typedef typename CountTable::const_iterator const_iterator;
		Count():size_(0),total_(0){}
		//increment and decrement functions, 
		CountType inc(const T & index, CountType amount)
		{//increment count for index by amount
			typename Count::iterator i = counts_.find(index);
			CountType count=0;
			if(i==counts_.end()&&amount>0){
				count=counts_[index]=amount;
				total_+=amount;
				size_++;
			}
			else{
				if(i->second==0&& amount>0)
					size_++;
				count=(i->second+=amount);
				if(i->second==0 && amount<0){//we were decrementing, and we are now at zero
					counts_.erase(i);
					size_--;
				}
				total_+=amount;
			}
			return count;	
		}
		CountType dec(const T & index, CountType amount)//increment count for index by amount
		{
			CountType count=inc(index,-amount);
			if(count<0){
				if(count>-ERROR) set(index,0);
				else{
					cout<<sizeof(CountType)<<endl;
					cout<<"count < 0 "<< (index)<<'\t'<<count<<endl;
					assert(count>=0);
				}
			}
			assert(size_>=0);	
			return count;
		}
		CountType total()const{return total_;}
		void remove(const T & index){
			typename Count::iterator i = counts_.find(index);
			if(i==counts_.end()) return;
			counts_erase(i);	
		}
		void set(const T & index, CountType amount)//set count for index to amount
		{
			typename Count::iterator i = counts_.find(index);
			if(i==counts_.end()){
				//counts_[index] implicitly equal to zero
				if(amount>0){
					counts_[index]=amount;
					size_++;
				}
				total_+=amount;
			}
			else{
				if(i->second==0&& amount>0)
					size_++;
				total_+=amount-i->second;
				i->second=amount;
			}
		}
		CountType get(const T & index) const//return count for index
		{
			typename Count::const_iterator i = counts_.find(index);
			if(i==counts_.end()){
				return 0;
			}
			else{
				return i->second;
			}
		}
		void clear(){
			total_=0;
			size_=0;
			counts_.clear();
		}
		void resize(size_t n){
			counts_.resize(n);
			size_=n;
		}
		size_t size()const{assert(size_==counts_.size());return counts_.size();}
		size_t size2()const{return size_;}
		reverse_iterator rbegin(){return counts_.rbegin();}
		reverse_iterator rend(){return counts_.rend();}
		iterator begin(){return counts_.begin();}
		iterator end(){return counts_.end();}
		const_iterator begin()const{return counts_.begin();}
		const_iterator end()const {return counts_.end();}
		void insert(Count<T> & b){
			counts_.insert(b.begin(),b.end());
		}
		void toList(list<T> & l){
			foreach(typename CountTable,count,counts_){
				if(count->second==0) continue;
				l.push_back(count->first);
			}
		}
		void confirmTotal(){
			CountType newTotal=0;
			CountType newSize=0;
			foreach(typename CountTable,count,counts_){
				newTotal+=count->second;
				if(count->second!=0) newSize++;
			}
			if(newTotal!=total_) cout<<"total does not add up! "<<newTotal<<'\t'<<total_<<endl;
			assert(newTotal==total_);
			assert(newSize==size());
		}
	private:
		CountTable counts_;
		size_t size_;
		CountType total_;
};
template< class T,class CountType = int>
class HashCount{
	public:
#ifdef LINUX
		typedef tr1::unordered_map<T,CountType> CountTable;
#endif
#ifdef OSX
		typedef ext::hash_map<T,CountType> CountTable;
#endif
		typedef typename CountTable::iterator iterator;
		typedef typename CountTable::const_iterator const_iterator;
		HashCount():size_(0),total_(0){}
		//increment and decrement functions, 
		CountType inc(const T & index, CountType amount){//increment count for index by amount
			typename HashCount::iterator i = counts_.find(index);
			CountType count=0;
			if(i==counts_.end()){
				if(amount>0){
					count=counts_[index]=amount;
					total_+=amount;
					size_++;
				}
			}
			else{
				if(i->second==0&& amount>0)
					size_++;
				count=(i->second+=amount);
				if(i->second==0 && amount<0){//we were decrementing, and we are now at zero
					counts_.erase(i);
					size_--;
				}
				total_+=amount;
			}
			return count;	
		}
		CountType dec(const T & index, CountType amount)//increment count for index by amount
		{
			CountType count=inc(index,-amount);
			if(count<0){
				if(count>-ERROR) set(index,amount);
				else{
					cout<<sizeof(CountType)<<endl;
					cout<<"count < 0 "<< (index)<<'\t'<<count<<endl;
					assert(count>=0);
				}
			}
			assert(size_>=0);	
			return count;
		}
		CountType total()const{return total_;}
		void remove(const T & index){
			typename HashCount::iterator i = counts_.find(index);
			if(i==counts_.end()) return;
			counts_erase(i);	
		}
		void set(const T & index, CountType amount)//set count for index to amount
		{
			typename HashCount::iterator i = counts_.find(index);
			if(i==counts_.end()){

				if(amount>0){
					counts_[index]=amount;
					size_++;
				}
				total_+=amount;
			}
			else{
				if(i->second==0&& amount>0)
					size_++;
				total_+=amount-i->second;
				i->second=amount;
			}
		}
		CountType get(const T & index) const//return count for index
		{
			typename HashCount::const_iterator i = counts_.find(index);
			if(i==counts_.end()){
				return 0;
			}
			else{
				return i->second;
			}
		}
		void clear(){
			total_=0;
			counts_.clear();
			size_=0;
			assert(size_==counts_.size());
		}
		void resize(size_t n){
			counts_.resize(n);
			size_=n;
		}
		size_t size()const{assert(size_==counts_.size());return counts_.size();}
		size_t size2()const{return size_;}
		iterator begin(){return counts_.begin();}
		iterator end(){return counts_.end();}
		const_iterator begin()const{return counts_.begin();}
		const_iterator end()const {return counts_.end();}
		void insert(HashCount<T> & b){
			counts_.insert(b.begin(),b.end());
		}
		void toList(list<T> & l){
			foreach(typename CountTable,count,counts_){
				if(count->second==0) continue;
				l.push_back(count->first);
			}
		}
		void confirmTotal(){
			CountType newTotal=0;
			foreach(typename CountTable,count,counts_)
				newTotal+=count->second;
			if(newTotal!=total_) cout<<"total does not add up! "<<newTotal<<'\t'<<total_<<endl;
			assert(newTotal==total_);
		}
	private:
		CountTable counts_;
		size_t size_;
		CountType total_;
};
template<class sub_key, class T,class CountType = int>
class ExtendedHashCount{
	public:
		typedef map<sub_key,HashCount<T,CountType> > EHC;
		typedef typename EHC::iterator iterator;
		typedef typename EHC::const_iterator const_iterator;
		
		ExtendedHashCount():total_(0){}
		ExtendedHashCount(size_t n):total_(0),counts_(n){}
			
		//increment and decrement functions, 
		CountType inc(const sub_key & index1, const T & index, CountType amount){//increment count for index by amount
			if(amount==0) return 0;
			CountType count= counts_[index1].inc(index,amount);
			total_+=amount;
			return count;	
		}
		CountType dec(const sub_key & index1,const T & index, CountType amount)//increment count for index by amount
		{
			CountType count=inc(index1,index,-amount);
			if(count<0){
				if(count>-ERROR) set(index1,index,amount);
				else{
					cout<<sizeof(CountType)<<endl;
					cout<<"count < 0 "<< (index)<<'\t'<<count<<endl;
					assert(count>=0);
				}
			}
			return count;
		}
		CountType total()const{return total_;}
		CountType total(const sub_key & index1)const{
			typename EHC::const_iterator i = counts_.find(index1);
			if(i==counts_.end())
				return 0;
			else
				return i->second.total();
		}
		void set(const sub_key & index1,const T & index, CountType amount)//set count for index to amount
		{
			typename EHC::iterator i = counts_.find(index1);
			if(i==counts_.end()){
				if(amount>0){
					counts_[index1].set(index,amount);
					total_+=amount;
				}
			}
			else{
				CountType oldCount=i->second.get(index);
				total_+=amount-oldCount;
				counts_[index1].set(index,amount);
			}
		}
		HashCount<T,CountType> & get(const sub_key& index1)//return count for index
		{
			return counts_[index1];
		}
		CountType get(const sub_key& index1, const T & index) const//return count for index
		{
			typename EHC::const_iterator i = counts_.find(index1);
			if(i==counts_.end()){
				return 0;
			}
			else{
				return i->second.get(index);
			}
		}
		size_t size(const sub_key & index1)const{
			typename EHC::const_iterator i = counts_.find(index1);
			if(i==counts_.end())
				return 0;
			else
				return i->second.size();	
		}
		iterator begin(){return counts_.begin();}
		iterator end(){return counts_.end();}
		const_iterator begin()const{return counts_.begin();}
		const_iterator end()const {return counts_.end();}
	private:
		CountType total_;
		EHC counts_;
};
#endif
