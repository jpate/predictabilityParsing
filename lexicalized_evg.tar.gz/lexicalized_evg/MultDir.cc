/*
 * Copyright William Headden 2009
 *
*/

#ifndef PITMAN_YOR_CC
#define PITMAN_YOR_CC
#include"MultDir.h"
#include"utility.h"
#include"random.h"
#include"gammavariate.h"
#include<string>
#include<stdlib.h>
#include "digamma.h"
#define EXTRA_DEBUG
template<typename lab_type>
int MultDir2<lab_type>::MLE=0;
template<typename lab_type>
int MultDir2<lab_type>::VAR=1;
template<typename lab_type>
int MultDir2<lab_type>::MAP=2;
template<typename lab_type>
bool MultDir2<lab_type>::point_estimate=false;

template<typename lab_type>
void MultDir2<lab_type>::printStatistics(ostream & out,F threshold){
	vector<LPair> vec(alphas.size());
	int i=0;
	foreach(typename IndexList,in,index){
		vec[i].first=theta_get(*in);
		vec[i].second=*in;
		i++;
	}
	sort(vec.rbegin(),vec.rend());
	out<<"Stats for "<<debug_id<<endl;
	F total=0;
	for(i=0;(U)i<vec.size();i++){
		if(total>threshold) break;
		total+=vec[i].first;
		out<<"\t"<<vec[i].second<<"\t"<<vec[i].first<<'\t'<<alphas2.get(vec[i].second)<<endl;
	}
}
#include"grammar.h"
template<typename lab_type>
F MultDir2<lab_type>::prob(const V & v) const{
		assert(getAlpha(v)>0);
		if(point_estimate) return probPointEstimate(v);
		F pr=theta_get(v);
		assert(pr>=0);
		return pr;
}
#include"Vocab.h"
template<typename lab_type>
void MultDir2<lab_type>::printStatistics(Vocab & v, ostream & out,F threshold){
	vector<LPair> vec(alphas.size());
	int i=0;
	foreach(typename IndexList,in,index){
		vec[i].first=theta_get(*in);
		vec[i].second=*in;
		i++;
	}
	sort(vec.rbegin(),vec.rend());
	out<<"Stats for "<<debug_id<<'\t'<<getAlphaSum()<<'\t'<<getAlpha2Sum()<<endl;
	F total=0;
	for(i=0;(U)i<vec.size();i++){
		if(total>threshold) break;
		total+=vec[i].first;
		out<<"\t"<<vec[i].second<<"\t"<<v.lookup(vec[i].second)<<"\t"<<vec[i].first<<'\t'<<alphas2.get(vec[i].second)<<endl;
	}
}
template<typename lab_type>
void MultDir2<lab_type>::initToPosterior(int type){
	collapsed=false;
	theta_clear();
	//cout<<"initToPosterior "<<debug_id<<endl;
	//F total=0;
	foreach(typename IndexList,i,index){
		if(type==MLE){
			//cout<<'\t'<<*i<<'\t'<<alphas2.get(*i)<<'\t'<<getAlphaSum()<<endl;
			theta_set(*i,alphas2.get(*i)/getAlpha2Sum());
		}
		if(type==VAR){
			theta_set(*i,exp(digamma(alphas2.get(*i))-digamma(getAlpha2Sum())));
		}
		if(type==MAP) assert(false);
	}
	//cout<<"sampled "<<debug_id<<endl;
}
template<typename lab_type>
void MultDir2<lab_type>::initToPrior(int type){
	collapsed=false;
	theta_clear();
	//F total=0;
	foreach(typename IndexList,i,index){
		if(type==MLE)
			theta_set(*i,alphas.get(*i)/getAlphaSum());
		if(type==VAR){
			theta_set(*i,exp(digamma(alphas.get(*i))-digamma(getAlphaSum())));
			alphas2.set(*i,alphas.get(*i));
		}
		if(type==MAP) assert(false);
	}
	//cout<<"sampled "<<debug_id<<endl;
}
template<typename lab_type>
void MultDir2<lab_type>::sample(){
	assert(!collapsed);
	theta_clear();
	F total=0;
	foreach(typename IndexList,i,index){
		F gamma= gammavariate(alphas.get(*i));
		total+=gamma;
		theta_set(*i,gamma);
		if(gamma==0)
			cerr<<"setting alpha to zero in sample(): "<<*i<<endl;
		assert(gamma>0);
		alphas2.set(*i,gamma);
	}
	foreach(typename IndexList,i,index){
		theta_set(*i,theta_get(*i)/total);
	}
	if(debug_id=="S_arg_given_root")
		cout<<"sampled "<<debug_id<<endl;
	
}
template<typename lab_type>
void MultDir2<lab_type>::sample_posterior(F size_factor){
	assert(!collapsed);
	theta_clear();
	F total=0;
	//cout<<"sample_posterior "<<debug_id<<'\t'<<count.total()<<'\t'<<size_factor<<endl;
	foreach(typename IndexList,i,index){
		F gamma= gammavariate(count.get(*i)/size_factor+alphas.get(*i));
		total+=gamma;
		theta_set(*i,gamma);
	}
	foreach(typename IndexList,i,index){
		theta_set(*i,theta_get(*i)/total);
	}
	count.clear();
	//cout<<"sampled "<<debug_id<<endl;
	
}

template< typename lab_type>
void MultDir2<lab_type>::setPrior(MultDir2<lab_type> & old){
	theta_clear();
	F total=0;
	foreach(typename IndexList,i,index){
		F c=old.prob(*i);
		theta_set(*i,c);
		alphas.set(*i,old.alphas.get(*i));
		alphas2.set(*i,old.alphas2.get(*i));
	}
	count.clear();
	collapsed=false;
	assert(total<=1.0000000001);
}
template< typename lab_type>
void MultDir2<lab_type>::initialize(MultDir2<lab_type> & old){
	theta_clear();
	F total=0;
	foreach(typename IndexList,i,index){
		F c=old.prob(*i);
		theta_set(*i,c);
		alphas2.set(*i,old.alphas2.get(*i));
		assert(alphas2.get(*i)>0);
	}
	count.clear();
	collapsed=false;
	assert(total<=1.0000000001);
}
template< typename lab_type>
void MultDir2<lab_type>::variationalEstimate(MultDir2<lab_type> & old){
	theta_clear();
	alphas2.clear();
	F total=0;
	//cout<<"variational estimate for: "<<debug_id<<endl;
	foreach(typename IndexList,i,index){
		F c= old.count.get(*i)+alphas.get(*i);
		F t = old.count.total()+getAlphaSum();
		F c2=exp(digamma(c));
		F t2=exp(digamma(t));
		total+=c2/t2;
		//cout<<'\t'<<*i<<"\t("<<c<<"\t"<<c2<<")\t("<<t<<"\t"<<t2<<")\t"<<c2/t2<<endl;
		theta_set(*i,c2/t2);
		assert(c>0);
		alphas2.set(*i,c);
	}
	count.clear();
	//cout<<"\ttotal="<<total<<'\t'<<log(total)<<endl;
	assert(total<=1.0000000001);
}
template< typename lab_type>
void MultDir2<lab_type>::MLEstimate(MultDir2<lab_type> & old){
	theta_clear();
	F total=0;
	foreach(typename IndexList,i,index){
		F c= old.count.get(*i)+1;//+alphas.get(*i);
		if(log(c)<-20) c=0;//bypass underflow issues with near zeros
		F t = old.count.total()+index.size();//+getAlphaSum();
		F pr=c;
		if(c>0&&t>0)
			pr/=t;
		if(pr>1&&pr<1.00001) pr=1;
		total+=pr;
		theta_set(*i,pr);
		alphas2.set(*i,c);
	}
	count.clear();
	if(total>1 && total<1.00001) total=1;
	if(!(total<=1.0000000001))
		cout<<"\ttotal="<<total<<'\t'<<log(total)<<endl;
	assert(total<=1.0000000001);
}
template< typename lab_type>
void MultDir2<lab_type>::MAPEstimate(MultDir2<lab_type> & old){
	theta_clear();
	F total=0;
	assert(getAlphaSum()-index.size()>=0);
	foreach(typename IndexList,i,index){
		F c= old.count.get(*i)+alphas.get(*i)-1;
		if(log(c)<-20) c=0;
		F t = old.count.total()+(getAlphaSum()-index.size());
		assert(c>=0);
		F pr=c;
		if(c>0&&t>0){
			pr/=t;
		}
		if(pr>1&&pr<1.00001) pr=1;
		total+=pr;
		theta_set(*i,pr);
		alphas2.set(*i,c);
	}
	count.clear();
	if(  !(total<=1.0000001)){
		//cout<<"\ttotal="<<total<<'\t'<<(1.0-total)<<'\t'<<log(total)<<'\t'<<log(theta.total())<<endl;
	}
	assert(total<=1.0000001);
}
//template<typename lab_type>
//F MultDir2<lab_type>::E_logP_wrt_Q(const gsl_vector * x_alpha,U i)const{
//	F lp=0;
//	F alpha_sum=0;
//	cforeach(typename Counter,al,alphas2){
//		//const lab_type &  v =al->first;
//		F alpha_q=al->second;
//		assert(i<x_alpha->size);
//		F alpha_p=x_alpha->data[i];
//		alpha_sum+=alpha_p;
//		lp+=(alpha_p-1)*(digamma(alpha_q)-digamma(alphas2.total()))-lgamma(alpha_p);
//		i++;
//	}
//	lp+=lgamma(alpha_sum);
//	return lp;
//}
template<typename lab_type>
F MultDir2<lab_type>::KLQ_P(){//const HashCount<label_type,F> & l){
	assert(!collapsed);
	F lp=lgamma(alphas2.total())-lgamma(getAlphaSum());
	//cout<<"KLQ_P "<<debug_id<<'\t'<<getAlphaSum()+count.total()<<'\t'<<getAlphaSum()<<endl;
	cforeach(typename Counter,al,alphas){
		const lab_type &  v =al->first;
		F alpha_p=al->second;
		F alpha_q=alphas2.get(v);//count.get(v)+alpha_p;
		if(alpha_q==0)
			cerr<<v<<'\t'<<al->first<<'\t'<<alpha_q<<'\t'<<alpha_p<<endl;
		assert(alpha_q>0);
		lp-=lgamma(alpha_q)-lgamma(alpha_p)-(alpha_q-alpha_p)*(digamma(alpha_q)-digamma(alphas2.total()));
	}
	//cout<<"\tlp="<<lp<<endl;
	return lp;
}
template< typename lab_type>
void MultDir2<lab_type>::insertAll(MultDir2<lab_type> & old){
	cforeach(typename Counter,al,old.count){
		insert(al->first,al->second,false);
	}	
}
template< typename lab_type>
F MultDir2<lab_type>::insert(const V & v,F weight,bool delete_table){
	assert(getAlpha(v)>0);
	if(weight<0)
		return erase(v,weight,delete_table);
	assert(weight>=0);
	F c=count.inc(v,weight);
	c-=weight;
	F n=count.total()-weight;
	assert(count.size()<=k);
	if(collapsed)
		return (c+getAlpha(v))/(n+getAlphaSum());
	else
		return prob(v);
}
template< typename lab_type>
F MultDir2<lab_type>::erase(const V & v,F weight,bool delete_table){
	F c=count.dec(v,weight);
#ifdef EXTRA_DEBUG
	F c2=count.get(v);
	assert(c==c2);
#endif
	if(collapsed)
		return (c+getAlpha(v))/(count.total()+getAlphaSum());
	else
		return prob(v);
	
}

template< typename lab_type>
typename MultDir2<lab_type>::F_T MultDir2<lab_type>::sampleT(){
	assert(index.size()==k);
	assert(collapsed);
	F r = random1()*(n()+getAlphaSum());
	F total=0;
	cforeach(typename list<lab_type>,i,index){
		total+=count.get(*i)+getAlpha(*i);
		if(total>=r)
			return F_T(prob(*i),*i);
	}
	
	assert(false);
	return F_T(1.0,0);
}

template< typename lab_type>
typename MultDir2<lab_type>::F_T MultDir2<lab_type>::sampleTGivenLabel(const V & v){
	if(index.size()!=k)
		cout<<"index size = "<<index.size()<<'\t'<<k<<endl;
	assert(index.size()==k);
	//v is a label *, t i a label***	
	return F_T(1.0,v);
}
template< typename lab_type>
void MultDir2<lab_type>::add(const list<label_type> & l){
	cforeach(typename list<label_type>,i,l)
		index.push_back(*i);
}
template< typename lab_type>
void MultDir2<lab_type>::add(const label_type & l){
	index.push_back(l);
}
template< typename lab_type>
F MultDir2<lab_type>::log2prob_corpus(HashCount<lab_type,F> & dmvcount){
	F lp=0;
	cforeach(typename Counter,i,alphas){
		F c=dmvcount.get(i->first);
		lp+=lgamma(i->second+c)-lgamma(i->second);
	}	
	lp+=lgamma(getAlphaSum())-lgamma(dmvcount.total()+getAlphaSum());
	assert(lp<=0);
	return lp/log(2.0);
}
template<typename lab_type>
F MultDir2<lab_type>::log2prob_corpus()const{
	F lp=0;
	cforeach(typename Counter,i,alphas){
		F c=count.get(i->first);
		lp+=lgamma(i->second+c)-lgamma(i->second);
	}
	lp+=lgamma(getAlphaSum())-lgamma(n()+getAlphaSum());
	assert(lp<=0);
	return lp/log(2.0);
}
/*
template< typename lab_type>
F MultDir2<lab_type>::probSeating()const{
	F logProb=0;
	if (n()==0) return 0;
	if(collapsed){
		cforeach(typename Counter,i,count){
			F al=alphas.get(i->first);
			logProb+=lgamma(i->second+al)-lgamma(al);
		}	
		logProb+=lgamma(getAlphaSum())-lgamma(n()+getAlphaSum());
		//cout<<"probSeating "<<debug_id<<" = "<<logProb/log(2.0)<<endl;
		assert(logProb<=0);
		return logProb;
	}
	else{
		cforeach(typename Counter,i,count){
			logProb+=(log(theta_get(i->first))-log(theta.total()))*i->second;
		}
		assert(logProb<=0);
		return logProb;
	}
}
*/


//template< typename lab_type>
//void MultDir2<lab_type>::print(ostream & out)const{
//	out<<debug_id<<": ";
//	out<<"k="<<k;
//	//out<<" alphas="<<alphas;
//	out<<" n="<<n();
//	out<<" <";
//	cforeach(typename Counter,i,count){
//		out<<i->second<<"("<< alphas.get(i->first) <<")"<<' ';
//	}
//	out<<">"<<endl;
//
//}


  

 

#endif
