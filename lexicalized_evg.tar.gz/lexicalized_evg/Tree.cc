/*
 * Copyright William Headden 2009
 *
*/

#include"Tree.h"
inline bool even(size_t s){
	return s%2==0;
}
Tree::~Tree()
{
	if(left) delete left;
	if(right) delete right;
}
Tree::Tree(const set<Upair> & deps,const Sentence & sent):
		nt(S),ntc(TOP),s(0),e(sent.size()),head(sent.root),left(NULL),right(NULL),sent(sent){
	U N=sent.size()/2;
	Sentence sentence;
	sentence.resize(sent.size());
	for(U i=0;i<sent.size();i+=2)//get an undoubled representation for the rest of it
		sentence[i/2]=sent[i];
	U root=-1;
	vector<U> head(sent.size());
	vector<list<U> > L_args(N);
	vector<list<U> > R_args(N);
	vector<Tree *> L_tree(N,NULL);
	vector<Tree *> R_tree(N,NULL);
	vector<Tree *> ML_tree(N,NULL);
	vector<Tree *> MR_tree(N,NULL);
	vector<Tree *> U_tree(2*N,NULL);
	cforeach(set<Upair>,d,deps){
		assert(d->second>=0&&d->second<N);
		assert(d->first==((U)-1)||(d->first>=0&&d->first<N));
		assert(d->second!=d->first);

		head[d->second]=d->first;

		if(d->first==(U)-1){
			root=d->second;
		}
		else if(d->first>d->second){//left
			L_args[d->first].push_back(d->second);
		}
		else{//right
			R_args[d->first].push_back(d->second);
		}
	}
	list<U> L_agenda;
	list<U> R_agenda;
	L_agenda.push_back(root);
	R_agenda.push_back(root);

	Tree * rootTree=this;
	rootTree->left=new Tree(L,TOP,sentence[root],0,root*2,NULL,NULL,sent);
	rootTree->right=new Tree(R,TOP,sentence[root],root*2+1,N*2-1,NULL,NULL,sent);
	L_tree[root]=rootTree->left;
	R_tree[root]=rootTree->right;
	while(L_agenda.size()+R_agenda.size()>0){
		if(L_agenda.size()>0){//do left
			U h=L_agenda.front();
			L_agenda.pop_front();
			list<U> args(L_args[h]);//copy
			Tree * tree=L_tree[h];
			assert(tree);
			U numArgs=args.size();
			U n=numArgs;
			if(n>=TOP) n=TOP-1;
			tree->left=new Tree(L,n,sentence[h],tree->s,tree->e,NULL,NULL,sent);
			tree=tree->left;
			while(args.size()>0){	
				assert(tree);
				U numArgs=args.size();
				U n=numArgs;
				if(n>=TOP) n=TOP-1;
				U a=args.front();args.pop_front();
				assert(tree->ntc==n);
				tree->left= new Tree(L,TOP,sentence[a],tree->s,a*2,NULL,NULL,sent);
				tree->right=new Tree(ML,n,sentence[h],a*2+1,tree->e,NULL,NULL,sent);
				L_agenda.push_back(a);
				L_tree[a]=tree->left;

				tree=tree->right;
				assert(tree);
				tree->left= new Tree(R,TOP,sentence[a],s,-1,NULL,NULL,sent);
				R_agenda.push_back(a);
				R_tree[a]=tree->left;
				
				if(n==TOP-1&&args.size()>=n){
					tree->right=new Tree(L,TOP-1,sentence[h],-1,tree->e,NULL,NULL,sent);
				}
				else{
					tree->right=new Tree(L,n-1,sentence[h],-1,tree->e,NULL,NULL,sent);
				}
				tree=tree->right;
			}
			assert(tree);
			assert(tree->nt==L&&tree->ntc==0);
			tree->left=new Tree(UL,TOP,sentence[h],tree->s,tree->e,NULL,NULL,sent);
			U_tree[2*h]=tree->left;
		}
		if(R_agenda.size()>0){//do right
			U h=R_agenda.front();
			R_agenda.pop_front();
			list<U> args(R_args[h]);//copy
			Tree * tree=R_tree[h];
			assert(tree);
			U numArgs=args.size();
			U n=numArgs;
			if(n>=TOP) n=TOP-1;

			tree->left=new Tree(R,n,sentence[h],tree->s,tree->e,NULL,NULL,sent);
			tree=tree->left;
			while(args.size()>0){	
				assert(tree);
				U numArgs=args.size();
				U n=numArgs;
				if(n>=TOP) n=TOP-1;

				U a=args.back();args.pop_back();
				assert(tree->ntc==n);

				tree->left=new Tree(MR,n,sentence[h],tree->s,-1,NULL,NULL,sent);
				tree->right= new Tree(R,TOP,sentence[a],-1,tree->e,NULL,NULL,sent);
				R_agenda.push_back(a);
				R_tree[a]=tree->right;

				tree=tree->left;
				assert(tree);
				if(n==TOP-1&&args.size()>=n)
					tree->left=new Tree(R,TOP-1,sentence[h],tree->s,-1,NULL,NULL,sent);
				else
					tree->left=new Tree(R,n-1,sentence[h],tree->s,-1,NULL,NULL,sent);
				tree->right= new Tree(L,TOP,sentence[a],s,-1,NULL,NULL,sent);
				L_agenda.push_back(a);
				L_tree[a]=tree->right;
				
				tree=tree->left;
			}
			assert(tree);
			assert(tree->nt==R&&tree->ntc==0);
			tree->left=new Tree(UR,TOP,sentence[h],tree->s,tree->e,NULL,NULL,sent);
			U_tree[2*h+1]=tree->left;
		}
	}
	for(U i=0;i<2*N;i++){
		assert(U_tree[i]);
		U_tree[i]->s=U_tree[i]->e=i;
	}
	assignEndpoints();
}
void Tree::assignEndpoints(){
	if(left){
		left->assignEndpoints();
		s=left->s;
		e=left->e;
	}
	if(right){
		right->assignEndpoints();
		e=right->e;
	}
	if(!left&&!right) assert(s==e);
}

U rightmostDescendant(const vector<U> & vec,U s, U e){
	if(s==e) return s;
	U m=e;
	for(;m>s;m--){
		if(vec[m]==s) break;
	}
	if(m==s){
		 assert(vec[m]!=s);
		 return s;
	}
	if(m==e){
		if(vec[m]==s) return e;
		else return s;
	}
	return  rightmostDescendant(vec,m,e);
	
	
}
U leftmostDescendant(const vector<U> & vec,U s, U e){
	if(s==e) return s;
	U m=s;
	for(;m<e;m++){
		if(vec[m]==e) break;
	}
	if(m==e){
		 assert(vec[m]!=e);
		 return e;
	}
	if(m==s){
		if(vec[m]==e) return s;
		else return e;
	}
	return leftmostDescendant(vec,s,m);
}
void Tree::write(ostream & out, const Grammar & g){
		if(left){//nonterminal
			//out<<"(" << g.toString(nt,sent[s],sent[e])<<' ';
			out<<"(" << s<<'_'<<g.translate[nt]<<ntc<<'_'<<e<<flush;
			left->write(out,g);
			if(right)
					right->write(out,g);
			out<<")";
		}
		else{
				out<<"("<<s<<'_'<< g.translate[nt]<<ntc<<'_'<<e;
				out<<" "<<g.getWordVocab().lookup(head.word)<<')';
		}
}
void Tree::extract_dependency_set(set<Upair> & deps){
	if(nt==S){
		assert(left&&right);
		assert(left->e/2==right->s/2);
		deps.insert(Upair((U)-1,left->e/2));
	}
	if(nt==L&&right){
		assert(left&&right);
		assert(left->e/2==right->s/2);
		deps.insert(Upair(e/2,left->e/2));
	}
	if(nt==R&&right){
		assert(left&&right);
		assert(left->e/2==right->s/2);
		deps.insert(Upair(s/2,left->e/2));
	}
	if(left)
		left->extract_dependency_set(deps);
	if(right)
		right->extract_dependency_set(deps);

}
void Tree::extract_dependency_list(list<Upair> & deps){
	if(nt==S)
		deps.push_back(Upair((U)-1,left->e/2));
	if(nt==L&&right)
		deps.push_back(Upair(e/2,left->e/2));
	if(nt==R&&right)
		deps.push_back(Upair(s/2,left->e/2));
	if(left)
		left->extract_dependency_list(deps);
	if(right)
		right->extract_dependency_list(deps);

}
void Tree::extract_dependency_vec(vector<U> & depvec){
	list<Upair> deps;
	extract_dependency_list(deps);
	U n=deps.size();
	depvec.resize(n,0);
	foreach(list<Upair>,i,deps)
		depvec[i->second]=i->first;	
}
/*
U Tree::countDifferingDeps(Tree * t){
	vector<U> depvec(e-s,0);
	extract_dependency_vec(depvec);
	U n=depvec.size();
	vector<U> tdepvec(n,0);
	t->extract_dependency_vec(tdepvec);
	
	U count=0;
	for(U i=0;i<n;i++){
		if(tdepvec[i]!=depvec[i])
			count++;
	}
	return count;
}
*/
bool operator==(const Tree & t0, const Tree & t1){
	if(t0.nt!=t1.nt||t0.s!=t1.s||t0.e!=t1.e||t0.head!=t1.head){
		return false;
	}
	if(((bool)t0.left)!=((bool)t1.left)){
		 return false;
	}
	if(((bool)t0.right)!=((bool)t1.right)){

		 return false;
	}
	if(t0.left){
		if(*(t0.left)!=*(t1.left)){return false;}
	}
	if(t0.right){
		if(*(t0.right)!=*(t1.right)){return false;}
	}
	return true;
}
bool operator!=(const Tree & t0, const Tree & t1){return !(t0==t1);}

void Tree::incErule(Grammar * g){
	switch(nt){
		case L:
		case R:
			assert(left);
			break;
		case ML:
		case MR:
		case S:
			assert(left&&right);
			break;
		case UL:
		case UR:
			assert(!left&&!right);
			return;
			break;
		default:
			assert(false);

	}
	if(left) left->incErule(g);
	if(right) right->incErule(g);
	if(right){
		assert(left);
		g->increment_rule(nt,ntc,left->nt,left->ntc,right->nt,right->ntc,sent[s],sent[left->s],sent[e],1.0,false);	
	}
	else{
		if(left->nt==UL||left->nt==UR) return;
		assert(nt==L||nt==R);
		assert(ntc==TOP||ntc==0);
		if(nt!=left->nt) cerr<<nt<<'\t'<<left->nt<<endl;
		assert(nt==left->nt);
		g->increment_rule(nt,ntc,left->nt,left->ntc,head,1.0,false);	
	}
}
