/*
 * Copyright William Headden 2009
 *
*/



#ifndef Chart_H
#define Chart_H
#include"grammar.h"
#include"Tree.h"


#include"Sentence.h"
struct ChartPos{
	ChartPos(){
		for(U i=0;i<NUMNTS;i++){
		    for(U j=0;j<NUMVAL;j++){
			insideProb[i][j]=0.0;
			outsideProb[i][j]=0.0;
			viterbiProb[i][j]=0.0;
			viterbiPos[i][j].first=NULL;
			viterbiPos[i][j].second=NULL;
			viterbiRule[i][j].first=-1;
			viterbiRule[i][j].second=-1;
		    }
		}
	}
	F insideProb [NUMNTS][NUMVAL];	
	F outsideProb [NUMNTS][NUMVAL];	
	F viterbiProb[NUMNTS][NUMVAL];
	pair<ChartPos *, ChartPos *> viterbiPos[NUMNTS][NUMVAL];
	pair<U,U> viterbiRule[NUMNTS][NUMVAL];
	pair<U,U> viterbiRuleC[NUMNTS][NUMVAL];
	U s;
	U e;
};
const word_type & getHeadFromSent(U n,U start,U end,const Sentence & sent);
class Chart{
    public:
	friend F absDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
	friend F sqDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
	friend F invLogDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
	friend F oneDirBranchiness(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
        Chart(const Sentence & s, Grammar * g);
        ~Chart();//changed
  //! ncells() returns the number of cells required for sentence of length n
  //
	struct TFPair{
		TFPair(Tree * t, F p):tree(t),prob(p){}
		TFPair():tree(NULL),prob(0){}
		Tree * tree;
		F prob;
	};
	Tree * extractTree(ChartPos * pos,U p,U pc);
	//Tree * generateRightBranchingTree(const Sentence & sentence);
        F inside(bool debugging=false);
        //F insideFast();
        F outside();
	TFPair viterbiTree();
	void incrementExpectedCounts(Grammar * g);//DMVCount * count);
	void incrementExpectedCounts(){incrementExpectedCounts(grammar);}
	F incrementExpectedCounts2(F (*G)(Chart *,U,U,U,U,U,U,int,int,int));//DMVCount * count);
	void printInside(U n,U nc,U s,U e){
		cout<<"n="<<n<<'\t'<<grammar->translate[n]<<endl;
		cout<<"printinsideProb("<<s<<" "<<e<<" "<<grammar->translate[n]<<nc<<") =\t"<<get(s,e)->insideProb[n][nc]<<'\t'<<log(get(s,e)->insideProb[n][nc])<<endl;
	}
	void printOutside(U n,U nc,U s,U e){
		//cout<<"outsideProb("<<s<<" "<<e<<" "<<grammar->translate[n]<<nc<<") =\t"<<get(s,e)->outsideProb[n][nc]<<endl;
	}
        void constructHarmonicChart();
	Tree * sampleTree(ChartPos * pos,U p,U pc);
    private:
        vector<vector<ChartPos> > chartPositions;
        //ChartPos chartPositions[TWICE_MAX_SENT_LEN][TWICE_MAX_SENT_LEN];
        const Sentence & sentence;
        Grammar * grammar;
	U root;
	U none;
	//TFPair sampleNewHarmonicTree(U par,U s, U e);
	TFPair sampleNewTree(U par,U pc,U s, U e);
	//lc,rc,pc 
	void incViterbi(U p,U pc, U l,U lc,U s){
	     U e=s;
	     ChartPos * pos=get(s,e);
	     F pr=grammar->prob_rule(p,pc,sentence[s]);
	     if(pr> get(s,e)->viterbiProb[p][pc]){
		pos->viterbiProb[p][pc]=pr;
		pos->viterbiPos[p][pc].first=pos;
		pos->viterbiPos[p][pc].second=NULL;
		pos->viterbiRule[p][pc].first=l;
		pos->viterbiRule[p][pc].second=-1;
		pos->viterbiRuleC[p][pc].first=lc;
		pos->viterbiRuleC[p][pc].second=-1;
	     }
		
		
	}
	void incViterbi(U p,U pc, U l,U lc,U s,U e){
	     assert(p==l);
	     ChartPos * pos=get(s,e);
	     F pr=get(s,e)->viterbiProb[l][lc];
	     if(pr==0) return;
	     pr*=grammar->prob_rule(p,pc,l,lc,getHead(p,s,e));
	     if(pr> get(s,e)->viterbiProb[p][pc]){
		pos->viterbiProb[p][pc]=pr;
		pos->viterbiPos[p][pc].first=pos;
		pos->viterbiPos[p][pc].second=NULL;
		pos->viterbiRule[p][pc].first=l;
		pos->viterbiRule[p][pc].second=-1;
		pos->viterbiRuleC[p][pc].first=lc;
		pos->viterbiRuleC[p][pc].second=-1;
	     }
		
		
	}
	void incViterbi(U p,U pc, U l,U lc,U r,U rc,U s,U m,U e){
	     ChartPos * pos=get(s,e);
	     F pr= get(s,m)->viterbiProb[l][lc] 
		* get(m+1,e)->viterbiProb[r][rc];
	     if(pr==0) return;
	     pr*=grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e]);
	     if(pr> get(s,e)->viterbiProb[p][pc]){
		pos->viterbiProb[p][pc]=pr;
		pos->viterbiPos[p][pc].first=get(s,m);
		pos->viterbiPos[p][pc].second=get(m+1,e);
		pos->viterbiRule[p][pc].first=l;
		pos->viterbiRule[p][pc].second=r;
		pos->viterbiRuleC[p][pc].first=lc;
		pos->viterbiRuleC[p][pc].second=rc;
	     }
		
		
	}
	void incInside(U p,U pc, U l,U lc,U r,U rc,U s,U m,U e){
	  if(get(s,m)->insideProb[l][lc] * get(m+1,e)->insideProb[r][rc]>0){
	     F pr=get(s,e)->insideProb[p][pc] +=grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e])
		* get(s,m)->insideProb[l][lc] 
		* get(m+1,e)->insideProb[r][rc];
		assert(pr<=1);
	  }
	  //cout<<"incInsideProb("<<s<<" "<<m<<" "<<e<<" "<<grammar->translate[p]<<pc<<"--> "<<grammar->translate[l]<<lc<<" "<<grammar->translate[r]<<rc<<") =\t"<<get(s,e)->insideProb[p][pc];//<<endl;
	  //cout<<"\t"<<grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e])<<"\t"<<get(s,m)->insideProb[l][lc]<<'\t'<<get(m+1,e)->insideProb[r][rc]<<endl;
	}
	void incInside(U p,U pc, U l, U lc, U s, U e){
		assert(p==l);
		if(get(s,e)->insideProb[l][lc]>0){
			F pr=get(s,e)->insideProb[p][pc]+=grammar->prob_rule(p,pc,l,lc,getHead(p,s,e))	*get(s,e)->insideProb[l][lc];
			assert(pr<=1);
		}

	}
	void incErule(U p,U pc, U l,U lc, U s,U e,Grammar * newG);
	F incErule2(U p,U pc, U l,U lc, U r,U rc,U s,U m,U e,Grammar * newG);
	void incOutside(U p,U pc, U l,U lc,U s,U e){
		F pr=get(s,e)->outsideProb[p][pc];
		if(pr==0) return;
		pr*=grammar->prob_rule(p,pc,l,lc,(p==L)?sentence[e]:sentence[s]);
		get(s,e)->outsideProb[l][lc]+=pr;
		
	}
	void incOutside(U p,U pc, U l,U lc,U r,U rc,U s,U m,U e){
		static F pr2=0;
		if(get(s,e)->outsideProb[p][pc]>0&&(get(s,m)->insideProb[l][lc]>0||get(m+1,e)->insideProb[r][rc]>0)){
			pr2=get(s,e)->outsideProb[p][pc]
				* grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e]);
			get(s  ,m)->outsideProb[l][lc]+= pr2*get(m+1,e)->insideProb[r][rc];
			get(m+1,e)->outsideProb[r][rc]+= pr2*get(s  ,m)->insideProb[l][lc];
		}
		/*
		F pr2=get(s,e)->outsideProb[p][pc];
		if(pr2==0) return;
	  	pr2*= grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e]);
		F pr3=get(m+1,e)->insideProb[r][rc];
		get(s,m)->outsideProb[l][lc]+= pr2*pr3;
					
		pr3 = (get(s,m)->insideProb[l][lc]);
		get(m+1,e)->outsideProb[r][rc]+=pr2*pr3;
		*/
	}
	F prob_rule_harmonic(U par,U pc, U lchild, U lc, U rchild,U rc, U s,U m, U e);
	void incHarmonicErule(U p,U pc, U l,U lc, U r,U rc,U s,U m,U e){
	   static F pr=0;
	   pr= prob_rule_harmonic(p,pc,l,lc,r,rc,s,m,e);
	   if(p==L||p==R||p==S){
		   assert(pr>0);
		   grammar->increment_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e],pr,false);	
	   }
	}
	F getInside(U p,U pc, U l,U lc,U r, U rc,U s,U m,U e){
	   if(get(s,m)->insideProb[l][lc] && get(m+1,e)->insideProb[r][rc])
		   //if(l==R && r==L )
			//assert(sentence[m]==sentence[m+1]);
		   return grammar->prob_rule(p,pc,l,lc,r,rc,sentence[s],sentence[m],sentence[e])
			* get(s,m)->insideProb[l][lc] 
			* get(m+1,e)->insideProb[r][rc];	   
	   return 0;
	}
        
        ChartPos * get(U s, U e){
		return &(chartPositions[s][e]);//[(e*(e-1))/2+s]);
	}

	U ncells(U n) { return n*(n+1)/2; }
	const word_type & getHead(U par, U s, U e)const{
		return getHeadFromSent(par,s,e,sentence);
	}
	//TablePointers * assignNewTablePointers(U par, U left, U s,U e);
	//TablePointers * assignNewTablePointers(U par, U left, U right, U s,U m,U e);
};

F absDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
F sqDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
F invLogDistance(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
F oneDirBranchiness(Chart * C,U p,U pc, U l,U lc, U r,U rc,int s,int m,int e);
F dirHeight(Tree * t);
#endif
