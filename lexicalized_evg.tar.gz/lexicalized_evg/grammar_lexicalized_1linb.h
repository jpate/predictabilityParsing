/*
 * Copyright William Headden 2009
 *
*/

#ifndef GRAMMAR_LEXICALIZED_1LINB_H
#define GRAMMAR_LEXICALIZED_1LINB_H

using namespace std;
#include<iostream>
#include<string>
#include<vector>
class Grammar;
#include "Vocab.h"
//#include "dependency.h"
#include "MultDir.h"
#include "types.h"

/*
 * Model:
 * More simply:
 *
 * S -> L R
 * L -> L^n, n\in 0,1,2,...,n-1;Np
 * L^n -> L ML^n         //predict  v |  in n place
 * ML^Np -> R L^Np | R L^N-1 	//predict whether to stop
 * ML^n -> R L^n-1  
 * L^0 -> ul

 * R -> R^Np | R^n, n \in 0,1,2,...,n-1
 * R^n -> MR^n R,  n \in 1,2,...N-1,Np
 * MR^Np -> R^Np L | R^N-1 L
 * MR^n -> R^n-1 L
 * R^0 -> ur
 */

//backoff:


#include"grammar.h"
#include"grammar_uvg_6lin.h"

class Grammar_lexicalized_1linb:public Grammar{
	public:
		static string type_id;
		typedef list<pair<U,F> > UFList;
		Grammar_lexicalized_1linb(MetaGrammar * mg);
		Grammar_lexicalized_1linb(Grammar_uvg_6lin * model0,MetaGrammar * mg);//initialize from model0
		~Grammar_lexicalized_1linb(){
			delete_dists();
		}
		F prob_rule(U par, U pc,U l,U lc,const word_type & word);//prob L_TOP -> L_n
		F prob_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e);

		F increment_rule(U par,U pc, U l,U lc, const word_type & word,F count,bool delete_table);
		F increment_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e, F count,bool delete_table);
		void write(ostream & out);
		F probSeating() const;
		static void generateSymbols(Vocab & tagVocab,list<pair<U,F> > & arg_symbols,list<pair<U,F> > & stop_symbols);
		MD * get_aw_given_arg(U arg);
		static U NUMSTOP;
		static U NUMARG;
	private:
		F logProbCorpus;
		U numTerminals;
		W_MD aw_given_arg;
		U numTagMixBuckets;
		Bucket tagBucket;
		U numWordTagMixBuckets;
		BucketClass<pair<U,U> > wordTagBucket;
		class AttDist{

		   public:
			AttDist(Grammar_lexicalized_1linb * gram,UFList & args, UFList & words,UFList & stops, const string & direction,Vocab & tv, Vocab & wv);
			//get specific distributions
			F stop_given_head_valence_hw_prob(U head, U v,U hw, U arg);
			F stop_given_head_valence_hw_inc( U head, U v,U hw, U arg,F weight);
			F arg_given_head_valence_hw_prob(U head, U v,U hw, U arg);
			F arg_given_head_valence_hw_inc( U head, U v,U hw, U arg,F weight);
			F arg_given_head_valence_inc( U head, U v, U arg,F weight);
			F aw_given_arg_head_valence_hw_prob(U arg,U head, U v,U hw, U aw);
			F aw_given_arg_head_valence_hw_inc(U arg,U head, U v,U hw, U aw, F weight);

			void cleanup();//remove any empty restaurants	


			void write(ostream & out);
			F probSeating() const;
			void setCollapsed(bool c);
			F log2prob_corpus();
			MD * get_arg_given_head_valence_hw(U ht,U v,U hw);
			MD * get_arg_mix_given_head_valence_hw(U h,U v,U hw);
			MD * get_arg_given_head_valence(U ht,U v);
			MD * get_arg_given_valence(U v);
			MD * get_arg_mix_given_head_valence(U h,U v);
			MD * get_aw_given_arg(U arg);

			MD * get_stop_given_head_valence(U h,U v);
			Vocab & getTagVocab(){return tagVocab;}
			Vocab & getWordVocab(){return wordVocab;}
		   private:
			const UFList & getWordList(U arg){return g->getWordList(arg);};	
			UFList & getArgs(){return args;}
			UFList & getWords(){return words;}
			Vocab & tagVocab;
			Vocab & wordVocab;
			string dir;
			UFList & args;
			UFList backoffs;
			UFList backoffs2;
			UFList args_or_backoff;
			UFList args_or_backoff2;
			UFList & words;
			UFList & stops;

			F arg_given_head_valence_prob(U head, U v, U arg);


			VW_MD   stop_given_head_valence;

			VWW_MD  arg_given_head_valence_hw;
			VW_MD  arg_given_head_valence;
			W_MD   arg_given_valence;
			VW_MD   arg_mix_given_head_valence_hw;		//mix: 
			VW_MD   arg_mix_given_head_valence;		//mix: 

			pair<U,F> backoffToHeadValence;
			pair<U,F> nobackoffToHeadValence;
			pair<U,F> backoffToValence;
			pair<U,F> nobackoffToValence;
			public:
				Grammar_lexicalized_1linb * g;


		};//Grammar::AttachmentDistribution
		class RootAttDist{

		   public:
			RootAttDist(Grammar_lexicalized_1linb * gram,UFList & args,UFList & words, Vocab & tv, Vocab & wv);
			//get specific distributions
			F arg_given_root_prob(U arg);
			F aw_given_root_arg_prob(U arg,U aw);

			F arg_given_root_inc(U arg,F weight);
			F aw_given_root_arg_inc(U arg,U aw,F weight);
			void reestimate(int type,RootAttDist & d);
			F KLQ_P();
			void setCollapsed(bool c);
			void printStatistics(ostream & out,F threshold);
			MD * get_arg_given_root(){return &arg_given_root;}
		   private:
			const UFList & getWordList(U arg){return g->getWordList(arg);};	
			Vocab & getTagVocab(){return tagVocab;}
			Vocab & getWordVocab(){return wordVocab;}
			Vocab & tagVocab;
			Vocab & wordVocab;
			string dir;
			UFList & args;
			UFList & words;
			MD arg_given_root;
			MD * get_aw_given_arg(U arg);
		public:
			Grammar_lexicalized_1linb * g;
		private:
			static MD * getMD(const U & h, W_MD & md);
			static MD * getMD(U h, U v, VW_MD & md);



		};//Grammar::AttachmentDistribution
		friend class Grammar;
		RootAttDist      S_root_att;
		AttDist L_att;
		AttDist R_att;

	public:
		MD * get_arg_given_root(){return S_root_att.get_arg_given_root();}
		
		//MD::F_T  sample_stop_table(U par, U v,U h, U arg);
		//MD::F_T  sampleL_arg_table(U par, U v,U h, U arg);
		//MD::F_T  sampleM_stop_table(U par, U h, U neighbor,U arg);
		//MD::F_T sampleML_arg_table(U par, U h, U neighbor,U arg);
	friend ostream & operator<<(ostream & out, Grammar &G);
};
//istream & operator>>(istream & in, Grammar &G);


#endif

