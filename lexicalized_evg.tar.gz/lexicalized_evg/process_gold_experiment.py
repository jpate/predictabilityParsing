#!/usr/bin/env python
from __future__ import division
from itertools import izip
import re,sys


#from AIMA import DefaultDict

base   = '/home/headdenw/research/markPCFGsamplers/lexicalized2/'
hogdir=base+'hog_induced/'
tagdir = '/home/headdenw/research/markHMM/Unsup-HMM-POS-tagger/hog/'

def process_experiment(path_name=None,off=0,beamWidth2=50,crit=2):
	i=-1
	DA=[]
	UA=[]
	DAtest=[]
	UAtest=[]
	DAtest2=[]
	UAtest2=[]
	for t in range(0,10):
		DAmin=0
		UAmin=0
		DAmin_test=0
		UAmin_test=0
		DAmin_test2=0
		UAmin_test2=0
		min=float('infinity')
		count=0
		minID=-1
		for s in range(0,beamWidth2):
			i+=1
			if(i!=t*beamWidth2+s):
				print 'FAIL'
			filename=path_name+str(t*beamWidth2+s)
			#print filename
			try:
				lines=open(filename,'r')
			except IOError:
				print filename +" not found"
				continue
			line=''
			try:
				while 1:
					line = lines.next()
					if line[0:8]=='Finished':
						line= lines.next()
						break

			except StopIteration:
				continue
			count+=1
			fields=line.split();

			if(crit==4 or crit==5 or crit==11 or crit==13 or crit==15 or crit==17):
				fields[crit]=-float(fields[crit])
			if min>float(fields[crit]) :
				min=float(fields[crit])
				DAmin=float(fields[10+off])
				UAmin=float(fields[12+off])
				DAmin_test=float(fields[14+off])
				UAmin_test=float(fields[16+off])
				if False:
				#if True:
					DAmin_test2=float(fields[18+off])
					UAmin_test2=float(fields[20+off])
				minID=t*beamWidth2+s
		print t,'FE: ',min,'DA:',DAmin,DAmin_test,DAmin_test2,
		print 'UA:',UAmin,UAmin_test,UAmin_test2,'count',count,'/',beamWidth2,' id=',minID
		DA.append(DAmin)
		UA.append(UAmin)
		DAtest.append(DAmin_test)
		UAtest.append(UAmin_test)
		DAtest2.append(DAmin_test2)
		UAtest2.append(UAmin_test2)
	
	print 'DA:',len(DA),sum(DA)/len(DA), sum(DAtest)/len(DAtest),sum(DAtest2)/len(DAtest2),
	print 'UA:',len(UA),sum(UA)/len(UA), sum(UAtest)/len(UAtest),sum(UAtest2)/len(UAtest2)
if __name__ == "__main__":
    print 'usage: process_gold_experiment.py hogpath [off=1] [beamwidth=50] [crit=2]'
    if len(sys.argv) > 1:
	hogpath=sys.argv[1]
	if hogpath[-1]!='/' :
		hogpath+='/'
	print hogpath
	logdir=hogpath+'logs/'
	off=0
	if len(sys.argv) > 2:
		off=int(sys.argv[2])
	beamwidth=50
	if len(sys.argv) > 3:
		beamwidth=int(sys.argv[3])
	crit=2
	if len(sys.argv) > 4:
		crit=int(sys.argv[4])
		
	process_experiment(logdir,off=off,beamWidth2=beamwidth,crit=crit)
	
	
    # calc_fscore_variance()
# for each numtags in 10,20,40:
# 	for each run in hog_0_0_numtags/tags 0-20:
#		run dmv,uvg6,uvg6_lin
#
# result: for each system in dmv,uvg6,uvg6_lin:
#		for each number of tags in 10,20,40
#			for each run of the tagger 0-20
#				run beamWidth2 times with each setting	
#


