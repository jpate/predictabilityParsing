/*
 * Copyright William Headden 2009
 *
*/

#ifndef MULTDIR_H
#define MULTDIR_H

#include<map>
#include<set>
#include<iostream>
#include<assert.h>
#include<list>
#include<gsl/gsl_sf.h>
#include<gsl/gsl_randist.h>
#include"types.h"
#include"Count.h"
#include"Vocab.h"
#include"mt19937ar.h"
//The goal is modular classes, for allowing easy HDP-models
//Each class has several typenames associated with them,
// for each gluing together the distributions:
//
//label_type: specifies the label of the base-most distribution.
//V: shorthand for label_type
//table_type: 	specifies a table for that distribution.
//		Distributions w/out backoff will have this = label_type
//F_T:		pair<F,table_type>
//
//Each distribution supports the following operations:
// F prob(const table_type & table) const;
// 	The probability of table.  
// 	If the structure is a new table, give the probability of 
// 	generating some new table, times the probability of 
// 	table's backoff structure.
// F prob(const label_type & label) const;
// 	The probability of the label, summing over all tables (old & new)
// F probGivenLabel(const table_type & table,const label_type & label) const;
//
// F insert(const table_type & t);
// 	insert t into the structure, including any backoff structures.
// 	typically, t will be sampled using sampleT, so it may be an existing
// 	structure pointing to tables in the backoff chain, without actually 
// 	being in the restaurant.
//
// F erase(table_type &t, bool delete_table);
//	erase t from the restaurant.  if delete_table is true, the pointer
//	will actually be deleted, and replaced with NULL. Typically if one
//	evacuates in the standard M-H way, you will not want to delete this.
//      It returns the probability of the table, if one were to insert
//      it anew.
//
// F_T sampleTGivenLabel(V & v);
// 	sample a table+probability, given v;
// F_T sampleT();
// 	sample a table
//
//

class Dist{
	public:
		virtual void setCollapsed(bool c){assert(false);}
		virtual void reestimate(int type)=0;

		virtual F KLQ_P(){assert(false);return 0;}
		virtual void sample_posterior(F size_factor){assert(false);}
		virtual void initToPrior(int type){assert(false);}
		virtual void printStatistics(Vocab & v, ostream & out,F threshold=1){assert(false);}
		virtual void clearCounts(){assert(false);}
		virtual const string & getID()=0;
		virtual void read(istream & in)=0;
		virtual void write(ostream & in) const=0;
};
using namespace std;
template<typename lab_type>
class MultDir2:public Dist{
	public:
		typedef lab_type label_type;
		typedef label_type table_type;
		typedef label_type V;   //these will be the same for the MultDir, since there are no underlying levels
		typedef HashCount<label_type,F> Counter;
		string debug_id;
		const string & getID(){return debug_id;}
		U k;  //number of elements
		//F alpha;
		F n()const{return count.total();}
		//! operator() returns the approximate probability for inserting v
		//
		static bool point_estimate;
		MultDir2(){}
		MultDir2(U numOptions,const list<pair<label_type,F> > & labels,const string & d_id,bool sparse=true):
			debug_id(d_id),
			k(numOptions),
			sparse_theta(sparse)
		{
			typedef list<pair<label_type,F> > L;
			assert(labels.size()==numOptions);
			assert(numOptions>0);
			collapsed=false;
			label_type max_label=0;
			cforeach(typename L,i,labels){
				if(i->first>max_label)
					max_label=i->first;
				add(i->first);
				alphas.inc(i->first,i->second);
				alphas2.inc(i->first,i->second);
			}
			if(!sparse_theta)
				theta_nonsparse.resize(max_label+1,1.0/labels.size());
			cforeach(typename L,i,labels){
				theta_set(i->first,getAlpha(i->first)/getAlphaSum());
			}
	
		}
		void read(istream & in)
		{
			cforeach(typename IndexList,i,index){
				label_type lab;
				F alpha2,alpha;
				in>>lab>>alpha2>>alpha;
				//cout<<lab<<'\t'<<alpha2<<'\t'<<alpha<<endl;
				if(lab!=*i){
					cout<<"ERROR, "<<lab<<"!="<<*i<<'\t'<<debug_id<<endl;
				}
				assert(lab==*i);
				assert(alphas.get(lab)==alpha&&alpha>0);
				assert(alpha2>=alpha);
				assert(lab>0);
				alphas2.set(lab,alpha2);
			}
			initToPosterior(VAR);	
			clearCounts();
		}
		F log2prob_corpus(HashCount<lab_type,F> & dmvcount);
		F log2prob_corpus()const;
		bool getCollapsed(){return collapsed;}
		void setCollapsed(bool c){
			collapsed=c;
			sample();
		}
		void reestimate(int type,const MultDir2<lab_type> & old){
			assert(&old==this);
			reestimate(type);	
		}
		void reestimate(int type){
			MultDir2<lab_type> & old=*this;
			if(type==VAR)
				variationalEstimate(old);
			else if(type==MLE)
				MLEstimate(old);
			else if(type==MAP)
				MAPEstimate(old);
			else{
				cout<<"type="<<type<<endl;
				assert(false);
			}
		}
		static int VAR,MLE,MAP;
		void variationalEstimate(MultDir2<lab_type> & old);//const HashCount<label_type,F> & m);
		void MLEstimate(MultDir2<lab_type> & old);//const HashCount<label_type,F> & m);
		void MAPEstimate(MultDir2<lab_type> & old);//const HashCount<label_type,F> & m);
		void initialize(MultDir2<lab_type> & old);
		void initialize(MultDir2<lab_type> * old){initialize(*old);}
		void setPrior(MultDir2<lab_type> & old);
		void setPrior(MultDir2<lab_type> * old){setPrior(*old);}

//		F E_logP_wrt_Q(const gsl_vector * x_alpha,U i)const;
//		F partialF_partialAlpha(const label_type & i) const{
//			//gsl_sf_psi performs digamma function
//			return gsl_sf_psi(getAlphaSum())-gsl_sf_psi(getAlpha(i))+gsl_sf_psi(getAlpha2(i))-gsl_sf_psi(getAlpha2Sum());
//		}
//		F partialSqF_partialAlphaiAlphaj(const label_type & i,const label_type & j) const{
//			//gsl_sf_psi performs digamma function
//			return gsl_sf_psi(getAlphaSum())-gsl_sf_psi(getAlpha(i))+gsl_sf_psi(getAlpha2(i))-gsl_sf_psi(getAlpha2Sum());
//		}
		F KLQ_P();//const HashCount<label_type,F> & l);
		F KLQ_P2();//const HashCount<label_type,F> & l);
		void sample();
		void sample_posterior(F size_factor);
		void initToPrior(int type);
		void initToPosterior(int type);
		F getAlpha(const label_type & l) const{
			return alphas.get(l);
		}
		F getAlpha2(const label_type & l) const{
			return alphas2.get(l);
		}
		void setAlpha2(const label_type & l,F f){
			alphas2.set(l,f);
		}
		void setAlpha(const label_type & l,F f){
			alphas.set(l,f);
		}
		F getAlphaSum() const{
			return alphas.total();
		}
		F getAlpha2Sum() const{
			return alphas2.total();
		}
  		F prob(const V & v) const;
  		F probPointEstimate(const V & v) const{
			assert(!collapsed);
			F pr=alphas2.get(v);
			if(pr>0) pr/=((F)alphas2.total());
			
			//assert(alphas2.total()>0);
			if(!(pr>=0)) cout<<"error, pr("<<v<<") ="<<alphas2.get(v)<<'\t'<<alphas2.total()<<'\t'<<pr<<endl;
			assert(pr>=0);
			if(pr>1&&pr<=1.00001) pr=1;
			return pr;
		}
		F probGivenLabel(const table_type & table,const label_type & label) const{
			if(to_label(table)==label)
				return 1;
			return 0;
		}
		F insert(const V & v, F weight=1.0,bool delete_table=false);
		void insertAll(MultDir2<lab_type> & old);
		F erase(const V & v,F weight,bool delete_table);
		typedef pair<F,table_type> F_T;
		F_T sampleTGivenLabel(const V & v);
		F_T sampleT();
		
		void write(ostream & out)const{
			cforeach(typename IndexList,i,index){
				out<<*i<<'\t'<<alphas2.get(*i)<<'\t'<<alphas.get(*i)<<endl;
			}
		}
		typedef pair<F,lab_type> LPair;	
		void printStatistics(Vocab & v, ostream & out,F threshold=1);
		void printStatistics( ostream & out,F threshold=1);
		static const V & to_label(const table_type & at){
			return at;
		}
		bool sanity_check() const;
		//F probSeating()const;
		void clearCounts(){count.clear();}
	
	private:
		bool sparse_theta;
		F theta_get(const label_type & l)const{
			if(sparse_theta)
				return theta_sparse.get(l);
			assert(l>=0&&l<theta_nonsparse.size());
			return theta_nonsparse[l];
		}
		void theta_set(const label_type & l,F f){
			if(sparse_theta){
				theta_sparse.set(l,f);
			}
			else{
				assert(l>=0&&l<theta_nonsparse.size());
				theta_nonsparse[l]=f;
			}
		}
		void theta_clear(){
			if(sparse_theta){
				theta_sparse.clear();
			}
			else{
				for(U i=0;i<theta_nonsparse.size();i++)
					theta_nonsparse[i]=0;	
			}
		}
		bool collapsed;
		void add(const label_type & l);
		void add(const list<label_type> & l);
		Counter count;
		Counter theta_sparse;
		vector<F> theta_nonsparse;
		Counter alphas;
		Counter alphas2;//alphas after variational estimate
		typedef list<label_type> IndexList;
		IndexList index;

};
#include"digamma.h"
class GammaPostBetaPrior:public Dist{
	
	public:
		string debug_id;
		const string & getID(){return debug_id;}
		void read(istream & in){}
		void write(ostream & in)const{}
		typedef MultDir2<U> MD;
		void setCollapsed(bool c){
			F sum=0;
			cforeach(list<MD *>,dist,mds){
				MD* md = *dist;
				assert(md->getAlpha2(val)>0);
				sum-=digamma(md->getAlpha2(val))-digamma(md->getAlpha2Sum());
			}
			setB(sum+b0);
			cout<<"setCollapsed E_q beta = "<<mean()<<endl;
		}
	
		void reestimate(int type){
			assert(type==MD::VAR);
			F m=mds.size();//number of distributions
			F sum=0;
			//cout<<"reestimating Gamma for number of mixture distributions:"<<mds.size()<<endl;
			cforeach(list<MD *>,dist,mds){
				MD* md = *dist;
				//cout<<"\tMD "<<md->debug_id<<'\t'<<val<<'\t'<<md->getAlpha2(val)<<'\t'<<md->getAlpha2Sum()<<endl;
				assert(md->getAlpha2(val)>0);
				sum-=digamma(md->getAlpha2(val))-digamma(md->getAlpha2Sum());
			}
			assert(sum>0);
			setA(m+getA0());
			setB(sum+getB0());
			F mn=mean();
			cout<<"set E_q beta = "<<mn<<endl;
			cforeach(list<MD *>,dist,mds){
				MD* md = *dist;
				md->setAlpha(val,mn);
			}
		}
		GammaPostBetaPrior(F c1,F c2,U v):val(v),a(c1),b(c2),a0(c1),b0(c2){
			       	gsl_rng_env_setup();
			       	const gsl_rng_type * T = gsl_rng_default;
			       	ran = gsl_rng_alloc (T);
				gsl_rng_set(ran,mt_genrand_int32());	
		}
		GammaPostBetaPrior(F c1,U v):val(v),a(c1),b(c1),a0(c1),b0(0){
			       	gsl_rng_env_setup();
			       	const gsl_rng_type * T = gsl_rng_default;
			       	ran = gsl_rng_alloc (T);
				gsl_rng_set(ran,mt_genrand_int32());	
		}
		~GammaPostBetaPrior(){
			       gsl_rng_free(ran);
			       mds.clear();
		}
		F KLQ_P(){
			F numSamples=100;
			F sum_log=0;
			F sum=0;
			F total=0;
			for(int i=0;i<numSamples;i++){
				F beta=2;
				int count=0;
				while(beta>1){
					beta=gammavariate(a,b);
					//cout<<"drew "<<beta<<" from gamma("<<a<<','<<b<<")"<<endl;
					total++;
					assert(count<numSamples*20);
				}
				sum_log+=log(beta);
				sum+=beta;
			}
			if(total>numSamples*10)
				cout<<"acceptance rate: "<<numSamples/total<<'\t'<<total<<endl;
			F Elog=sum_log/numSamples;
			F Ebeta=mean();
			F result=0;
			if(b0==0)//Beta prior conditional gamma posterior
				result= -(log(a0)+(a0-1)*Elog //prior
					  -((a-1)*(Elog)+a*log(b)-b*Ebeta-loggammainc(a,b)));//posterior
			else//gamma prior gamma postierior
				
				result=	-( ((a0-1)*(Elog)+a0*log(b0)-b0*Ebeta-lgamma(b0))
					  -((a -1)*(Elog)+a *log(b )-b *Ebeta-lgamma(b )));
			result-=mds.size()*(Elog-log(Ebeta));//KLQ_P calculations for lambdas are incorrect, this will adjust them
			//cout<<"KLQ_P:"<<result<<'\t'<<Elog<<'\t'<<Ebeta<<'\t'<<Ebeta2<<'\t'<<b<<endl;
			assert(result>=0);
			return result;
			
		}
		F mean(){
			F m=((gsl_sf_gamma_inc_P(a+1,b)/gsl_sf_gamma_inc_P(a,b))/b)*a;
			if(!(m<=1)){
				cerr<<"m="<<m<<'\t'<<a<<'\t'<<b<<'\t'<<gsl_sf_gamma_inc_P(a+1,b)<<'\t'<<gsl_sf_gamma_inc_P(a,b)<<endl;
				assert(m<=1);
			}
			assert(m>0);
			return m;
		}//norm_gamma_inc(a+1,b)/norm_gamma_inc(a,b)*(a/b)
		void sample_posterior(F size_factor){assert(false);}
		void initToPrior(int type){}
		void printStatistics(Vocab & v, ostream & out,F threshold=1){}
		void clearCounts(){}
		const F & getA()const{return a;}
		const F & getB()const{return b;}
		const F & getA0()const{return a0;}
		const F & getB0()const{return b0;}
		void setA(F aa){a=aa;};
		void setB(F bb){b=bb;};
		void addMD(MD * md){mds.push_back(md);a++;b++;}
	private:
		U val;
		list<MD*> mds;
		F a;//first parameter of posterior gamma
		F b;//second parameter of posterior gamma
		F a0;
		F b0;
		gsl_rng * ran;
		F gammavariate(F a,F b){return gsl_ran_gamma(ran,a,1.0/b);}
		F loggammainc(F a,F b){return log(gsl_sf_gamma_inc_P(a,b))+log(gsl_sf_lngamma(a));}
};
void testMultDir();
void testPYAdaptor();

#include"MultDir.cc"
#endif
