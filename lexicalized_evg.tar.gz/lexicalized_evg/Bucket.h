/*
 * Copyright William Headden 2009
 *
*/

#ifndef BUCKET_H
#define BUCKET_H
#include"utility.h"
#include<vector>
#include"Count.h"
#include"types.h"
#include<limits.h>
#ifdef LINUX
#include<tr1/unordered_map>
#endif
#ifdef OSX
#include<ext/hash_map>
#endif
using namespace std;
/*
namespace tr1{
  template<class T1, class T2> struct hash<std::pair<T1,T2> > {
    size_t operator()(const std::pair<T1,T2>& p) const
    {
      size_t h1 = hash<T1>()(p.first);
      size_t h2 = hash<T2>()(p.second);
      return h1 ^ (h1 >> 1) ^ h2 ^ (h2 << 1);
    }
  };


}
*/
//typedef hash<std::pair<U,U> > std::tr1::hash<std::pair<U,U> >;

#ifdef LINUX
template <class type>
class BucketClass:public tr1::unordered_map<type,U,ext::hash<type> >{
	typedef tr1::unordered_map<type,U,ext::hash<type> > CountTable;
#endif
#ifdef OSX
template <class type>
class BucketClass:public ext::hash_map<type,U,ext::hash<type> >{
	typedef ext::hash_map<type,U,ext::hash<type> > CountTable;
#endif
	public:
		BucketClass(int numBuckets,const Count<type> & count):CountTable(){
			int min=INT_MAX;
			int max=0;
			cforeach(typename Count<type>,c,count){
				if(c->second>max) max=c->second;	
				if(c->second<min) min=c->second;	
				//assert(c->first<this->size());
			}
			F max_ent=0;
			F arg_max_ent=2;
			for(F i=1.1;i<5;i+=.1){
				//cout<<"calculating bucket entropy for base "<<i<<endl;
				vector<F> countPerBucket(numBuckets,0);
				F lmax=log(max)/log(2);
				//F lmin=log(min)/log(2);
				F bucketSize=lmax/numBuckets;
				F total=0;
				cforeach(typename Count<type>,c,count){
					int bucket=(int)(log(F(c->second))/bucketSize/log(i));
					if(bucket<0) bucket=0;
					if(bucket>=numBuckets) bucket=numBuckets-1;
					countPerBucket[bucket]++;
					total++;
				}
				F ent=0;
				for(int j=0;j<numBuckets;j++){
					F pr=countPerBucket[j]>0?countPerBucket[j]/total:0;
					ent-=pr*log(pr);
					//cout<<'\t'<<i<<'\t'<<j<<'\t'<<countPerBucket[j]<<'\t'<<total<<endl;
				}
				//cout<<"entropy="<<ent<<endl;
				if(ent>max_ent){
					max_ent=ent;
					arg_max_ent=i;
				}
				//if(countPerBucket[numBuckets-1]==0) break;
					
			}
			//cout<<"arg_max_ent="<<arg_max_ent<<'\t'<<max_ent<<endl;
			//item c gets placed in bucket i if (c-min)/numBuckets
			F bucketSize=(log(max)/log(arg_max_ent)/F(numBuckets));
			cforeach(typename Count<type>,c,count){
				int bucket=(int)(log(F(c->second)))/bucketSize/log(arg_max_ent);//int 
				if(bucket<0) bucket=0;
				if(bucket>=numBuckets) bucket=numBuckets-1;
				(*this)[c->first]=bucket;
			}
			
				
			
		}

	private:




};
typedef BucketClass<U> Bucket;
#endif
