/*
 * Copyright William Headden 2009
 *
*/

#include"grammar_uvg_6lin.h"
#include"grammar_uvg.h"
#include"dependency.h"
#include<fstream>
#include"Chart.h"
#include<math.h>
U Grammar_uvg_6lin::NUMSTOP=2;
U Grammar_uvg_6lin::NUMARG=2;
string Grammar_uvg_6lin::type_id="Grammar_uvg_6lin";
void Grammar_uvg_6lin::initRandUVG(const vector<Sentence> & sents,int varType){
  Grammar_uvg * model0 =new Grammar_uvg(getMetaGrammar());
  model0->setCollapsed(false,true,true);
  int numIterations=1;
  for (int iteration=0;iteration<numIterations;iteration++){
	  cout<<"uvg iteration "<<iteration<<endl;
	  for (U i = 0; i < sents.size(); ++i) {
		assert(sents[i].size()>0);
		Chart p(sents[i],model0);
		F tprob = p.inside();
		assert(tprob>=0&&tprob<=1);
		p.outside();
		p.incrementExpectedCounts(model0);//count0);
	  }
	  if(iteration<numIterations-1)
		  model0->reestimate(varType,true,true);
  }
  cout<<"statistics for DMV"<<endl;
  ofstream out("asdf");
  model0->printStatistics(out);
  cout<<"statistics for uvg6lin"<<endl;
	cforeach(UFList,iter,getArgs()){
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_valence(n)->insertAll(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_valence(n)->insertAll(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
		}

	}
	cforeach(UFList,iter,getArgs()){
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_head_valence(iter->first,n)->insertAll(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_head_valence(iter->first,n)->insertAll(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
			if(varType==0){
				L_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("NOBACKOFF"),getMetaGrammar()->backoffAlpha.second,false);
				L_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("BACKOFF"),getMetaGrammar()->backoffAlpha.first,false);
				R_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("NOBACKOFF"),getMetaGrammar()->backoffAlpha.second,false);
				R_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("BACKOFF"),getMetaGrammar()->backoffAlpha.first,false);
			}
		}

	}
	get_arg_given_root()->insertAll(*(model0->get_arg_given_root()));
	typedef pair<U,U> UPair;
	cforeach(UFList,iter,getArgs()){
		for(U n=0;n<NUMSTOP;n++){
			L_att.get_stop_given_head_valence(iter->first,n)->insertAll(*(model0->L_att.get_stop_given_head_valence(iter->first,n)));
			R_att.get_stop_given_head_valence(iter->first,n)->insertAll(*(model0->R_att.get_stop_given_head_valence(iter->first,n)));
		}
	}
	reestimate(varType,true,true);
	delete model0;
}
void Grammar_uvg_6lin::initKlein(const vector<Sentence> & sents,F randomize,int varType,const vector<set<Upair> > * deps){
	Grammar_uvg * model0 =new Grammar_uvg(getMetaGrammar());
	model0->initKlein(sents,randomize,varType,deps);
	if(randomize==0){
		model0->reestimate(varType,true,true);
	}
  int numIterations=1;
  for (int iteration=0;iteration<numIterations;iteration++){
	  cout<<"dmv iteration "<<iteration<<endl;
	  for (U i = 0; i < sents.size(); ++i) {
		assert(sents[i].size()>0);
		Chart p(sents[i],model0);
		F tprob = p.inside();
		assert(tprob>=0&&tprob<=1);
		p.outside();
		p.incrementExpectedCounts(model0);//count0);
	  }
	  if(iteration<numIterations-1)
		  model0->reestimate(varType,true,true);
	  score_deps(sents,deps, model0, &cout,true,false);
  }
  cout<<"statistics for klein DMV"<<endl;
  ofstream out("asdf");
  model0->printStatistics(out);
  cout<<"statistics for uvg6lin"<<endl;
	cforeach(UFList,iter,getArgs()){
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_valence(n)->insertAll(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_valence(n)->insertAll(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
		}

	}
	cforeach(UFList,iter,getArgs()){
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_head_valence(iter->first,n)->insertAll(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_head_valence(iter->first,n)->insertAll(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
			if(varType==0){
				L_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("NOBACKOFF"),getMetaGrammar()->backoffAlpha.second,false);
				L_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("BACKOFF"),getMetaGrammar()->backoffAlpha.first,false);
				R_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("NOBACKOFF"),getMetaGrammar()->backoffAlpha.second,false);
				R_att.get_arg_mix_given_head_valence(iter->first,n)->insert(getTagVocab().lookup("BACKOFF"),getMetaGrammar()->backoffAlpha.first,false);
			}
		}

	}
	get_arg_given_root()->insertAll(*(model0->get_arg_given_root()));
	typedef pair<U,U> UPair;
	cforeach(UFList,iter,getArgs()){
		for(U n=0;n<NUMSTOP;n++){
			L_att.get_stop_given_head_valence(iter->first,n)->insertAll(*(model0->L_att.get_stop_given_head_valence(iter->first,n)));
			R_att.get_stop_given_head_valence(iter->first,n)->insertAll(*(model0->R_att.get_stop_given_head_valence(iter->first,n)));
		}
	}
	delete model0;
	if(randomize)
		this->reestimate(varType,true,true);
	ofstream out2("asdf2");
	this->printStatistics(out2);
	
}

Grammar_uvg_6lin::Grammar_uvg_6lin(MetaGrammar * mg):Grammar(mg),
	numMixBuckets(1),
	tagBucket(numMixBuckets,mg->tagCount),
	S_root_att(this,getArgs(),getWords(),getTagVocab(),getWordVocab()),
	L_att(this,getArgs(),getWords(),mg->stop_symbols,"L",getTagVocab(),getWordVocab(),mg->backoffAlpha),
	R_att(this,getArgs(),getWords(),mg->stop_symbols,"R",getTagVocab(),getWordVocab(),mg->backoffAlpha)
{
	setCollapsed(false,true,false);
	if(mg->tiedInit)
		initRandUVG(mg->trains,mg->varType);
	if(mg->useBuckets)
		foreach(UFList,arg,getArgs()){
			cout<<getTagVocab().lookup(arg->first)<<" in bucket "<<tagBucket[arg->first]<<"\t with count "<<mg->tagCount.get(arg->first)<<endl;

		}
	initToPrior(MD::VAR,false,true);
}
Grammar_uvg_6lin::Grammar_uvg_6lin(Grammar_uvg_6lin * model0, MetaGrammar * mg)://,W_MD & aw_given_arg_real):
	Grammar(mg),
	numMixBuckets(1),
	tagBucket(numMixBuckets,mg->tagCount),
	S_root_att(this,getArgs(),getWords(),getTagVocab(),getWordVocab()),
	L_att(this,getArgs(),getWords(),mg->stop_symbols,"L",getTagVocab(),getWordVocab(),mg->backoffAlpha),
	R_att(this,getArgs(),getWords(),mg->stop_symbols,"R",getTagVocab(),getWordVocab(),mg->backoffAlpha)
{
	//initialize others from model0
	get_arg_given_root()->initialize(model0->get_arg_given_root());
	add_nonmix_dist(get_arg_given_root());
	typedef pair<U,U> UPair;
	cforeach(UFList,iter,getArgs()){
		for(U n=0;n<NUMSTOP;n++){
			L_att.get_stop_given_head_valence(iter->first,n)->initialize(*(model0->L_att.get_stop_given_head_valence(iter->first,n)));
			R_att.get_stop_given_head_valence(iter->first,n)->initialize(*(model0->R_att.get_stop_given_head_valence(iter->first,n)));
		}
	}
	cforeach(UFList,iter,getArgs()){
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
			L_att.get_arg_given_head_valence(iter->first,n)->initialize(
				*(model0->L_att.get_arg_given_head_valence(iter->first,n)));
			R_att.get_arg_given_head_valence(iter->first,n)->initialize(
				*(model0->R_att.get_arg_given_head_valence(iter->first,n)));
			L_att.get_arg_mix_given_head_valence(iter->first,n)->initialize(
				*(model0->L_att.get_arg_mix_given_head_valence(iter->first,n)));
			R_att.get_arg_mix_given_head_valence(iter->first,n)->initialize(
				*(model0->R_att.get_arg_mix_given_head_valence(iter->first,n)));

		}

	}
	for(U n=1;n<=NUMARG;n++){//zero valence things don't have 
		L_att.get_arg_given_valence(n)->initialize(
			*(model0->L_att.get_arg_given_valence(n)));
		R_att.get_arg_given_valence(n)->initialize(
			*(model0->R_att.get_arg_given_valence(n)));
	}
	

}

F Grammar_uvg_6lin::increment_rule(U par,U pc, U l,U lc, const word_type & head,F weight,bool delete_table){
	assert(pc==TOP);
	assert(lc<TOP);
	// If lc==0, then 1 stop, no nonstops
	// if lc==1, then 1 stop, 1 nonstop
	// if lc==2, then 1 stop, 2 nonstop...
	// if lc==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=L_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}
			
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,n-1,head.word,nonstop,weight);
		}
		if(lc!=TOP-1){
			pr*=R_att.stop_given_head_valence_hw_inc(head.tag,lc,head.word,stop,weight);
		}

	}
	else assert(false);
        return pr;	
}

F Grammar_uvg_6lin::increment_rule(U par, U pc,U lchild,U lc, U rchild, U rc, const word_type & s,const word_type & m, const word_type & e,F weight,bool delete_table){
    F pr=1;
	if(weight==1)assert(!delete_table);
	
	// L^pc -> L ML^pc
	if(par==L){
	    assert(pc==rc);
	    assert(lc==TOP);
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(lchild==L&&rchild==ML);
	    pr*=L_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=L_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(pc==lc);
	    assert(rc==TOP);
	    assert(lchild==MR&&rchild==R);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    pr*=R_att.arg_given_head_valence_hw_inc(head.tag,pc,head.word,arg.tag,weight);
	    pr*=R_att.aw_given_arg_head_valence_hw_inc(arg.tag,head.tag,pc,head.word,arg.word,weight);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(rc==TOP-1||rc==TOP-2);
  	   
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }


	}
	// MR --> R L
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(lc==TOP-1||lc==TOP-2);
	   assert(lchild==R&&rchild==L);
	   assert(rc==TOP);
	   if(pc==TOP-1){
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,nonstop,weight);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_inc(head.tag,pc,head.word,stop,weight);
		}
	   }

	}
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_inc(m.tag,weight);
	  pr*=  S_root_att.aw_given_root_arg_inc(m.tag,m.word,weight);
	}
	//S -> L R

    return pr;	
}
F Grammar_uvg_6lin::prob_rule(U par,U pc,U l,U lc, const word_type & head){
	assert(pc==TOP);
	assert(lc<TOP);
	assert(par==l);
	// If pc2==0, then 1 stop, no nonstops
	// if pc2==1, then 1 stop, 1 nonstop
	// if pc2==2, then 1 stop, 2 nonstop...
	// if pc2==TOP-1, then TOP-1 nonstops.
	F pr=1;
	if(par==L){
		for(U n=1;n<=lc;n++){
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=L_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);
	}
	else if(par==R){
		for(U n=1;n<=lc;n++){
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,n-1,head.word,nonstop);
		}
		if(lc!=TOP-1)
			pr*=R_att.stop_given_head_valence_hw_prob(head.tag,lc,head.word,stop);

	}
	else assert(false);
	if(pr>1&&pr<1.00001) pr=1;
	if(pr>1) cout<<"pr="<<pr<<endl;
	assert(pr<=1);
	//cout<<"prob_rule="<<translate[par]<<pc<<" --> "<<translate[l]<<lc
	//		  <<'\t'<<getTagVocab().lookup(head.tag)
	//		  <<'\t'<<pr<<endl;
        return pr;	
}

F Grammar_uvg_6lin::prob_rule(U par,U pc, U lchild, U lc, U rchild,U rc, const word_type & s,const word_type & m,const word_type & e){
	// L -> L ML
	assert(pc>0);
	assert(pc<NUMVAL);
	assert(lc<NUMVAL);
	assert(rc<NUMVAL);
	F pr=1;
	if(par==L){
	    //e --> m
	    const word_type & head = e;
	    const word_type & arg = m;
	    assert(pc==rc);
	    assert(lc==TOP);
	    assert(lchild==L&&rchild==ML);
	    pr*=L_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=L_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	  
	}
	// R -> MR R
	else if(par==R){
	    assert(lchild==MR&&rchild==R);
	    assert(pc==lc);
	    assert(rc==TOP);
	    //s --> m
	    const word_type & head = s;
	    const word_type & arg = m;
	    pr*=R_att.arg_given_head_valence_hw_prob(head.tag,pc,head.word,arg.tag);
	    pr*=R_att.aw_given_arg_head_valence_hw_prob(arg.tag,head.tag,pc,head.word,arg.word);
	}
	// ML --> R L
	else if(par==ML){
	   const word_type & head = e;
	   if(pc!=TOP-1)
		assert(pc-1==rc);	
	   
	   else
		assert(pc-1==rc||pc==rc);
	   assert(lc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//ML^Np -->R L^Np | R L^N-1
		if(rc==TOP-1)
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(rc==TOP-2);
		   pr*=L_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
	   }
	}
	// MR --> UR L
	// MR --> MR M
	else if(par==MR){
	   const word_type & head = s;
	   if(pc!=TOP-1)
		assert(pc-1==lc);	
	   
	   else
		assert(pc-1==lc||pc==lc);
	   assert(rc==TOP);
	   assert(lchild==R&&rchild==L);
	   if(pc==TOP-1){//MR^Np -->R^Np L | R^N-1 L
		if(lc==TOP-1)
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,nonstop);
		else{
		   assert(lc==TOP-2);
		   pr*=R_att.stop_given_head_valence_hw_prob(head.tag,pc,head.word,stop);
		}
	    }
	}
	// M --> R L 
	else if(par==S){
	  assert(lchild==L && rchild==R);
	  pr=  S_root_att.arg_given_root_prob(m.tag);
	  pr*=  S_root_att.aw_given_root_arg_prob(m.tag,m.word);

	}
	else assert(false);
	//S -> L R
	//cout<<"prob_rule="<<translate[par]<<pc<<" --> "
	//		  <<translate[lchild]<<lc<<'\t'
	//		  <<translate[rchild]<<rc<<'\t'
	//		  <<'\t'<<getTagVocab().lookup(s.tag)
	//		  <<'\t'<<getTagVocab().lookup(m.tag)
	//		  <<'\t'<<getTagVocab().lookup(e.tag)
	//		  <<pr<<endl;
	if(pr>1&&pr<1.00001) pr=1;
	if(!(pr<=1)) cout<<"pr="<<pr<<endl;
	assert(pr<=1);
	return pr;

}
void Grammar_uvg_6lin::write(ostream & out){
	out<<"Grammar: "<<endl;
	out<<"left:"<<endl;
	L_att.write(out);
	out<<"right:"<<endl;
	R_att.write(out);
}
void Grammar_uvg_6lin::AttDist::write(ostream & out){}
MD * Grammar_uvg_6lin::AttDist::get_stop_given_head_valence(U  h,U v){ 
	if(v>=NUMSTOP) v=NUMSTOP-1;//cap valence
	return getMD(h,v,stop_given_head_valence);
}
F Grammar_uvg_6lin::AttDist::stop_given_head_valence_hw_prob(U h,U v, U hw,U arg){
	return get_stop_given_head_valence(h,v)->prob(arg);
}
F Grammar_uvg_6lin::AttDist::stop_given_head_valence_hw_inc(U h,U v, U hw,U arg,F weight){
	return get_stop_given_head_valence(h,v)->insert(arg,weight,false);
}

F Grammar_uvg_6lin::AttDist::arg_given_head_valence_hw_inc(U h,U v, U hw,U arg,F weight){
	assert(v>0);
	U size=2;
	MD * md[size];
	md[0] = get_arg_given_head_valence(h,v);
	md[1] = get_arg_given_valence(v);
	MD * mix_dist=get_arg_mix_given_head_valence(h,v);
	F mix[2]= {mix_dist->prob(nobackoffToValence.first),mix_dist->prob(backoffToValence.first)};
	F total=0;
	F probTrans[size];
	for(U i=0;i<size;i++){
		probTrans[i]=md[i]->prob(arg)*mix[i];
		total+=probTrans[i];
	}
	if(total==0) total=1;//in case there is zero mass

	for(U i=0;i<size;i++){
		md[i]->insert(arg,weight*probTrans[i]/total,false);
	}
	mix_dist->insert(nobackoffToValence.first,weight*(probTrans[0]/total),false);
	mix_dist->insert(backoffToValence.first,weight*(probTrans[1]/total),false);
	return total;
}

F Grammar_uvg_6lin::AttDist::arg_given_head_valence_prob(U h,U v, U argt){
	assert(v>0);
	MD * md1 = get_arg_given_head_valence(h,v);
	MD * md2 = get_arg_given_valence(v);
	MD * mix=get_arg_mix_given_head_valence(h,v);
	
	F pr=mix->prob(nobackoffToValence.first)*md1->prob(argt)+mix->prob(backoffToValence.first)*md2->prob(argt);
	
	assert(pr>=0&&pr<=1.0000001);
	//cout<<"\n\targ_given_head_valence_prob("<<tagVocab.lookup(argt)<<" | "<<tagVocab.lookup(h)<<" "<<v<<" )="<<pr;
	//cout<<"("<<mix->prob(nobackoffToValence.first)<<'\t'<<mix->prob(backoffToValence.first)<<")"<<endl;
	return pr;
}
F Grammar_uvg_6lin::AttDist::arg_given_head_valence_hw_prob(U ht,U v,U hw, U argt){
	assert(v>0);
	F pr=arg_given_head_valence_prob(ht,v,argt);
	return pr;
}
F Grammar_uvg_6lin::AttDist::aw_given_arg_head_valence_hw_prob(U argt,U ht,U v,U hw, U aw){
	return 1;
}
F Grammar_uvg_6lin::AttDist::aw_given_arg_head_valence_hw_inc(U arg,U head, U v,U hw, U aw, F weight){
	return 1;
}
MD * Grammar_uvg_6lin::AttDist::get_arg_mix_given_head_valence(U  h,U v){ 
	assert(v>0);
	if(v>NUMARG) v=NUMARG;//cap valence
	if(g->getMetaGrammar()->useBuckets)
		return getMD(g->tagBucket[h],v,arg_mix_given_head_valence);
	return getMD(h,v,arg_mix_given_head_valence);
}
MD * Grammar_uvg_6lin::AttDist::get_arg_given_head_valence(U  h,U v){ 
	assert(v>0);
	//if(v>NUMARG) cout<<"capped valence "<<v<<" to "<<NUMARG<<endl;
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(h,v,arg_given_head_valence);
}
MD * Grammar_uvg_6lin::AttDist::get_arg_given_valence(U v){ 
	assert(v>0);
	if(v>NUMARG) v=NUMARG;//cap valence
	return getMD(v,arg_given_valence);
}
Grammar_uvg_6lin::AttDist::AttDist(Grammar_uvg_6lin * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, list<pair<U,F> > & stop,const string & direction,Vocab & tv,Vocab & wv,pair<F,F> & backoffAlpha):
	tagVocab(tv),
	wordVocab(wv),
	dir(direction),
	args(arg),
	words(word),
	stops(stop),


	stop_given_head_valence(NUMSTOP,V_MD(tv.size(),NULL)),
	arg_given_head_valence(NUMARG+1,V_MD(tv.size(),NULL)),
	arg_given_valence(NUMARG+1,NULL),
	arg_mix_given_head_valence(NUMARG+1,V_MD(gram->getMetaGrammar()->useBuckets?gram->numMixBuckets:tv.size(),NULL)),
	backoffToValence(tagVocab.lookup("BACKOFF"),backoffAlpha.first),
	nobackoffToValence(tagVocab.lookup("NOBACKOFF"),backoffAlpha.second),
	g(gram)
{
	backoffs.push_back(nobackoffToValence);
	backoffs.push_back(backoffToValence);
	foreach(UFList,arg,getArgs()){
		string id=dir+"_stop_given_";
		string id3=dir+"_arg_given_";
		string id2=dir+"_arg_given_";
		string argstr=tagVocab.lookup(arg->first);
		id+=argstr;
		id3+=argstr;
		for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
			char nc='0'+n;
			string ida=id3+nc;
			arg_given_head_valence[n][arg->first]=new MD(args.size(),args,ida,false);
			g->add_nonmix_dist(get_arg_given_head_valence(arg->first,n));
			ida="mix_";
			ida+=id3+nc;
			if(g->getMetaGrammar()->useBuckets){
				if(!arg_mix_given_head_valence[n][g->tagBucket[arg->first]]){
					arg_mix_given_head_valence[n][g->tagBucket[arg->first]]= new MD(backoffs.size(), backoffs,ida);
					g->add_mix_dist(get_arg_mix_given_head_valence(arg->first,n));
				}
			}else{
				arg_mix_given_head_valence[n][arg->first]= new MD(backoffs.size(), backoffs,ida);
				g->add_mix_dist(get_arg_mix_given_head_valence(arg->first,n));

			}
		}

		for(U n=0;n<NUMSTOP;n++){
			char nc='0'+n;
			string ida=id+nc;
			stop_given_head_valence[n][arg->first]=new MD(2,stops,ida,false);
			g->add_nonmix_dist(get_stop_given_head_valence(arg->first,n));
		}
	}
	for(U n=1;n<=NUMARG;n++){//zero valence things don't have args
		char nc='0'+n;
		string id2=dir+"_arg_given_";
		string ida=id2+nc;
		arg_given_valence[n]=new MD(args.size(),args,ida,false);
		g->add_nonmix_dist(get_arg_given_valence(n));
	}
		
}

Grammar_uvg_6lin::RootAttDist::RootAttDist(Grammar_uvg_6lin * gram,list<pair<U,F> > & arg,list<pair<U,F> > & word, Vocab & tv,Vocab & wv):
	tagVocab(tv),
	wordVocab(wv),
	args(arg),
	words(word),
	arg_given_root(new MD(args.size(),args,"S_arg_given_root")),
	g(gram)
{
	g->add_nonmix_dist(get_arg_given_root());
}
F Grammar_uvg_6lin::RootAttDist::arg_given_root_prob(U arg){
	return arg_given_root->prob(arg);
}
F Grammar_uvg_6lin::RootAttDist::aw_given_root_arg_prob(U arg,U aw){
        return 1;
}

F Grammar_uvg_6lin::RootAttDist::arg_given_root_inc(U arg,F weight){
	return arg_given_root->insert(arg,weight,false);
}
F Grammar_uvg_6lin::RootAttDist::aw_given_root_arg_inc(U arg,U aw,F weight){
	return 1;
}

//F Grammar_uvg_6lin::RootAttDist::KLQ_P(){
//	return arg_given_root.KLQ_P();
//}
//void Grammar_uvg_6lin::RootAttDist::setCollapsed(bool c){
//	arg_given_root.setCollapsed(c);
//}
