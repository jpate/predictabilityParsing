/*
 * Copyright William Headden 2009
 *
*/

#include"grammar.h"
#include"mt19937ar.h"
#include<math.h>
U Grammar::stop=0;
U Grammar::nonstop=0;
void Grammar::delete_dists(){
	//cout<<"delete_dists()"<<get_nonmix_dist().size()<<endl;
	U i=0;
	foreach(list<Dist2 *>,dist,get_nonmix_dist()){
		//cout<<"deleting "<<(*dist)->getID()<<endl;
		delete *dist;
		*dist=NULL;
		//cout<<"deleted"<<endl;
		i++;
	}
	//cout<<"mix: delete_dists()"<<get_mix_dist().size()<<endl;
	foreach(list<Dist2 *>,dist,get_mix_dist()){
		delete *dist;
		*dist=NULL;
	}
	get_nonmix_dist().clear();
	get_mix_dist().clear();
	//cout<<"deleted"<<endl;

}
void Grammar::writeToFile(ostream & out){
	string none="--NONE--";
	foreach(list<Dist2 *>,dist,get_nonmix_dist()){
		out<<none<<'\t'<<(*dist)->getID()<<endl;
		(*dist)->write(out);
	}
	foreach(list<Dist2 *>,dist,get_mix_dist()){
		out<<none<<'\t'<<(*dist)->getID()<<endl;
		(*dist)->write(out);
	}
}
void Grammar::readFromFile(istream & in){
	string none="--NONE--";
	foreach(list<Dist2 *>,dist,get_nonmix_dist()){
		string s,id;
		in>>s;
		in>>id;
		cerr<<"s="<<s<<'\t';
		cerr<<"id="<<id<<'\t'<<(*dist)->getID()<<endl;
		assert(s==none&&id==(*dist)->getID());
		(*dist)->read(in);
	}
	foreach(list<Dist2 *>,dist,get_mix_dist()){
		string s,id;
		in>>s>>id;
		assert(s==none&&id==(*dist)->getID());
		(*dist)->read(in);
	}
}
void Grammar::clearCounts(bool reestimate_nonmix, bool reestimate_mix){
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			(*dist)->clearCounts();
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			(*dist)->clearCounts();
		}
}
void Grammar::reestimate(int type,bool reestimate_nonmix, bool reestimate_mix){
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			(*dist)->reestimate(type);
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			(*dist)->reestimate(type);
		}

}
void Grammar::printStatistics(ostream & out){
	out<<endl;
	F threshold=.9;
	foreach(list<Dist2 *>,dist,get_nonmix_dist()){
		(*dist)->printStatistics(getTagVocab(),out,threshold);
	}
	foreach(list<Dist2 *>,dist,get_mix_dist()){
		(*dist)->printStatistics(getTagVocab(),out,threshold);
	}
}
F Grammar::logKLPosteriorPrior(bool reestimate_nonmix, bool reestimate_mix){
	F log_p=0;
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			log_p+=(*dist)->KLQ_P();
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			log_p+=(*dist)->KLQ_P();
		}
	return log_p;
}
void Grammar::sample_posterior(bool reestimate_nonmix, bool reestimate_mix,F size_factor){
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			(*dist)->sample_posterior(size_factor);
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			(*dist)->sample_posterior(size_factor);
		}
}
void Grammar::setCollapsed(bool c,bool reestimate_nonmix, bool reestimate_mix,F prob){
	int count=0;
	int total=0;
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			if(prob==1||prob>mt_genrand_real1()){
				count++;
				(*dist)->setCollapsed(c);
			}
			total++;
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			if(prob==1||prob>mt_genrand_real1()){
				count++;
				(*dist)->setCollapsed(c);
			}
			total++;
		}
	collapsed=c;
	cout<<"resampled "<<count<<" of "<<total<<" distributions"<<endl;
}
void Grammar::initToPrior(int type,bool reestimate_nonmix, bool reestimate_mix){
	if(reestimate_nonmix)
		foreach(list<Dist2 *>,dist,get_nonmix_dist()){
			(*dist)->initToPrior(type);
		}
	if(reestimate_mix)
		foreach(list<Dist2 *>,dist,get_mix_dist()){
			(*dist)->initToPrior(type);
		}

}
MD * getMD(U h, V_MD & md){
	assert(h<md.size());
	assert(md[h]);
	return md[h];
}
MD * getMD(U h, U v, VV_MD & md){
	assert(v<md.size());
	assert(h<md[v].size());
	assert(md[v][h]);
	return md[v][h];
}
MD * getMD(U h, W_MD & md){
	W_MD::iterator i=md.find(h);
	if(i==md.end()){
		cout<<"didn't find "<<h<<endl;
		assert(false);
	}
	else 
		return (i->second);
	assert(false);
	return NULL;
}
MD * getMD(U h, U v, WW_MD & md){
	//assert(v<md.size());
	WW_MD::iterator i=md.find(v);
	if(i==md.end()){
		cout<<"didn't find "<<v<<endl;
		assert(false);
	}
	else {
		return getMD(h,i->second);
	}
	assert(false);
	return NULL;
}
MD * getMD(U h, U a,U v, VWW_MD & md){
	assert(v<md.size());
	WW_MD::iterator i=md[v].find(a);
	if(i==md[v].end()){
		cout<<"didn't find "<<a<<endl;
		assert(false);
	}
	else {
		return getMD(h,i->second);
	}
	assert(false);
	return NULL;
}
MD * getMD(U h, U v, VW_MD & md){
	assert(v<md.size());
	W_MD::iterator i=md[v].find(h);
	if(i==md[v].end()){
		cout<<"didn't find "<<h<<endl;
		assert(false);
	}
	else 
		return (i->second);
	assert(false);
	return NULL;
}
MetaGrammar::MetaGrammar(Vocab & tv,Vocab & wv,list<pair<U,F> > & arg_sym,list<pair<U,F> > & word_sym,list<pair<U,F> > & back_sym, list<pair<U,F> > & stop_sym,U_LUF & wbp,pair<F,F> & backAlph,pair<F,F> & backAlph2,const Count<U> & wordCount,const Count<U> & tagCount,const Count<pair<U,U>,int> & tagWordCount,bool tiedInit,const vector<Sentence> & sents,int varType,bool useBuckets,F gb_prior_hyp,F gb_prior_hyp2):
	tagVocab(tv),
	wordVocab(wv),
	arg_symbols(arg_sym),
	word_symbols(word_sym),
	backoff_symbols(back_sym),
	stop_symbols(stop_sym),
	wordsByPOS(wbp),
	backoffAlpha(backAlph),
	backoffAlpha2(backAlph2),
	wordCount(wordCount),
	tagCount(tagCount),
	tagWordCount(tagWordCount),
	tiedInit(tiedInit),
	trains(sents),
	varType(varType),
	useBuckets(useBuckets),
	gb_prior_hyp(gb_prior_hyp),
	gb_prior_hyp2(gb_prior_hyp2)
{
	//assert(stop!=0);
	//assert(nonstop!=0);
	string trans[NUMNTS]={"L","R","ML","MR","S","UL","UR"};
	for(U i=0;i<NUMNTS;i++)
		this->translate[i]=trans[i];
}
Grammar::Grammar(MetaGrammar * mg):
	wordsByPOS(mg->wordsByPOS),
	tagVocab(mg->tagVocab),
	wordVocab(mg->wordVocab),
	args(mg->arg_symbols),
	words(mg->word_symbols),
	backs(mg->backoff_symbols),
	//collapsed(false),
	logProbCorpus(0)
{
	string trans[NUMNTS]={"L","R","ML","MR","S","UL","UR"};
	for(U i=0;i<NUMNTS;i++)
		this->translate[i]=trans[i];
	setMetaGrammar(mg);
}
void Grammar::generateSymbols(Vocab & vocab,list<pair<U,F> > & arg_symbols,F arg_alpha,list<pair<U,F> > & stop_symbols,F stop_alpha,F nonstop_alpha,Count<U> & tagCount,bool ignoreTagCount){
	Grammar::stop=vocab.lookup("STOP");
	Grammar::nonstop=vocab.lookup("NONSTOP");
	arg_symbols.clear();
	stop_symbols.push_back(pair<U,F>(Grammar::stop,stop_alpha));
	stop_symbols.push_back(pair<U,F>(Grammar::nonstop,nonstop_alpha));
	for(U i=1;i<vocab.size();i++)
		if(i!=Grammar::stop&&i!=Grammar::nonstop &&(ignoreTagCount|| tagCount.get(i)>0)){
			cout<<"generateSymbols: adding "<<vocab.lookup(i)<<endl;
			arg_symbols.push_back(pair<U,F>(i,arg_alpha));
		}
	
}
F Grammar::tree_prob(Tree * tp,const Sentence & sent){
    F pr = 1;
    if (!tp->left) 
      return pr;
    if(!tp->right){
	if(tp->ntc==0){//preterminal
		pr= tree_prob(tp->left,sent)*
			prob_rule(tp->nt,tp->ntc,tp->left->head);
	}
	else{
		pr= tree_prob(tp->left,sent)*
			prob_rule(tp->nt,tp->ntc,tp->left->nt,tp->left->ntc,tp->left->head);

	}
    }
    else{
	pr= tree_prob(tp->left,sent)*tree_prob(tp->right,sent)*
		prob_rule(tp->nt,tp->ntc,tp->left->nt,tp->left->ntc,tp->right->nt,tp->right->ntc,sent[tp->s],sent[tp->left->e],sent[tp->e]);
    }
    return pr;	
}
F Grammar::increment(Tree * tp,const Sentence & sent,int weight,bool delete_table){
	if (!tp->left) {
		assert(tp->nt!=S);
		return 1;
	}
	F p=1;
	if(!tp->right){//unary tree
		if(tp->ntc==0){//preterminal
			assert(tp->s==tp->e);
			p=increment_rule(tp->nt,tp->ntc,sent[tp->s],weight,delete_table);
			p*=increment(tp->left,sent,weight,delete_table);
		}
		else{//determine valency class
			assert(tp->nt==tp->left->nt);
			assert(tp->head==sent[tp->s]||tp->head==sent[tp->e]);
			p=increment_rule(tp->nt,tp->ntc,tp->left->nt,tp->left->ntc,tp->head,weight,delete_table);
			p*=increment(tp->left,sent,weight,delete_table);
		}
	}
	else{//binary tree;
		p= increment_rule(tp->nt,tp->ntc,tp->left->nt,tp->left->ntc,tp->right->nt,tp->right->ntc,sent[tp->s],sent[tp->left->e],sent[tp->e],weight,delete_table);
		p*=increment(tp->left,sent,weight,delete_table)*increment(tp->right,sent,weight,delete_table);
	}
	if(tp->nt==S){
		if(weight==1){
			assert(p>0);
			logProbCorpus+=log(p)/log(2.0);
		}
		else{
			assert(p>0);
			assert(weight==-1);
			logProbCorpus-=log(p)/log(2.0);
		}
	}
	return p;
	


}

