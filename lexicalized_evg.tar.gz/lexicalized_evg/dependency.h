/*
 * Copyright William Headden 2009
 *
*/

#ifndef DEPENDENCY_H
#define DEPENDENCY_H
#include<vector>
#include<set>
#include<list>
#include<assert.h>
#include <algorithm>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <unistd.h>
#include <utility>
#include <vector>
#include "Vocab.h"
#include "Count.h"
#include "Sentence.h"
#include "types.h"
typedef std::vector<U> Ws;
typedef std::vector<Ws> Wss;
typedef std::vector<Sentence> Sentences;
using namespace std;

struct DepScore{
	DepScore():matched(0),total(0),lHist(5,0),rHist(5,0){}
	size_t matched;
	size_t total;
	vector<int> lHist;
	vector<int> rHist;
	
	void printLeft(ostream & out){
		double tl=total;
		out<<"\n\tL "<<tl<<'\t'<<lHist[0]/(double)total<<'\t';
		for(size_t i=1;i<lHist.size();i++)
			out<<(tl>0?lHist[i]/tl:0)<<'\t';
	}
	void printRight(ostream & out){
		double tl=total;
		out<<"\n\tR "<<tl<<'\t'<<rHist[0]/(double)total<<'\t';
		for(size_t i=1;i<rHist.size();i++)
			out<<(tl>0?rHist[i]/tl:0)<<'\t';
	}
	DepScore & operator+=(DepScore & rhs){
		this->matched+=rhs.matched;
		this->total+=rhs.total;
		assert(rHist.size()==lHist.size());
		assert(rhs.lHist.size()==lHist.size());
		assert(rhs.rHist.size()==rHist.size());
		for(size_t i=0;i<this->lHist.size();i++){
			this->lHist[i]+=rhs.lHist[i];
			this->rHist[i]+=rhs.rHist[i];
		}
		return *this;
	}
	void count(const set<Upair> & s){
		Count<int> largCount;
		Count<int> rargCount;
		for(U i=0;i<lHist.size();i++){
			lHist[i]=0;
			rHist[i]=0;
		}
		foreach(set<Upair>,i,s){
			//cout<<"i->first="<<i->first<<'\t'<<(int)(i->first)<<endl;
			if(i->first>200) continue;//==(U)-1) continue;
			if(i->first<i->second)
				rargCount.inc(i->first,1);
			else
				largCount.inc(i->first,1);
			if(i->first==i->second-1)
				rHist[0]++;
			if(i->first==i->second+1)
				lHist[0]++;
		}
		if(!((U)(rargCount.total()+largCount.total())==s.size()-1)){
			cout<<rargCount.total()<<" "<<largCount.total()<<" "<<s.size()<<endl;
			foreach(Count<int>,i,largCount)
				cout<<i->first<<','<<i->second<<" ";
			cout<<endl;
			foreach(Count<int>,i,rargCount)
				cout<<i->first<<','<<i->second<<" ";
			cout<<endl;
			cout<<s<<endl;
		}
		assert((U)(rargCount.total()+largCount.total())==s.size()-1);
		foreach(Count<int>,i,largCount){
			int j=i->second;
			if(j>4)j=4;
			assert(j>=0&&((U)j)<lHist.size());
			lHist[j]++;
		}
		foreach(Count<int>,i,rargCount){
			int j=i->second;
			if(j>4)j=4;
			assert(j>=0&&((U)j)<rHist.size());
			rHist[j]++;
		}
	}
};

struct CoNLLDependency{
	U id;
	string form;
	string lemma;
	string cpostag;
	string postag;
	string feats;
	U head;
	string deprel;
	U phead;
	string pdeprel;
	bool last;
	void print(ostream & out){
		CoNLLDependency & d=*this;
		out<<d.id+1<<" \t"<<d.form<<" \t"<<d.lemma<<" \t"<<d.cpostag<<" \t"<<d.postag<<" \t"<<d.feats<<" \t"<<d.head+1<<" \t"<<d.deprel<<" \t"<<d.phead+1<<" \t"<<d.pdeprel<<endl;
		//out<<d.id<<" \t"<<d.form<<" \t"<<d.lemma<<" \t"<<d.cpostag<<" \t"<<d.postag<<" \t"<<d.feats<<" \t"<<d.head<<" \t"<<d.deprel<<" \t"<<d.phead<<" \t"<<d.pdeprel;
	}
	friend ostream & operator<<(ostream & out, const CoNLLDependency & d){
		out<<d.id+1<<" \t"<<d.form<<" \t"<<d.lemma<<" \t"<<d.cpostag<<" \t"<<d.postag<<" \t"<<d.feats<<" \t"<<d.head+1<<" \t"<<d.deprel<<" \t"<<d.phead+1<<" \t"<<d.pdeprel;
		//out<<d.id<<" \t"<<d.form<<" \t"<<d.lemma<<" \t"<<d.cpostag<<" \t"<<d.postag<<" \t"<<d.feats<<" \t"<<d.head<<" \t"<<d.deprel<<" \t"<<d.phead<<" \t"<<d.pdeprel;
		return out;
	}
	friend istream & operator>>(istream & in, CoNLLDependency & d){
		if(!in) return in;
		string idstr;
		in>>idstr;
		if(!in||idstr.size()==0) return in;
		if(!isdigit(idstr[0])){
			d.last=true; 
			cout<<"read idstr: "<<idstr<<endl;
			return in;
		}
		stringstream sstream(idstr);	
		sstream>>d.id;
		if(!in) return in;
		//in>>d.form;
		ws(in);
		char c=in.peek();
		d.form.clear();
		while((c=in.get())!='\t'){
			d.form+=c;
		}
		ws(in);
		in>>d.lemma>>d.cpostag>>d.postag>>d.feats>>d.head>>d.deprel;
		ws(in);
		if(in.peek()=='_'){
			d.phead=d.head;
			string s;
			in>>s;	
		}
		else
			in>>d.phead;
		in>>d.pdeprel;
		d.id--;
		d.head--;
		d.phead--;
		return in;
	}
	static void read_deps(istream & in, vector<list<CoNLLDependency> > & gold_deps){
		CoNLLDependency d;
		list<CoNLLDependency> deps;
		size_t id=0;
		while(in){
			d.last=false;
			in>>d;
			if(d.id<=id)
			{
				if(deps.size()>0)
					gold_deps.push_back(deps);
				deps.clear();
			}
			if(!in||d.last) break;
			deps.push_back(d);
			id=d.id;
		}
		if(deps.size()>0)
		    gold_deps.push_back(deps);
		deps.clear();
	}

	static pair<DepScore,DepScore>  score_deps(const set<Upair> & gold, const set<Upair> & test){
		assert(gold.size()==test.size());
		pair<DepScore,DepScore> score;
		set<Upair>::iterator g=gold.begin();	
		set<Upair>::iterator t;
		assert(gold.size()==test.size());
		for(;g!=gold.end();g++,t++){
			t=test.find(*g);
			score.first.total++;
			score.second.total++;
			if(t!=test.end()){
				score.first.matched++;
				score.second.matched++;
			} else {
				t=test.find(Upair(g->second,g->first));
				if(t!=test.end())
					score.second.matched++;
			}
		}
		score.first.count(gold);	
		score.second.count(test);	
		return score;
	}
};

struct PuncID2{
	PuncID2(){
		punc.insert("!");
		punc.insert("!!");
		punc.insert("!!!");
		punc.insert("?");
		punc.insert("??");
		punc.insert("#");
		punc.insert(".");
		punc.insert("..");
		punc.insert("...");
		punc.insert(",");
		punc.insert("-");
		punc.insert("--");
		punc.insert(":");
		punc.insert(";");
		punc.insert("-RRB-");
		punc.insert("-RCB-");
		punc.insert("-LRB-");
		punc.insert("-LCB-");
		punc.insert("-LSB-");
		punc.insert("-LSB-");
		punc.insert("```");
		punc.insert("``");
		punc.insert("`");
		punc.insert("\'\'");
		punc.insert("\'\'\'");
		punc.insert("\'");

	}
	bool isPunc(const string &s)const{
		if(s=="-RRB-") return true;
		if(s=="-RCB-") return true;
		if(s=="-LRB-") return true;
		if(s=="-LCB-") return true;
		if(s=="-LSB-") return true;
		if(s=="-LSB-") return true;
		if(s=="$") return false;
		if(s=="%") return false;
		if(s=="&") return false;
		if(s=="=") return false;
		if(s=="\\*") return false;
		if(s=="\\*\\*") return false;
		for(U i=0;i<s.size();i++){
			if(isalnum(s[i])) return false;
		}
		return true;
	}
	private:
			set<string> punc;
};
struct PuncID{
	//static U ENGLISH=0;
	//static U CHINESE=1;
	//static U SWEDISH=2;
	PuncID(U language=0){
		switch(language){
			case 0:
				cout<<"language=English"<<endl;
				punc.insert("#");
				//punc.insert("$");
				punc.insert(".");
				punc.insert(",");
				punc.insert(":");
				punc.insert("-RRB-");
				punc.insert("-LRB-");
				punc.insert("``");
				punc.insert("\'\'");
				//assert(punc.size()==8);
				break;
			case 1:
				cout<<"language=Chinese"<<endl;
				break;
			case 2:
				cout<<"language=Swedish"<<endl;
				punc.insert("IK");
				punc.insert("IP");
				punc.insert("I?");
				punc.insert("IU");
				punc.insert("IQ");
				punc.insert("IS");
				punc.insert("IT");
				punc.insert("IR");
				punc.insert("IC");
				punc.insert("PU");
				punc.insert("IG");
				break;
			case 3:
				cout<<"language=German"<<endl;
				punc.insert("$.");
				punc.insert("$(");
				punc.insert("$,");
				break;
			default:
				cerr<<"unknown language "<<language<<endl;
				assert(false);
		}

	}
	bool isPunc(const string &s)const{
		return punc.find(s)!=punc.end();
	}
	private:
			set<string> punc;
};
void processWords(Sentences & trains,Sentences & trains2,Sentences & devs,Sentences & tests,Sentences & tests10,Vocab & wordVocab,list<pair<U,F> > & words,int unkCutoff,string unkstr,int unkNum,Vocab & tagVocab,U ownTagCutoff);
void read_deps(istream & in,Sentences & trains, vector<set<Upair> > * gold_deps,Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len,bool use_gold_tags,bool excise_on_words,U language);
void read_flat(istream & in,istream & in2,Sentences & trains, vector<set<Upair> > & gold_deps,Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len);
void read_flat2(istream & in,Sentences & trains, Vocab & tagVocab,Vocab & wordVocab,bool lowercaseAll,bool excise_punc,U max_sent_len);
#include"grammar.h"
void score_deps(const Sentences & tests,const vector<set<Upair> > * gold_deps, Grammar * model0,ostream * out,bool point_estimate=true,bool newline=true,ostream * outA=NULL);
pair<string,string> split_symbol(string s,char delim='_');
list<string> & split_symbol(string s,list<string> & l,char delim='_');
#endif
