/*
 * Copyright William Headden 2009
 *
*/

#ifndef GRAMMAR_UVG_6LIN_H
#define GRAMMAR_UVG_6LIN_H

using namespace std;
#include<iostream>
#include<string>
#include<vector>
class Grammar;
#include "Vocab.h"
#include "Bucket.h"
//#include "dependency.h"
#include "MultDir.h"
//#define L  0
//#define R  1 
//#define ML 2 
//#define MR 3 
//#define S  4
//#define UL 5
//#define UR 6
//#define NUMNTS 7
//#define NUMNT_SMALL 6

/*
 * Model:
 * More simply:
 *
 * S -> L R
 * L -> L^n, n\in 0,1,2,...,n-1;Np
 * L^n -> L ML^n         //predict  v |  in n place
 * ML^Np -> R L^Np | R L^N-1 	//predict whether to stop
 * ML^n -> R L^n-1  
 * L^0 -> ul

 * R -> R^Np | R^n, n \in 0,1,2,...,n-1
 * R^n -> MR^n R,  n \in 1,2,...N-1,Np
 * MR^Np -> R^Np L | R^N-1 L
 * MR^n -> R^n-1 L
 * R^0 -> ur
 */

//backoff:


#include"Sentence.h"


#include"grammar.h"
#include "Tree.h"
class Grammar_uvg_6lin:public Grammar{
	public:
		static string type_id;
		typedef list<pair<U,F> > UFList;
		Grammar_uvg_6lin(MetaGrammar * mg);
		Grammar_uvg_6lin(Grammar_uvg_6lin * model0, MetaGrammar * metagrammar);
		~Grammar_uvg_6lin(){
			delete_dists();
		}
		F prob_rule(U par, U pc,U l,U lc,const word_type & word);//prob L_TOP -> L_n
		F prob_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e);

		F increment_rule(U par,U pc, U l,U lc, const word_type & word,F count,bool delete_table);
		F increment_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e, F count,bool delete_table);
		void write(ostream & out);
		F probSeating() const;
		static void generateSymbols(Vocab & tagVocab,list<pair<U,F> > & arg_symbols,list<pair<U,F> > & stop_symbols);
		MD * get_aw_given_arg(U arg);
		static U NUMSTOP;
		static U NUMARG;
		void initKlein(const vector<Sentence> & sents,F randomize,int varType,const vector<set<Upair> > * train_deps);
		void initRandUVG(const vector<Sentence> & sents,int varType);
	private:
		F logProbCorpus;
		U numTerminals;
		U numMixBuckets;
		Bucket tagBucket;
		class AttDist{

		   public:
			AttDist(Grammar_uvg_6lin * gram,UFList & args, UFList & words,UFList & stops, const string & direction,Vocab & tv, Vocab & wv,pair<F,F> & backoffAlpha);
			//get specific distributions
			F stop_given_head_valence_hw_prob(U head, U v,U hw, U arg);
			F stop_given_head_valence_hw_inc( U head, U v,U hw, U arg,F weight);
			F arg_given_head_valence_hw_prob(U head, U v,U hw, U arg);
			F arg_given_head_valence_hw_inc( U head, U v,U hw, U arg,F weight);
			F aw_given_arg_head_valence_hw_prob(U arg,U head, U v,U hw, U aw);
			F aw_given_arg_head_valence_hw_inc(U arg,U head, U v,U hw, U aw, F weight);

			void cleanup();//remove any empty restaurants	


			void write(ostream & out);
			F probSeating() const;
			void setCollapsed(bool c);
			F log2prob_corpus();
			//F log2prob_corpus(DMVCount & count);
			//MD * get_arg_given_head_valence_hw(U ht,U v,U hw);
			MD * get_arg_given_head_valence(U ht,U v);
			MD * get_arg_given_valence(U v);
			MD * get_arg_mix_given_head_valence(U h,U v);
			MD * get_aw_given_arg(U arg);

			MD * get_stop_given_head_valence(U h,U v);
			//void printStatistics(ostream & out,F threshold);
			Vocab & getTagVocab(){return tagVocab;}
			Vocab & getWordVocab(){return wordVocab;}
		   private:
			UFList & getArgs(){return args;}
			UFList & getWords(){return words;}
			Vocab & tagVocab;
			Vocab & wordVocab;
			string dir;
			UFList & args;
			UFList backoffs;
			UFList & words;
			UFList & stops;

			F arg_given_head_valence_prob(U head, U v, U arg);


			VV_MD   stop_given_head_valence;

			VV_MD  arg_given_head_valence;
			V_MD   arg_given_valence;
			VV_MD   arg_mix_given_head_valence;		//mix: 

			pair<U,F> backoffToHeadValence;
			pair<U,F> nobackoffToHeadValence;
			pair<U,F> backoffToValence;
			pair<U,F> nobackoffToValence;
			public:
				Grammar_uvg_6lin * g;


		};//Grammar::AttachmentDistribution
		class RootAttDist{

		   public:
			RootAttDist(Grammar_uvg_6lin * gram,UFList & args,UFList & words, Vocab & tv, Vocab & wv);
			//get specific distributions
			F arg_given_root_prob(U arg);
			F aw_given_root_arg_prob(U arg,U aw);

			F arg_given_root_inc(U arg,F weight);
			F aw_given_root_arg_inc(U arg,U aw,F weight);
			MD * get_arg_given_root(){return arg_given_root;}
		   private:
			Vocab & getTagVocab(){return tagVocab;}
			Vocab & getWordVocab(){return wordVocab;}
			Vocab & tagVocab;
			Vocab & wordVocab;
			string dir;
			UFList & args;
			UFList & words;
			MD  * arg_given_root;
			MD * get_aw_given_arg(U arg);
		public:
			Grammar_uvg_6lin * g;
		private:
			//static MD * getMD(const U & h, W_MD & md);



		};//Grammar::AttachmentDistribution
	public:
		RootAttDist      S_root_att;
		AttDist L_att;
		AttDist R_att;

		MD * get_arg_given_root(){return S_root_att.get_arg_given_root();}
		
	friend ostream & operator<<(ostream & out, Grammar &G);
};


#endif

