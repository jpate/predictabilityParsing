Lexicalized Extended Valence Grammar
This provides code for 3 sorts of models: EVG(here referred to as UVG)-without backoff, EVG with backoff,  and Lexicalized EVG
In each, specify the number of argument distributions in each direction, and the number of stop distributions:
e.g.: for DMV, a=1,s=2; for EVG a=2,s=2;  To experiment with values higher than 2, set the TOP flag in the Makefile to the max desired value+1, and recompile.

Compiling: 
	make  

	Important options:  OS -- an unfortunate misnomer; 
				LINUX means you are using tr1/unordered_map
				OSX means using ext/hash_map
			    TOP-- one higher than maximal valence.  

Running:  Unfortunately the code is not set up to save the models in training, and then separately use them to parse data.

There are 3 executables:
	estimate_uvg:
		basic dirichlet priors, no mixture distributions	
	estimate_uvg6lin:
		argument distributions are smoothed with a 
		"skip-head" backoff distribution
	estimate_uvg6_luvg1linb:	
		argument distributions are conditioned on head word, 
		smoothed with uvg6lin argument distribution. 
		
[executable] [options]
the options parser we use here requires an argument for all options whether they need one or not.

 -l language       -- language number (used for removing punctuation). Punc set in dependency.h This version only does English (0) 
 -P 1              -- set estimation of mixing parameters to false
 -q 1              -- set estimation of mixing parameters from dev to true
 -A analyses_path  -- file stem to place output parses
 -J ownTagCutoff   -- set top K most frequent words to their own POS tag
 -S 1              -- initialize from gold dependencies
 -V estimationType -- 0=EM, 1=VB, 2=MAP
 -D 1              --use conLL-X input
 -U unkNum         -- set unkCutoff to keep unkNum words
 -u unkCutoff      -- set words seen this number or fewer to UNK
 -W filename       -- write final model to filename
 -R filename       -- read model frrom filename
 -k 1              -- set initialization to harmonic initializer of Klein & Manning
 -B beam_iters     -- number of iterations to use in beam search. Default 40
 -b beam_width     -- width of beam search
 -s numStop        -- number of stop distributions.    EVG=2,DMV=2 
 -a numArg         -- number of argument distributions. EVG=2, DMV=1
 -X max_sent_len   -- maximum sentence length for training 
 -d debug          -- debug level
 -n num_iterations -- number of iterations for second stage
 -r randomSeed     -- random seed
 -t trainPath      -- training path
 -d devPath        -- dev path
 -T testPath       -- test path;



Examples on how to run common models:


Regular DMV using Klein and Manning Initializer: 

	estimate_uvg -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -r 17500 -a 1 -s 2 -b 1 -k 1 -A analyses/0 

DMV using random restart initialization:
	estimate_uvg -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7500 -a 1 -s 2 -A analyses/0
	estimate_uvg -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7501 -a 1 -s 2 -A analyses/1
		...

EVG w/ smoothing and random restart initialization
	estimate_uvg6lin -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7500 -a 2 -s 2 -A analyses/0
	estimate_uvg6lin -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7501 -a 2 -s 2 -A analyses/1
		...

Lexicalized EVG w/ smoothing and random restart initialization
	estimate_uvg6_luvg1linb -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7500 -a 2 -s 2 -A analyses/0
	estimate_uvg6_luvg1linb -D 1  -V 1 -n 100 -u 100 -t wsj_2_21.conll -d wsj_22.conll -T wsj_24.conll -b 20  -r 7501 -a 2 -s 2 -A analyses/1
		...


For random restart scoring, I would recommend running 30-50 jobs, and selecting the one with the lowest free energy (the third column at the end of the output.)

I have a script for this (process_gold_experiment.py), that presumes you run 10 times that number, and averages the results over 10 groups of jobs.  Given a path, it presumes the logs are in:
"path/logs/"    and the filenames there are numbered 0-299 (or 0-499).  It selects the job with the highest free energy in each cohort of 30(50), and averages over those results.

