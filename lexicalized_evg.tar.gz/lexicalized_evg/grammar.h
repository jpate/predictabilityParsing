/*
 * Copyright William Headden 2009
 *
*/

#ifndef GRAMMAR_H
#define GRAMMAR_H

using namespace std;
#include<iostream>
#include<string>
#include<vector>

#ifdef LINUX
#include<tr1/unordered_map>
#endif
#ifdef OSX
#include<ext/hash_map>
#endif

class Grammar;
#include "Vocab.h"
//#include "dependency.h"
#include "MultDir.h"
#define L  0
#define R  1 
#define ML 2 
#define MR 3 
#define S  4
#define UL 5
#define UR 6
#define NUMNTS 7
#ifndef TOP
#define TOP 3   //distinguish 0,1,2+
#endif
#define NUMVAL (TOP+1) //top valence is 2, unmarked one gets 3
#define NUMNT_SMALL 6

/*
 * Model:
 * More simply:
 *
 * S -> L R
 * L -> L^n, n\in 0,1,2,...,n-1;Np
 * L^n -> L ML^n         //predict  v |  in n place
 * ML^Np -> R L^Np | R L^N-1 	//predict whether to stop
 * ML^n -> R L^n-1  
 * L^0 -> ul

 * R -> R^Np | R^n, n \in 0,1,2,...,n-1
 * R^n -> MR^n R,  n \in 1,2,...N-1,Np
 * MR^Np -> R^Np L | R^N-1 L
 * MR^n -> R^n-1 L
 * R^0 -> ur
 */

//backoff:

#include"types.h"
#include"Sentence.h"
#include"Tree.h"

//typedef pair<U,U> word_type;
typedef pair<U,U> Upair;
typedef MultDir2<U> MD;
typedef Dist Dist2;
#ifdef LINUX
typedef tr1::unordered_map<U,MD*> W_MD;
typedef tr1::unordered_map<U,W_MD> WW_MD;
typedef tr1::unordered_map<U,list<pair<U,F> > > U_LUF;
typedef tr1::unordered_map<U,U_LUF > UU_LUF;
typedef tr1::unordered_map<U,set<U> > U_SetU;

#endif
#ifdef OSX
typedef ext::hash_map<U,MD*> W_MD;
typedef ext::hash_map<U,W_MD> WW_MD;
typedef ext::hash_map<U,list<pair<U,F> > > U_LUF;
typedef ext::hash_map<U,set<U> > U_SetU;
#endif
typedef vector<W_MD> VW_MD;
typedef vector<MD *> V_MD;
typedef vector<V_MD> VV_MD;
typedef vector<WW_MD> VWW_MD;
class MetaGrammar;

#include "Tree.h"
//Common Grammar parameters
class MetaGrammar{
	public:
		MetaGrammar(Vocab & tv,Vocab & wv,list<pair<U,F> > & arg_symbols,list<pair<U,F> > & word_symbols,list<pair<U,F> > & back_symbols, list<pair<U,F> > & stop_symbols,U_LUF & wbp,pair<F,F> & backAlph,pair<F,F> & backAlph2,const Count<U> & wordCount, const Count<U> & tagCount,const Count<pair<U,U>,int> & tagWordCount,bool tiedInit,const vector<Sentence> & sents,int varType,bool useBuckets,F gb_prior_hyp,F gb_prior_hyp2);
		~MetaGrammar(){
			foreach(W_MD,iter,word_given_pos){
				delete iter->second;
				iter->second=NULL;
			}
			//if(posMD) delete posMD;
		}
		Vocab & tagVocab;
		Vocab & wordVocab;
		string translate[NUMNTS];
		list<pair<U,F> >  & arg_symbols;
		list<pair<U,F> >  & word_symbols;
		list<pair<U,F> >  & backoff_symbols;
		list<pair<U,F> >  & stop_symbols;
		U_LUF  & wordsByPOS;
		UU_LUF  wordsByPOSHeadLeft;
		UU_LUF  wordsByPOSHeadRight;
		Grammar * generateInitialGrammar();
		typedef pair<U,pair<U,U> > ChangeType;

		typedef set<ChangeType> ChangeSet;
		pair<F,F> backoffAlpha;
		pair<F,F> backoffAlpha2;
		ChangeSet changes;
		const Count<U> & wordCount; 
		const Count<U> & tagCount;
		const Count<pair<U,U>,int> & tagWordCount;
		bool tiedInit;
		const vector<Sentence> & trains;
		int varType;
		bool useBuckets;
		F gb_prior_hyp;
		F gb_prior_hyp2;
		W_MD word_given_pos;
		//MD * posMD;
	private:
};
class Grammar{
	public:
		typedef list<pair<U,F> > UFList;
		Grammar(MetaGrammar * mg);
		virtual ~Grammar(){}
		F prob_rule(U par, U pc, const word_type & word){return 1;}
		virtual F prob_rule(U par, U pc,U l,U lc,const word_type & word){assert(false);return 0;}//prob L_TOP -> L_n
		virtual F prob_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e){assert(false);return 0;}

		F tree_prob(Tree * t,const Sentence & sent);
		F increment(Tree * t,const Sentence & sent,int count,bool delete_table);
		F increment_rule(U par,U pc, const word_type & word,F count,bool supervised){return 1;}
		virtual F increment_rule(U par,U pc, U l,U lc, const word_type & word,F count,bool supervised){return 0;}
		virtual F increment_rule(U par, U pc,U lchild,U lc, U rchild,U rc, const word_type & s,const word_type & m, const word_type & e, F count,bool supervised){return 0;}
		void write(ostream & out);


		// things formerly in component classes
		void reestimate(int type,bool nonmix,bool mix);//////////////////
		void initToPrior(int type,bool nonmix,bool mix);//////////////////
		void clearCounts(bool nonmix,bool mix);//////////////////
		F logKLPosteriorPrior(bool reestimate_nonmix=true,bool reestimate_mix=true);////////////
		void printStatistics(ostream & out);///////////////////////
		void setCollapsed(bool c,bool reestimate_nonmix,bool reestimate_mix,F probReset=1);//////////
		void readFromFile(istream & in);
		void writeToFile(ostream & out);
		void sample_posterior(bool reestimate_nonmix,bool reestimate_mix,F size_factor);//////////
		bool getCollapsed(){return collapsed;}

		Vocab & getTagVocab()const{return tagVocab;}
		Vocab & getWordVocab()const{return wordVocab;}
		Vocab & getTagVocab(){return tagVocab;}
		Vocab & getWordVocab(){return wordVocab;}
		string translate[NUMNTS];
		static void generateSymbols(Vocab & tagVocab,list<pair<U,F> > & arg_symbols,F arg_alpha,list<pair<U,F> > & stop_symbols,F stop_alpha,F nonstop_alpha,Count<U> & tagCount,bool ignoreTagCount);
		MD * get_aw_given_arg(U arg);
		UFList & getArgs(){return args;}
		UFList & getWords(){return words;}
		UFList & getBacks(){return backs;}
		const UFList & getWordList(U arg){return wordsByPOS[arg];}
		const UFList & getWordListL(U arg,U head){return meta_grammar->wordsByPOSHeadLeft[arg][head];}
		const UFList & getWordListR(U arg,U head){return meta_grammar->wordsByPOSHeadRight[arg][head];}
		void add_mix_dist(Dist2 * dist){mix_distributions.push_back(dist);}
		void add_nonmix_dist(Dist2 * dist){
			assert(dist);
			//cout<<"adding distribution "<<dist->getID()<<" "<<nonmix_distributions.size()<<endl;
			nonmix_distributions.push_back(dist);
		}
		list<Dist2 *> & get_mix_dist(){return mix_distributions;}
		list<Dist2 *> & get_nonmix_dist(){return nonmix_distributions;}
		void delete_dists();
		void reestimateHyperparameters();
		void setMetaGrammar(MetaGrammar * mg){meta_grammar=mg;}
		MetaGrammar * getMetaGrammar(){return meta_grammar;}
	protected:
		list<Dist2 *> mix_distributions;
		list<Dist2 *> nonmix_distributions;
		//list<list<Dist2 *> > grouped_mix_distributions;
		bool collapsed;
	private:
		MetaGrammar * meta_grammar;
		U_LUF  & wordsByPOS;
		Vocab & tagVocab;
		Vocab & wordVocab;
		UFList & args;
		UFList & words;
		UFList & backs;
		F logProbCorpus;

		class hyperparameter_learning_specs{
			public:
				hyperparameter_learning_specs():use_gamma_prior(false),b1(1),b2(2){}
				bool use_gamma_prior;
				F b1;
				F b2;
		};
	public:
		static U stop;
		static U nonstop;
		//static U NUMVAL;	
		//static U TOP;	
	
	friend ostream & operator<<(ostream & out, Grammar &G);
};
//istream & operator>>(istream & in, Grammar &G);
MD * getMD(U h,W_MD & md);
MD * getMD(U h,V_MD & md);
MD * getMD(U h,U v, WW_MD & md);
MD * getMD(U h,U a,U v, VWW_MD & md);
MD * getMD(U h,U v, VW_MD & md);
MD * getMD(U h,U v, VV_MD & md);

#endif

