/* gammavariate.h -- generates samples from a Gamma distribution
 *
 * Mark Johnson, 1st May 2006
 *
 * Translated from gammavariate() code in Python library
 */

#ifndef GAMMAVARIATE_H
#define GAMMAVARIATE_H

#ifdef __cplusplus
extern "C" {
#endif

  /* gammavariate() generates samples from a Gamma distribution
   * conditioned on the parameters alpha.
   * 
   * alpha > 0, mean is alpha, variance is alpha
   * Warning: a few older sources define the gamma distribution in terms
   * of alpha > -1.0
   */

  double gammavariate(double alpha);

#ifdef __cplusplus
};
#endif

#endif /* GAMMAVARIATE_H */
