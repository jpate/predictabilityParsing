/*
 * Copyright William Headden 2007
 *
*/

#ifndef VOCAB_H
#define VOCAB_H
#include<iostream>
#include<vector>
#include"utility.h"
//#include"LookupTable.h"

#include<assert.h>
using namespace std;
template<typename type>
class GeneralizedVocab{

	public:
		const type &undefined(){
			//static type un="\%UNDEFINED\%";
			//static type un="NEW_UNK";
			return un;
		}
		type un;
		GeneralizedVocab(type u):un(u){}
		size_t lookup(type s)
		{
			typename map<type,size_t>::iterator iter=myMap().find(s);
			if(iter==myMap().end()){
				size_t size=myMap().size();
				myMap()[s]=size+1;
				assert(size+1==myMap().size());
				myRevMap()[size+1]=s;
				return size+1;
			}
			return iter->second;
		}
		const type & lookup(size_t i){
			assert(i>=0);
			if(i>=myMap().size()+1){
				return GeneralizedVocab::undefined();//undefined
			}
			return myRevMap()[i];
		}
		size_t size() const{
			return myMap().size()+1;
		}
		static GeneralizedVocab *& vocab(){
			static GeneralizedVocab * v= NULL;
			if(!v) v= new GeneralizedVocab();
			return v;
		}
		static void clearStatic(){
			if(GeneralizedVocab::vocab())
				delete(GeneralizedVocab::vocab());
			GeneralizedVocab::vocab()=NULL;

			//myMap().clear();
		//	myRevMap().resize(0);
		}
		void print(ostream & out){
			typename map<type,size_t>::iterator i=count_.begin();
			out<<"Vocab:"<<endl;
			for(;i!=count_.end();i++)
				out<<'\t'<<i->first<<'\t'<<i->second<<endl;
		}
	private:
		/*
		static ext::hash_map<symbol,size_t> & myMap(){
			static ext::hash_map<symbol,size_t> count_;
			return count_;
		}
		*/
		map<type,size_t> & myMap(){return count_;}
		const map<type,size_t> & myMap()const{return count_;}
		map<type,size_t> count_;
		map<size_t,type> & myRevMap(){return rcount_;}
		map<size_t,type> rcount_;
		/*
		static vector<symbol> & myRevMap(){
			static vector<symbol> count_(50000);
			return count_;
		}
		*/

};
typedef GeneralizedVocab<string> Vocab;
#endif
