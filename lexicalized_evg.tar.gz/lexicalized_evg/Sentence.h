/*
 * Copyright William Headden 2009
 *
*/

#ifndef SENTENCE_H
#define SENTENCE_H
#include<vector>
#include<list>
using namespace std;
class word_type{
	public:
		word_type():word(0),tag(0){}
		word_type(size_t t, size_t w):word(w),original_word(w),tag(t){}
		int word;
		int original_word;
		int tag;
		friend bool operator==(const word_type & a, const word_type & b){
			return a.word==b.word&&a.tag==b.tag;
		}
		friend bool operator!=(const word_type & a, const word_type & b){
			return !(a==b);
		}
};
class Sentence: public vector<word_type>{
	public:
	//Sentence
		word_type root;
		Sentence():vector<word_type>(),root((size_t)(-1),(size_t)(-1)){}
};
#endif
