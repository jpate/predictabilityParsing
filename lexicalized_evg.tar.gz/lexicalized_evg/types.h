#ifndef TYPES_H
#define TYPES_H
#include<bits/stl_pair.h>
typedef long double F;
typedef unsigned int U;
typedef std::pair<U,U> Upair;
#endif
