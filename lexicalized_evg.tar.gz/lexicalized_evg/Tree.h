/*
 * Copyright William Headden 2009
 *
*/

#ifndef TREE_H
#define TREE_H
struct Tree;
#include"Sentence.h"
#include"grammar.h"
#include"types.h"
struct Tree {
	//typedef long double F;
	//typedef size_t U;
	//typedef pair<U,U> Upair;
	Tree(const set<Upair> & deps,const Sentence & sent);
	Tree(U nt_,U ntc_, word_type h, U st, U en,Tree * l,Tree * r,const Sentence & sent):
		nt(nt_),ntc(ntc_),s(st),e(en),head(h),left(l),right(r),sent(sent){};
	//Tree(const set<Upair> & deps,const vector<U> & sent);
	//Tree(const vector<U> & vec,const vector<U> & sent, U start, U end,U nt_);
	~Tree();
	U nt;
	U ntc;
	U s;
	U e;
	word_type head;
	Tree * left;
	Tree * right;
	const Sentence & sent;
	void incErule(Grammar * g);
	void write(ostream & out, const Grammar & g);
	void extract_dependency_set(set<Upair> & deps);
	void extract_dependency_list(list<Upair> & deps);
	void extract_dependency_vec(vector<U> & depvec);
	void assignEndpoints();
	//U countDifferingDeps(Tree * t);
};
//pair<size_t,size_t> getHeadFromSent(size_t n,size_t start,size_t end,const vector<pair<size_t,size_t> > & sent);

ostream & operator<<(ostream & out, Tree * t);
bool operator==(const Tree & t0, const Tree & t1);
bool operator!=(const Tree & t0, const Tree & t1);
#endif
