#ifndef DIGAMMA_H
#define DIGAMMA_H
double digamma(double x);


#endif
